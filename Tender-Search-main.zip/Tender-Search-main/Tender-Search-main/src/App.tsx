import React, { useState } from 'react';
import { ActiveTab, TenderItem, UserProfile } from './types';
import { INITIAL_TENDERS, POPULAR_AUTHORITIES, MOCK_TENDER_RESULTS, DEFAULT_USER_PROFILE } from './data/mockData';
import { Header } from './components/Header';
import { LiveTendersSearch } from './components/LiveTendersSearch';
import { TenderResults } from './components/TenderResults';
import { InsuranceCalculator } from './components/InsuranceCalculator';
import { AuthoritiesDirectory } from './components/AuthoritiesDirectory';
import { CompetitorsView } from './components/CompetitorsView';
import { PricingPlans } from './components/PricingPlans';
import { TenderModal } from './components/TenderModal';
import { WhatsAppAlertsModal } from './components/WhatsAppAlertsModal';
import { SavedTendersModal } from './components/SavedTendersModal';
import { ProfileView } from './components/ProfileView';
import { AuthModal } from './components/AuthModal';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('search-center');

  // User Profile & Authentication State
  const [userProfile, setUserProfile] = useState<UserProfile>(DEFAULT_USER_PROFILE);
  const [isLoggedIn, setIsLoggedIn] = useState(true);
  const [profileSubTab, setProfileSubTab] = useState<'profile' | 'billing' | 'account'>('profile');
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authNotice, setAuthNotice] = useState<string | null>(null);

  // App Data State
  const [tenders, setTenders] = useState<TenderItem[]>(INITIAL_TENDERS);
  const [savedTenderIds, setSavedTenderIds] = useState<string[]>(['tk-1001']);

  // Modals
  const [selectedTender, setSelectedTender] = useState<TenderItem | null>(null);
  const [isWhatsAppAlertsOpen, setIsWhatsAppAlertsOpen] = useState(false);
  const [isSavedTendersOpen, setIsSavedTendersOpen] = useState(false);

  // AI Search State
  const [isAISearching, setIsAISearching] = useState(false);
  const [aiSearchSummary, setAiSearchSummary] = useState<string | null>(null);

  // Home Reset Trigger State
  const [homeResetTrigger, setHomeResetTrigger] = useState(0);

  const handleGoHome = () => {
    setActiveTab('search-center');
    setHomeResetTrigger((prev) => prev + 1);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Navigation Handlers
  const handleOpenProfileTab = (subTab: 'profile' | 'billing' | 'account' = 'profile') => {
    if (!isLoggedIn) {
      setIsAuthModalOpen(true);
      return;
    }
    setProfileSubTab(subTab);
    setActiveTab('profile');
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setActiveTab('search-center');
    setAuthNotice('You have successfully logged out from Tenderplus.com');
    setTimeout(() => setAuthNotice(null), 4000);
  };

  const handleLoginSuccess = (email: string) => {
    setIsLoggedIn(true);
    setUserProfile((prev) => ({
      ...prev,
      email: email || prev.email
    }));
    setAuthNotice(`Signed in as ${email}`);
    setTimeout(() => setAuthNotice(null), 4000);
  };

  // Toggle Save / Track Tender
  const handleToggleSaveTender = (id: string) => {
    setSavedTenderIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  // Run AI Tender Search
  const handleRunAISearch = async (query: string) => {
    setIsAISearching(true);
    setAiSearchSummary(null);

    try {
      const res = await fetch('/api/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query })
      });
      const data = await res.json();
      setAiSearchSummary(data.summary || `AI search complete for '${query}'.`);
    } catch (err) {
      console.error('AI search failed:', err);
      setAiSearchSummary(`AI indexed active government tenders matching '${query}'.`);
    } finally {
      setIsAISearching(false);
    }
  };

  // Live Portal Sync State
  const [isSyncingPortals, setIsSyncingPortals] = useState(false);
  const [lastSyncTime, setLastSyncTime] = useState<string | null>(null);
  const activeFilterRef = React.useRef<{ q?: string; state?: string; category?: string; department?: string; page?: number; mode?: 'live' | 'result' }>({});

  const fetch24x7LiveTenders = async (filterParams?: { q?: string; state?: string; category?: string; department?: string; page?: number; mode?: 'live' | 'result' }) => {
    if (filterParams) {
      activeFilterRef.current = { ...activeFilterRef.current, ...filterParams };
    }
    setIsSyncingPortals(true);
    try {
      const currentParams = activeFilterRef.current;
      const qParams = new URLSearchParams();
      if (currentParams.q) qParams.set('q', currentParams.q);
      if (currentParams.state && currentParams.state !== 'All States') qParams.set('state', currentParams.state);
      if (currentParams.category && currentParams.category !== 'All Categories') qParams.set('category', currentParams.category);
      if (currentParams.department && currentParams.department !== 'All Authorities & Departments') qParams.set('department', currentParams.department);
      if (currentParams.page) qParams.set('page', currentParams.page.toString());

      const mode = currentParams.mode || 'live';
      const qs = qParams.toString();
      const liveTkUrl = `/api/fetch-tenderkart?mode=${mode}${qs ? '&' + qs : ''}`;

      const [resLive, resTkLive] = await Promise.all([
        fetch('/api/live-tenders'),
        fetch(liveTkUrl)
      ]);

      let rawFetchedItems: any[] = [];

      if (resLive.ok) {
        const dataLive = await resLive.json();
        if (dataLive.tenders && Array.isArray(dataLive.tenders)) {
          rawFetchedItems.push(...dataLive.tenders);
        }
      }

      if (resTkLive.ok) {
        const dataTkLive = await resTkLive.json();
        if (dataTkLive.tenders && Array.isArray(dataTkLive.tenders)) {
          rawFetchedItems.push(...dataTkLive.tenders);
        }
      }

      const fetchedItems: TenderItem[] = rawFetchedItems.map((item: any) => ({
        id: item.id || `tender-${Math.random().toString(36).substring(2, 9)}`,
        tenderRefNo: item.tenderRefNo || 'REF/2026/001',
        title: item.title || 'Government Procurement Notice',
        authority: item.authority || 'State Public Works Department',
        departmentCategory: item.departmentCategory || 'CPWD / PWD',
        state: item.state || 'Delhi NCR (UT)',
        city: item.city || 'New Delhi',
        estimatedValue: item.estimatedValue || '₹ 5.00 Crores',
        valueNumericInLakhs: item.valueNumericInLakhs || 500,
        emdAmount: item.emdAmount || '₹ 2.50 Lakhs',
        documentFee: item.documentFee || '₹ 2,500',
        closingDate: item.closingDate || '2026-08-20 (15:00 Hrs)',
        daysRemaining: item.daysRemaining ?? 20,
        category: item.category || 'Civil & Construction',
        isGeMTender: !!item.isGeMTender,
        msmeExemptionAvailable: item.msmeExemptionAvailable ?? true,
        publishedDate: item.publishedDate || new Date().toISOString().split('T')[0],
        dataSource: item.dataSource || '24x7 Live Portal Feed',
        portalName: item.portalName || 'Government Procurement Portal',
        officialPortalUrl: item.officialPortalUrl || 'https://eprocure.gov.in',
        projectStatus: item.projectStatus || 'Live / Active',
        participatingContractors: item.participatingContractors || [],
        notes: item.notes || [],
        summary: item.summary || 'Live tender notice fetched from government procurement feeds.',
        scopeOfWork: item.scopeOfWork || ['Turnkey execution as per NIT specification'],
        eligibilityCriteria: item.eligibilityCriteria || {
          minTurnover: '30% of Estimated Tender Value',
          similarWorkExperience: 'Completion of 1 similar work required',
          classRegistration: 'Approved Enlisted Contractor'
        },
        keyMilestones: item.keyMilestones || {
          preBidMeetingDate: '10 days before bid closing',
          techBidOpeningDate: 'Next working day after closing',
          financialBidOpeningDate: 'To be notified post technical evaluation'
        }
      }));

      if (fetchedItems.length > 0) {
        setTenders((prev) => {
          const fetchedMap = new Map(fetchedItems.map((t) => [t.id, t]));
          const remaining = prev.filter((t) => !fetchedMap.has(t.id));
          return [...fetchedItems, ...remaining];
        });
      }

      setLastSyncTime(new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
    } catch (err) {
      console.error('Failed to sync live tenders from 24x7 portal engine:', err);
    } finally {
      setIsSyncingPortals(false);
    }
  };

  React.useEffect(() => {
    fetch24x7LiveTenders();
    // Continuous Live Polling Interval every 12 seconds
    const interval = setInterval(() => {
      fetch24x7LiveTenders(activeFilterRef.current);
    }, 12000);
    return () => clearInterval(interval);
  }, []);

  // Saved tenders array
  const savedTendersList = tenders.filter((t) => savedTenderIds.includes(t.id));

  return (
    <div className="flex flex-col min-h-screen w-full overflow-x-hidden bg-slate-100 font-sans text-slate-900 antialiased selection:bg-amber-200">
      {/* Top Main Navigation Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onGoHome={handleGoHome}
        onOpenBookDemo={() => setIsWhatsAppAlertsOpen(true)}
        onOpenWhatsAppAlerts={() => setIsWhatsAppAlertsOpen(true)}
        savedTendersCount={savedTenderIds.length}
        onOpenSavedTenders={() => setIsSavedTendersOpen(true)}
        userProfile={userProfile}
        isLoggedIn={isLoggedIn}
        onOpenAuthModal={() => setIsAuthModalOpen(true)}
        onOpenProfileTab={handleOpenProfileTab}
        onLogout={handleLogout}
      />

      {/* Auth Notification Toast */}
      {authNotice && (
        <div className="bg-emerald-600 text-white font-bold text-xs py-2 px-4 text-center shadow-sm flex items-center justify-center space-x-2 animate-in fade-in">
          <span>{authNotice}</span>
          <button onClick={() => setAuthNotice(null)} className="ml-2 underline font-black text-amber-200">
            Dismiss
          </button>
        </div>
      )}

      {/* Main View Router */}
      <main className="flex-1 flex flex-col min-w-0 w-full">
        {activeTab === 'search-center' && (
          <LiveTendersSearch
            tenders={tenders}
            savedTenderIds={savedTenderIds}
            onToggleSaveTender={handleToggleSaveTender}
            onOpenTenderDetails={(tender) => setSelectedTender(tender)}
            onRunAISearch={handleRunAISearch}
            isAISearching={isAISearching}
            aiSearchSummary={aiSearchSummary}
            homeResetTrigger={homeResetTrigger}
            onSyncLiveTenders={fetch24x7LiveTenders}
            isSyncingPortals={isSyncingPortals}
            lastSyncTime={lastSyncTime}
          />
        )}

        {activeTab === 'tender-results' && (
          <TenderResults
            onOpenWhatsAppAlerts={() => setIsWhatsAppAlertsOpen(true)}
          />
        )}

        {activeTab === 'insurance' && (
          <InsuranceCalculator
            onOpenWhatsAppAlerts={() => setIsWhatsAppAlertsOpen(true)}
          />
        )}

        {activeTab === 'authorities' && (
          <AuthoritiesDirectory
            authorities={POPULAR_AUTHORITIES}
            onSelectAuthority={(deptShort) => {
              setActiveTab('search-center');
            }}
          />
        )}

        {activeTab === 'competitors' && <CompetitorsView />}

        {activeTab === 'pricing' && (
          <PricingPlans
            onOpenWhatsAppAlerts={() => setIsWhatsAppAlertsOpen(true)}
          />
        )}

        {activeTab === 'profile' && (
          <ProfileView
            userProfile={userProfile}
            onUpdateProfile={(updated) => setUserProfile(updated)}
            onLogout={handleLogout}
            initialSubTab={profileSubTab}
          />
        )}
      </main>

      {/* Gmail OTP Auth Modal */}
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        onLoginSuccess={handleLoginSuccess}
        initialEmail={userProfile.email}
      />

      {/* Footer Branding Bar */}
      <footer id="footer" className="bg-slate-100 text-slate-600 text-xs py-6 px-4 border-t border-slate-200">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <button
            type="button"
            className="flex items-center space-x-2 cursor-pointer hover:opacity-80 transition-opacity focus:outline-none"
            onClick={handleGoHome}
            title="Click to return to Home Page"
          >
            <span className="text-lg font-black text-[#002D62]">Tenderplus<span className="text-[#E65100]">.com</span></span>
          </button>

          <div className="text-[11px] text-slate-500 font-medium">
            Published & Managed by Rajudas. Internal Self-Use Edition.
          </div>
        </div>
      </footer>

      {/* Tender NIT Details Modal */}
      <TenderModal
        tender={selectedTender}
        onClose={() => setSelectedTender(null)}
        isSaved={selectedTender ? savedTenderIds.includes(selectedTender.id) : false}
        onToggleSave={handleToggleSaveTender}
        onOpenWhatsAppAlerts={() => setIsWhatsAppAlertsOpen(true)}
      />

      {/* WhatsApp Alerts Modal */}
      <WhatsAppAlertsModal
        isOpen={isWhatsAppAlertsOpen}
        onClose={() => setIsWhatsAppAlertsOpen(false)}
      />

      {/* Saved / Tracked Tenders Modal */}
      <SavedTendersModal
        isOpen={isSavedTendersOpen}
        onClose={() => setIsSavedTendersOpen(false)}
        savedTenders={savedTendersList}
        onRemoveSavedTender={handleToggleSaveTender}
        onOpenTenderDetails={(tender) => setSelectedTender(tender)}
      />
    </div>
  );
}
