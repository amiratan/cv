import React, { useState } from 'react';
import {
  User,
  CreditCard,
  Sliders,
  ShieldCheck,
  CheckCircle2,
  Save,
  Building2,
  FileText,
  Download,
  Key,
  Smartphone,
  Mail,
  Lock,
  RefreshCw,
  LogOut,
  ChevronRight,
  AlertCircle,
  Eye,
  Copy,
  Receipt,
  UserCheck,
  MapPin,
  Calendar,
  Sparkles,
  ShieldAlert
} from 'lucide-react';
import { UserProfile, PaymentInvoice } from '../types';

interface ProfileViewProps {
  userProfile: UserProfile;
  onUpdateProfile: (updated: UserProfile) => void;
  onLogout: () => void;
  initialSubTab?: 'profile' | 'billing' | 'account';
}

export const ProfileView: React.FC<ProfileViewProps> = ({
  userProfile,
  onUpdateProfile,
  onLogout,
  initialSubTab = 'profile'
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'profile' | 'billing' | 'account'>(initialSubTab);

  // Editable Form States
  const [formData, setFormData] = useState<UserProfile>(userProfile);
  const [saveSuccess, setSaveSuccess] = useState<string | null>(null);

  // Invoice Modal
  const [selectedInvoice, setSelectedInvoice] = useState<PaymentInvoice | null>(null);

  // Backup codes reveal
  const [showBackupCodes, setShowBackupCodes] = useState(false);
  const [copiedCode, setCopiedCode] = useState(false);

  const handleInputChange = (field: keyof UserProfile, value: any) => {
    let cleanValue = value;
    if (field === 'mobile' && typeof value === 'string') {
      cleanValue = value.replace(/\D/g, '').slice(0, 10);
    }
    setFormData((prev) => ({ ...prev, [field]: cleanValue }));
  };

  const handleSubControlChange = (field: keyof UserProfile['subAccountControls'], value: any) => {
    setFormData((prev) => ({
      ...prev,
      subAccountControls: {
        ...prev.subAccountControls,
        [field]: value
      }
    }));
  };

  const handleSave = (sectionName: string) => {
    onUpdateProfile(formData);
    setSaveSuccess(`${sectionName} updated successfully!`);
    setTimeout(() => {
      setSaveSuccess(null);
    }, 3000);
  };

  const handleGenerateNewBackupCodes = () => {
    const newCodes = Array.from({ length: 6 }, () =>
      Math.random().toString(36).substring(2, 6).toUpperCase() + '-' + Math.random().toString(36).substring(2, 6).toUpperCase()
    );
    const updated = { ...formData, backupCodes: newCodes };
    setFormData(updated);
    onUpdateProfile(updated);
    setSaveSuccess('Generated 6 new single-use 2-Step Verification backup codes.');
    setTimeout(() => setSaveSuccess(null), 3000);
  };

  return (
    <div className="flex-1 bg-[#f8fafc] overflow-y-auto p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto w-full">
      {/* Top Profile Banner Header */}
      <div className="bg-gradient-to-r from-[#002D62] to-[#001D42] rounded-2xl p-6 sm:p-8 text-white shadow-sm relative overflow-hidden">
        <div className="absolute right-0 top-0 translate-x-12 -translate-y-12 w-64 h-64 bg-amber-400/10 rounded-full blur-2xl pointer-events-none"></div>

        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="flex items-center space-x-4 sm:space-x-5">
            <div className={`w-16 h-16 sm:w-20 sm:h-20 rounded-2xl ${formData.avatarBgColor || 'bg-red-600'} text-white font-black text-2xl sm:text-3xl flex items-center justify-center shadow-lg border-2 border-white/20 shrink-0`}>
              {formData.name.charAt(0).toUpperCase()}
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight">{formData.name}</h1>
                <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 text-[10px] uppercase tracking-wider font-extrabold px-2.5 py-0.5 rounded-full flex items-center space-x-1">
                  <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                  <span>Verified Account</span>
                </span>
              </div>
              <p className="text-slate-300 text-xs sm:text-sm font-medium mt-0.5">{formData.email}</p>
              <p className="text-amber-400 text-xs font-semibold mt-1 flex items-center space-x-1.5">
                <Building2 className="w-3.5 h-3.5" />
                <span>{formData.companyName || 'Rajudas Procurement Solutions'}</span>
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-3 w-full md:w-auto">
            <button
              onClick={onLogout}
              className="bg-rose-600/90 hover:bg-rose-600 text-white text-xs font-bold px-4 py-2.5 rounded-xl shadow-md flex items-center space-x-1.5 transition-all border border-rose-500 shrink-0 cursor-pointer"
            >
              <LogOut className="w-4 h-4" />
              <span>Log Out</span>
            </button>
          </div>
        </div>

        {/* Tab Navigation Controls */}
        <div className="flex flex-wrap items-center gap-2 mt-6 pt-6 border-t border-slate-700/60">
          <button
            onClick={() => setActiveSubTab('profile')}
            className={`px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold flex items-center space-x-2 transition-all cursor-pointer ${
              activeSubTab === 'profile'
                ? 'bg-amber-400 text-slate-900 shadow-md'
                : 'bg-slate-800/80 text-slate-300 hover:bg-slate-800 hover:text-white'
            }`}
          >
            <User className="w-4 h-4" />
            <span>My Profile</span>
          </button>

          <button
            onClick={() => setActiveSubTab('billing')}
            className={`px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold flex items-center space-x-2 transition-all cursor-pointer ${
              activeSubTab === 'billing'
                ? 'bg-amber-400 text-slate-900 shadow-md'
                : 'bg-slate-800/80 text-slate-300 hover:bg-slate-800 hover:text-white'
            }`}
          >
            <CreditCard className="w-4 h-4" />
            <span>Billing & Settings</span>
          </button>

          <button
            onClick={() => setActiveSubTab('account')}
            className={`px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold flex items-center space-x-2 transition-all cursor-pointer ${
              activeSubTab === 'account'
                ? 'bg-amber-400 text-slate-900 shadow-md'
                : 'bg-slate-800/80 text-slate-300 hover:bg-slate-800 hover:text-white'
            }`}
          >
            <Sliders className="w-4 h-4" />
            <span>My Account (Controls & 2FA)</span>
          </button>
        </div>
      </div>

      {/* Toast Notification Banner */}
      {saveSuccess && (
        <div className="mb-6 bg-emerald-50 border border-emerald-300 text-emerald-900 px-4 py-3 rounded-xl font-bold text-xs sm:text-sm flex items-center justify-between shadow-sm animate-in fade-in slide-in-from-top-2">
          <div className="flex items-center space-x-2">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
            <span>{saveSuccess}</span>
          </div>
          <button onClick={() => setSaveSuccess(null)} className="text-emerald-700 font-black hover:text-emerald-900 text-xs">
            Dismiss
          </button>
        </div>
      )}

      {/* ======================================================== */}
      {/* SUB-TAB 1: MY PROFILE                                   */}
      {/* ======================================================== */}
      {activeSubTab === 'profile' && (
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 sm:p-8 space-y-8">
          <div className="border-b border-slate-200 pb-4 flex items-center justify-between">
            <div>
              <h2 className="text-xl font-black text-slate-900 flex items-center space-x-2">
                <User className="w-5 h-5 text-[#002D62]" />
                <span>My Profile Details</span>
              </h2>
              <p className="text-xs text-slate-500 mt-1">
                Update your personal identification, contact details, gender, date of birth, and official address.
              </p>
            </div>
            <button
              onClick={() => handleSave('My Profile')}
              className="bg-[#002D62] hover:bg-[#001D42] text-white font-bold text-xs px-4 py-2.5 rounded-xl shadow-md flex items-center space-x-2 transition-all cursor-pointer border border-slate-800"
            >
              <Save className="w-4 h-4 text-amber-400" />
              <span>Save Profile</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Name */}
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1.5">
                Full Name <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => handleInputChange('name', e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-[#002D62] text-sm font-semibold text-slate-900 bg-slate-50 focus:bg-white"
                required
              />
            </div>

            {/* Email */}
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1.5">
                Email ID (Gmail Verified) <span className="text-rose-500">*</span>
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => handleInputChange('email', e.target.value)}
                  className="w-full pl-10 pr-24 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-[#002D62] text-sm font-semibold text-slate-900 bg-slate-50 focus:bg-white"
                  required
                />
                <span className="absolute right-2 top-1/2 -translate-y-1/2 bg-emerald-100 text-emerald-800 text-[10px] font-extrabold px-2 py-0.5 rounded-md border border-emerald-300">
                  Gmail Verified
                </span>
              </div>
            </div>

            {/* Mobile */}
            <div>
              <div className="flex justify-between items-center mb-1.5">
                <label className="block text-xs font-bold text-slate-700 uppercase">
                  Mobile Number <span className="text-rose-500">*</span>
                </label>
                <span className="text-[10px] text-slate-500 font-bold">
                  {(formData.mobile || '').length}/10 Digits
                </span>
              </div>
              <div className="relative">
                <Smartphone className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="tel"
                  maxLength={10}
                  value={formData.mobile}
                  onChange={(e) => handleInputChange('mobile', e.target.value)}
                  placeholder="9876543210"
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-[#002D62] text-sm font-semibold text-slate-900 bg-slate-50 focus:bg-white tracking-wider"
                  required
                />
              </div>
            </div>

            {/* Gender */}
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1.5">Gender</label>
              <select
                value={formData.gender}
                onChange={(e) => handleInputChange('gender', e.target.value as any)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-[#002D62] text-sm font-bold text-slate-900 bg-slate-50 focus:bg-white"
              >
                <option value="Male">Male</option>
                <option value="Female">Female</option>
                <option value="Other">Other</option>
                <option value="Prefer not to say">Prefer not to say</option>
              </select>
            </div>

            {/* Date of Birth */}
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1.5">
                Date of Birth (DOB)
              </label>
              <div className="relative">
                <Calendar className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="date"
                  value={formData.dateOfBirth}
                  onChange={(e) => handleInputChange('dateOfBirth', e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-[#002D62] text-sm font-bold text-slate-900 bg-slate-50 focus:bg-white"
                />
              </div>
            </div>

            {/* Company Name */}
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1.5">Company / Firm Name</label>
              <div className="relative">
                <Building2 className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={formData.companyName}
                  onChange={(e) => handleInputChange('companyName', e.target.value)}
                  placeholder="Your Contracting / Business Entity"
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-[#002D62] text-sm font-semibold text-slate-900 bg-slate-50 focus:bg-white"
                />
              </div>
            </div>

            {/* Address */}
            <div className="md:col-span-2">
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1.5">
                Official Address
              </label>
              <div className="relative">
                <MapPin className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                <textarea
                  rows={3}
                  value={formData.address}
                  onChange={(e) => handleInputChange('address', e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-[#002D62] text-sm font-semibold text-slate-900 bg-slate-50 focus:bg-white"
                ></textarea>
              </div>
            </div>
          </div>

          <div className="pt-4 flex justify-end">
            <button
              onClick={() => handleSave('My Profile')}
              className="bg-[#002D62] hover:bg-[#001D42] text-white font-bold text-sm px-6 py-3 rounded-xl shadow-md flex items-center space-x-2 transition-all cursor-pointer border border-slate-800"
            >
              <Save className="w-4 h-4 text-amber-400" />
              <span>Update Profile Info</span>
            </button>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* SUB-TAB 2: BILLING AND SETTINGS                          */}
      {/* ======================================================== */}
      {activeSubTab === 'billing' && (
        <div className="space-y-8">
          {/* GST & PAN Details Form */}
          <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 sm:p-8 space-y-6">
            <div className="border-b border-slate-200 pb-4 flex items-center justify-between">
              <div>
                <h2 className="text-xl font-black text-slate-900 flex items-center space-x-2">
                  <CreditCard className="w-5 h-5 text-[#002D62]" />
                  <span>GST, PAN & Tax Settings</span>
                </h2>
                <p className="text-xs text-slate-500 mt-1">
                  Manage GST Identification Number (GSTIN), PAN, and tax invoice billing details for procurement subscription claims.
                </p>
              </div>
              <button
                onClick={() => handleSave('GST & Billing Settings')}
                className="bg-[#002D62] hover:bg-[#001D42] text-white font-bold text-xs px-4 py-2.5 rounded-xl shadow-md flex items-center space-x-2 transition-all cursor-pointer border border-slate-800"
              >
                <Save className="w-4 h-4 text-amber-400" />
                <span>Save GST Info</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* GST Number */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1.5">
                  GST Identification Number (GSTIN)
                </label>
                <div className="relative">
                  <Receipt className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={formData.gstNumber}
                    onChange={(e) => handleInputChange('gstNumber', e.target.value.toUpperCase())}
                    placeholder="e.g. 27AABCU9603R1ZM"
                    className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-[#002D62] text-sm font-mono font-bold text-slate-900 bg-slate-50 focus:bg-white"
                  />
                </div>
                <p className="text-[11px] text-slate-500 mt-1">
                  Input 15-digit GSTIN to claim 18% Input Tax Credit (ITC) on all invoices.
                </p>
              </div>

              {/* PAN Number */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1.5">
                  Permanent Account Number (PAN)
                </label>
                <div className="relative">
                  <FileText className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={formData.panNumber}
                    onChange={(e) => handleInputChange('panNumber', e.target.value.toUpperCase())}
                    placeholder="e.g. AABCU9603R"
                    className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-[#002D62] text-sm font-mono font-bold text-slate-900 bg-slate-50 focus:bg-white"
                  />
                </div>
                <p className="text-[11px] text-slate-500 mt-1">
                  10-character PAN number associated with entity tax filings.
                </p>
              </div>

              {/* Billing Address */}
              <div className="md:col-span-2">
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1.5">
                  GST Registered Billing Address
                </label>
                <textarea
                  rows={2}
                  value={formData.billingAddress}
                  onChange={(e) => handleInputChange('billingAddress', e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-[#002D62] text-sm font-semibold text-slate-900 bg-slate-50 focus:bg-white"
                ></textarea>
              </div>
            </div>
          </div>

          {/* Billing & Payment History */}
          <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 sm:p-8 space-y-6">
            <div>
              <h2 className="text-xl font-black text-slate-900 flex items-center space-x-2">
                <Receipt className="w-5 h-5 text-[#002D62]" />
                <span>Billing & Payment History</span>
              </h2>
              <p className="text-xs text-slate-500 mt-1">
                View previous subscription receipts, download official GST tax invoices, and check transaction statuses.
              </p>
            </div>

            <div className="overflow-x-auto rounded-xl border border-slate-200">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-slate-100 text-[11px] font-black uppercase text-slate-700 border-b border-slate-200">
                    <th className="py-3 px-4">Invoice ID</th>
                    <th className="py-3 px-4">Date</th>
                    <th className="py-3 px-4">Description</th>
                    <th className="py-3 px-4">Amount</th>
                    <th className="py-3 px-4">Tax / GST</th>
                    <th className="py-3 px-4">Status</th>
                    <th className="py-3 px-4 text-right">Tax Invoice</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 text-xs text-slate-800 font-semibold">
                  {formData.paymentHistory.map((invoice) => (
                    <tr key={invoice.id} className="hover:bg-slate-50">
                      <td className="py-3.5 px-4 font-mono font-bold text-[#002D62]">{invoice.id}</td>
                      <td className="py-3.5 px-4 text-slate-600">{invoice.date}</td>
                      <td className="py-3.5 px-4 font-bold text-slate-900">{invoice.description}</td>
                      <td className="py-3.5 px-4 font-black text-slate-900">{invoice.amount}</td>
                      <td className="py-3.5 px-4 text-slate-500 text-[11px]">{invoice.taxAmount}</td>
                      <td className="py-3.5 px-4">
                        <span className="bg-emerald-100 text-emerald-800 border border-emerald-300 font-extrabold text-[10px] px-2.5 py-1 rounded-full inline-flex items-center space-x-1">
                          <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                          <span>{invoice.status}</span>
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-right">
                        <button
                          onClick={() => setSelectedInvoice(invoice)}
                          className="bg-slate-100 hover:bg-slate-200 text-[#002D62] font-bold text-xs px-3 py-1.5 rounded-lg border border-slate-300 inline-flex items-center space-x-1.5 cursor-pointer"
                        >
                          <Download className="w-3.5 h-3.5 text-[#002D62]" />
                          <span>Download GST Receipt</span>
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* SUB-TAB 3: MY ACCOUNT (MANAGE CONTROL & 2FA)             */}
      {/* ======================================================== */}
      {activeSubTab === 'account' && (
        <div className="space-y-8">
          {/* Section A: Manage Control Option */}
          <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 sm:p-8 space-y-6">
            <div className="border-b border-slate-200 pb-4 flex items-center justify-between">
              <div>
                <h2 className="text-xl font-black text-slate-900 flex items-center space-x-2">
                  <Sliders className="w-5 h-5 text-[#002D62]" />
                  <span>Manage Account Controls & Team Permissions</span>
                </h2>
                <p className="text-xs text-slate-500 mt-1">
                  Configure notification dispatch rules, daily digest frequency, sub-user access controls, and active sessions.
                </p>
              </div>
              <button
                onClick={() => handleSave('Account Controls')}
                className="bg-[#002D62] hover:bg-[#001D42] text-white font-bold text-xs px-4 py-2.5 rounded-xl shadow-md flex items-center space-x-2 transition-all cursor-pointer border border-slate-800"
              >
                <Save className="w-4 h-4 text-amber-400" />
                <span>Save Controls</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Role Permissions */}
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                <label className="block text-xs font-bold text-slate-800 uppercase mb-1">
                  Account Role & Administrative Power
                </label>
                <select
                  value={formData.subAccountControls.rolePermissions}
                  onChange={(e) => handleSubControlChange('rolePermissions', e.target.value as any)}
                  className="w-full mt-2 px-3.5 py-2 rounded-xl border border-slate-300 font-bold text-sm bg-white text-slate-900"
                >
                  <option value="Admin">Admin (Full Access & Billing Control)</option>
                  <option value="Manager">Manager (Track Tenders & Export Reports)</option>
                  <option value="Viewer">Viewer (Read-Only Access)</option>
                </select>
                <p className="text-[11px] text-slate-500 mt-2">
                  Current role gives full administrative control over tender tracking desks and alert channels.
                </p>
              </div>

              {/* Daily Digest Time */}
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                <label className="block text-xs font-bold text-slate-800 uppercase mb-1">
                  Daily Tender Digest Dispatch Time
                </label>
                <select
                  value={formData.subAccountControls.dailyDigestTime}
                  onChange={(e) => handleSubControlChange('dailyDigestTime', e.target.value)}
                  className="w-full mt-2 px-3.5 py-2 rounded-xl border border-slate-300 font-bold text-sm bg-white text-slate-900"
                >
                  <option value="08:00 AM">08:00 AM IST (Morning Procurement Digest)</option>
                  <option value="12:00 PM">12:00 PM IST (Midday Corrigendum Digest)</option>
                  <option value="06:00 PM">06:00 PM IST (Evening Summary Digest)</option>
                </select>
                <p className="text-[11px] text-slate-500 mt-2">
                  Daily aggregated NIT notices dispatched straight to your Gmail & WhatsApp.
                </p>
              </div>
            </div>

            {/* Toggles List */}
            <div className="space-y-3 pt-2">
              <h3 className="text-xs font-extrabold text-slate-500 uppercase tracking-wider">
                Notification & Team Controls
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <label className="flex items-center justify-between p-3.5 rounded-xl border border-slate-200 hover:bg-slate-50 cursor-pointer transition-colors">
                  <div className="space-y-0.5">
                    <p className="text-xs font-bold text-slate-900">Email Notifications</p>
                    <p className="text-[11px] text-slate-500">Instant Gmail alerts for matching new tenders</p>
                  </div>
                  <input
                    type="checkbox"
                    checked={formData.subAccountControls.emailNotifications}
                    onChange={(e) => handleSubControlChange('emailNotifications', e.target.checked)}
                    className="w-5 h-5 text-[#002D62] rounded focus:ring-[#002D62] cursor-pointer"
                  />
                </label>

                <label className="flex items-center justify-between p-3.5 rounded-xl border border-slate-200 hover:bg-slate-50 cursor-pointer transition-colors">
                  <div className="space-y-0.5">
                    <p className="text-xs font-bold text-slate-900">SMS Alerts</p>
                    <p className="text-[11px] text-slate-500">Critical deadline & extension reminders via SMS</p>
                  </div>
                  <input
                    type="checkbox"
                    checked={formData.subAccountControls.smsAlerts}
                    onChange={(e) => handleSubControlChange('smsAlerts', e.target.checked)}
                    className="w-5 h-5 text-[#002D62] rounded focus:ring-[#002D62] cursor-pointer"
                  />
                </label>

                <label className="flex items-center justify-between p-3.5 rounded-xl border border-slate-200 hover:bg-slate-50 cursor-pointer transition-colors">
                  <div className="space-y-0.5">
                    <p className="text-xs font-bold text-slate-900">WhatsApp Updates</p>
                    <p className="text-[11px] text-slate-500">Direct WhatsApp desk integration</p>
                  </div>
                  <input
                    type="checkbox"
                    checked={formData.subAccountControls.whatsappUpdates}
                    onChange={(e) => handleSubControlChange('whatsappUpdates', e.target.checked)}
                    className="w-5 h-5 text-[#002D62] rounded focus:ring-[#002D62] cursor-pointer"
                  />
                </label>

                <label className="flex items-center justify-between p-3.5 rounded-xl border border-slate-200 hover:bg-slate-50 cursor-pointer transition-colors">
                  <div className="space-y-0.5">
                    <p className="text-xs font-bold text-slate-900">Allow Sub-Users & Multi-Login</p>
                    <p className="text-[11px] text-slate-500">Team members share tracked tender bookmarking</p>
                  </div>
                  <input
                    type="checkbox"
                    checked={formData.subAccountControls.allowSubUsers}
                    onChange={(e) => handleSubControlChange('allowSubUsers', e.target.checked)}
                    className="w-5 h-5 text-[#002D62] rounded focus:ring-[#002D62] cursor-pointer"
                  />
                </label>
              </div>
            </div>

            {/* Active Sessions */}
            <div className="pt-4 border-t border-slate-200 space-y-3">
              <h3 className="text-xs font-extrabold text-slate-500 uppercase tracking-wider">
                Active Logged-In Devices & Sessions
              </h3>
              <div className="space-y-2">
                {formData.activeSessions.map((session) => (
                  <div
                    key={session.id}
                    className="flex items-center justify-between p-3.5 bg-slate-50 rounded-xl border border-slate-200 text-xs"
                  >
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 rounded-lg bg-slate-200 text-slate-700 font-bold flex items-center justify-center shrink-0">
                        <Smartphone className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="flex items-center space-x-2">
                          <p className="font-bold text-slate-900">{session.device}</p>
                          {session.current && (
                            <span className="bg-emerald-100 text-emerald-800 text-[10px] font-extrabold px-2 py-0.5 rounded-full border border-emerald-300">
                              Active Device
                            </span>
                          )}
                        </div>
                        <p className="text-[11px] text-slate-500">
                          IP: {session.ip} • {session.location} • {session.lastActive}
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Section B: 2-Step Verification Option */}
          <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 sm:p-8 space-y-6">
            <div className="border-b border-slate-200 pb-4 flex items-center justify-between">
              <div>
                <h2 className="text-xl font-black text-slate-900 flex items-center space-x-2">
                  <ShieldCheck className="w-5 h-5 text-emerald-600" />
                  <span>2-Step Verification (2FA Security)</span>
                </h2>
                <p className="text-xs text-slate-500 mt-1">
                  Protect your Tenderplus account from unauthorized access with Gmail OTP or Authenticator App passcodes.
                </p>
              </div>

              {/* Toggle Switch */}
              <div className="flex items-center space-x-3">
                <span className={`text-xs font-extrabold uppercase ${formData.twoFactorEnabled ? 'text-emerald-700' : 'text-slate-400'}`}>
                  {formData.twoFactorEnabled ? '2FA Enabled' : '2FA Disabled'}
                </span>
                <button
                  type="button"
                  onClick={() => {
                    const updated = { ...formData, twoFactorEnabled: !formData.twoFactorEnabled };
                    setFormData(updated);
                    onUpdateProfile(updated);
                    setSaveSuccess(`2-Step Verification turned ${!formData.twoFactorEnabled ? 'ON' : 'OFF'}.`);
                    setTimeout(() => setSaveSuccess(null), 3000);
                  }}
                  className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors cursor-pointer ${
                    formData.twoFactorEnabled ? 'bg-emerald-600' : 'bg-slate-300'
                  }`}
                >
                  <span
                    className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                      formData.twoFactorEnabled ? 'translate-x-6' : 'translate-x-1'
                    }`}
                  />
                </button>
              </div>
            </div>

            {/* 2FA Details Box */}
            <div className="bg-slate-50 p-5 rounded-2xl border border-slate-200 space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    Primary 2FA Method
                  </label>
                  <select
                    value={formData.twoFactorMethod}
                    onChange={(e) => {
                      const updated = { ...formData, twoFactorMethod: e.target.value as any };
                      setFormData(updated);
                      onUpdateProfile(updated);
                    }}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 font-bold text-sm bg-white text-slate-900"
                  >
                    <option value="Gmail OTP">Gmail OTP (Recommended)</option>
                    <option value="SMS OTP">SMS OTP (+91 98765 43210)</option>
                    <option value="Authenticator App">Google Authenticator App</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    Verification Destination
                  </label>
                  <input
                    type="text"
                    readOnly
                    value={formData.twoFactorPhoneOrEmail}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 font-semibold text-sm bg-slate-100 text-slate-700 cursor-not-allowed"
                  />
                </div>
              </div>

              {/* Backup Codes Box */}
              <div className="pt-4 border-t border-slate-200">
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <h4 className="text-xs font-bold text-slate-900 uppercase">Single-Use Backup Recovery Codes</h4>
                    <p className="text-[11px] text-slate-500">
                      Use backup codes if you lose access to your Gmail inbox or mobile device.
                    </p>
                  </div>
                  <div className="flex space-x-2">
                    <button
                      type="button"
                      onClick={() => setShowBackupCodes(!showBackupCodes)}
                      className="bg-slate-200 hover:bg-slate-300 text-slate-800 text-xs font-bold px-3 py-1.5 rounded-lg transition-colors flex items-center space-x-1 cursor-pointer"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>{showBackupCodes ? 'Hide Codes' : 'Show Backup Codes'}</span>
                    </button>
                    <button
                      type="button"
                      onClick={handleGenerateNewBackupCodes}
                      className="bg-[#002D62] hover:bg-[#001D42] text-white text-xs font-bold px-3 py-1.5 rounded-lg transition-colors flex items-center space-x-1 cursor-pointer"
                    >
                      <RefreshCw className="w-3 h-3 text-amber-400" />
                      <span>Regenerate Codes</span>
                    </button>
                  </div>
                </div>

                {showBackupCodes && (
                  <div className="bg-slate-900 text-white p-4 rounded-xl border border-slate-800 font-mono text-xs space-y-2 animate-in fade-in">
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-amber-400 font-black">
                      {formData.backupCodes.map((code, idx) => (
                        <div key={idx} className="bg-slate-800 px-2.5 py-1.5 rounded text-center border border-slate-700">
                          {code}
                        </div>
                      ))}
                    </div>
                    <p className="text-[10px] text-slate-400 pt-1">
                      Keep these codes stored securely. Each code can be used only once to bypass 2FA.
                    </p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tax Invoice Receipt Preview Modal */}
      {selectedInvoice && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/70 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white w-full max-w-lg rounded-2xl shadow-2xl border border-slate-200 overflow-hidden relative">
            <div className="bg-[#002D62] text-white px-6 py-4 flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Receipt className="w-5 h-5 text-amber-400" />
                <h3 className="font-extrabold text-sm tracking-wide">Tax Invoice Receipt • {selectedInvoice.id}</h3>
              </div>
              <button onClick={() => setSelectedInvoice(null)} className="text-slate-300 hover:text-white">
                ✕
              </button>
            </div>

            <div className="p-6 space-y-4 text-xs text-slate-800">
              <div className="flex justify-between border-b pb-3">
                <div>
                  <p className="font-black text-lg text-[#002D62]">Tenderplus.com</p>
                  <p className="text-slate-500 text-[11px]">Government Procurement Intelligence Portal</p>
                  <p className="text-slate-500 text-[11px]">GSTIN: 27AABCT9981K1ZP</p>
                </div>
                <div className="text-right">
                  <p className="font-bold text-slate-900">DATE: {selectedInvoice.date}</p>
                  <p className="font-bold text-emerald-700">STATUS: {selectedInvoice.status}</p>
                </div>
              </div>

              <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 space-y-1">
                <p className="font-bold text-slate-900 uppercase text-[10px] text-slate-500">BILLED TO:</p>
                <p className="font-extrabold text-slate-900">{formData.companyName || formData.name}</p>
                <p className="text-slate-600">GSTIN: {formData.gstNumber || 'Unregistered'}</p>
                <p className="text-slate-600">{formData.billingAddress}</p>
              </div>

              <div className="border rounded-xl overflow-hidden">
                <div className="bg-slate-100 px-3 py-2 font-bold flex justify-between text-slate-700">
                  <span>ITEM DESCRIPTION</span>
                  <span>AMOUNT</span>
                </div>
                <div className="px-3 py-2.5 flex justify-between font-semibold border-t">
                  <span>{selectedInvoice.description}</span>
                  <span>{selectedInvoice.amount}</span>
                </div>
                <div className="px-3 py-2 flex justify-between text-slate-500 border-t text-[11px]">
                  <span>INCLUDED GST (18%)</span>
                  <span>{selectedInvoice.taxAmount}</span>
                </div>
              </div>

              <div className="flex justify-end pt-2">
                <button
                  onClick={() => {
                    alert(`Downloading Tax Invoice PDF for ${selectedInvoice.id}`);
                    setSelectedInvoice(null);
                  }}
                  className="bg-[#002D62] hover:bg-[#001D42] text-white font-bold px-4 py-2 rounded-xl text-xs flex items-center space-x-1.5 shadow-md cursor-pointer"
                >
                  <Download className="w-4 h-4 text-amber-400" />
                  <span>Download PDF Receipt</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
