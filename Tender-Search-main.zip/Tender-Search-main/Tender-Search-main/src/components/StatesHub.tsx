import React from 'react';
import { StateHubInfo } from '../types';
import { MapPin, Building2, ArrowRight, ShieldCheck, Sparkles } from 'lucide-react';
import { StateLandmarkIcon } from './StateLandmarkIcon';

interface StatesHubProps {
  stateHubs: StateHubInfo[];
  onSelectState: (stateName: string) => void;
}

export const StatesHub: React.FC<StatesHubProps> = ({ stateHubs, onSelectState }) => {
  return (
    <div className="flex-1 bg-[#f8fafc] overflow-y-auto p-4 sm:p-6 lg:p-8 space-y-6">
      {/* Header Banner */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-2xs space-y-2">
        <div className="flex items-center space-x-2 text-[#002D62] font-extrabold text-xs uppercase tracking-wider">
          <MapPin className="w-4 h-4 text-[#E65100]" />
          <span>Pan-India eProcurement Directory</span>
        </div>
        <h1 className="text-2xl font-black text-slate-900 tracking-tight">
          Government Tenders by Indian State & Union Territory
        </h1>
        <p className="text-xs sm:text-sm text-slate-500">
          Instant access to State Public Works Departments (PWD), Urban Local Bodies, Jal Nigams, Irrigation, Transport, and Energy Utilities across India.
        </p>
      </div>

      {/* Grid of States */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {stateHubs.map((hub) => (
          <div
            key={hub.code}
            className="bg-white p-6 rounded-2xl border border-slate-200 hover:border-blue-400 shadow-2xs hover:shadow-md transition-all space-y-4 flex flex-col justify-between group"
          >
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="w-12 h-12 rounded-xl bg-slate-50 border border-slate-100 p-1 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
                    <StateLandmarkIcon stateName={hub.stateName} code={hub.code} className="w-9 h-9 mx-auto" />
                  </div>
                  <div>
                    <h3 className="font-extrabold text-base text-slate-900">{hub.stateName}</h3>
                    <p className="text-[11px] font-semibold text-slate-400">State Code: {hub.code}</p>
                  </div>
                </div>
                <span className="bg-blue-50 text-[#002D62] text-xs font-black px-2.5 py-1 rounded-lg border border-blue-200">
                  {hub.activeTendersCount.toLocaleString()} Tenders
                </span>
              </div>

              <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-100 space-y-2 text-xs">
                <div className="flex justify-between items-center text-slate-600 font-medium">
                  <span>Total Active Value:</span>
                  <strong className="text-slate-900 font-extrabold text-sm">{hub.totalValueCrores}</strong>
                </div>
                <div className="text-[11px] text-slate-500">
                  <span className="font-bold text-slate-700 block">Top Issuing Departments:</span>
                  <span className="text-slate-600 line-clamp-1">{hub.topDepartment}</span>
                </div>
              </div>
            </div>

            <button
              onClick={() => onSelectState(hub.stateName)}
              className="w-full bg-[#002D62] hover:bg-[#001D42] text-white font-extrabold text-xs py-2.5 px-4 rounded-xl flex items-center justify-center space-x-2 transition-all mt-2 cursor-pointer"
            >
              <span>Explore {hub.stateName} Tenders</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};
