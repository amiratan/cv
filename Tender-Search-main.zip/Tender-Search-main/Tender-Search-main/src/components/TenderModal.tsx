import React, { useState, useEffect } from 'react';
import { TenderItem } from '../types';
import {
  X,
  FileText,
  Building2,
  Calendar,
  Clock,
  Download,
  CheckCircle2,
  AlertTriangle,
  Sparkles,
  MapPin,
  Bookmark,
  Share2,
  PhoneCall,
  RefreshCw
} from 'lucide-react';

interface TenderModalProps {
  tender: TenderItem | null;
  onClose: () => void;
  isSaved: boolean;
  onToggleSave: (id: string) => void;
  onOpenWhatsAppAlerts: () => void;
}

export const TenderModal: React.FC<TenderModalProps> = ({
  tender,
  onClose,
  isSaved,
  onToggleSave,
  onOpenWhatsAppAlerts
}) => {
  const [activeTab, setActiveTab] = useState<'nit' | 'scope' | 'eligibility' | 'ai_brief'>('nit');
  const [aiBrief, setAiBrief] = useState<any | null>(null);
  const [loadingAi, setLoadingAi] = useState(false);

  useEffect(() => {
    if (!tender) return;

    // Fetch AI Tender Brief when opening
    const fetchAiBrief = async () => {
      setLoadingAi(true);
      try {
        const res = await fetch('/api/dossier', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            entityName: tender.title,
            entityType: tender.departmentCategory
          })
        });
        const data = await res.json();
        setAiBrief(data);
      } catch (err) {
        console.error('Failed to load AI tender brief:', err);
      } finally {
        setLoadingAi(false);
      }
    };

    fetchAiBrief();
  }, [tender]);

  if (!tender) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto animate-in fade-in">
      <div className="bg-white w-full max-w-4xl rounded-3xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[92vh]">

        {/* Modal Header */}
        <div className="px-6 py-5 bg-[#002D62] text-white flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center space-x-3 min-w-0 pr-4">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center border border-amber-400/30 shrink-0">
              <FileText className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center space-x-2">
                <span className="text-[10px] font-extrabold uppercase text-amber-300 bg-amber-950/80 px-2 py-0.5 rounded border border-amber-800/80">
                  Notice Inviting Tender (NIT)
                </span>
                <span className="text-[10px] text-slate-300 font-mono">Ref: {tender.tenderRefNo}</span>
              </div>
              <h2 className="text-base sm:text-lg font-bold tracking-tight text-white mt-0.5 truncate">
                {tender.title}
              </h2>
            </div>
          </div>

          <div className="flex items-center space-x-2 shrink-0">
            <button
              onClick={() => onToggleSave(tender.id)}
              className={`p-2 rounded-xl transition-colors border text-xs font-bold flex items-center space-x-1 ${
                isSaved ? 'bg-amber-500 text-slate-950 border-amber-400' : 'bg-slate-800 text-slate-200 border-slate-700 hover:bg-slate-700'
              }`}
            >
              <Bookmark className={`w-4 h-4 ${isSaved ? 'fill-slate-950' : ''}`} />
              <span className="hidden sm:inline">{isSaved ? 'Tracked' : 'Track'}</span>
            </button>

            <button
              onClick={onClose}
              className="text-slate-300 hover:text-white p-2 rounded-xl hover:bg-slate-800"
            >
              <X className="w-6 h-6" />
            </button>
          </div>
        </div>

        {/* Modal Top Banner Value & Due Date */}
        <div className="bg-slate-50 border-b border-slate-200 p-4 px-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center space-x-2 text-xs font-bold text-slate-800">
              <Building2 className="w-4 h-4 text-[#002D62]" />
              <span>{tender.authority}</span>
            </div>
            <div className="flex items-center space-x-2 text-xs text-slate-500 font-medium">
              <MapPin className="w-3.5 h-3.5 text-slate-400" />
              <span>{tender.city}, {tender.state}</span>
            </div>
          </div>

          <div className="flex items-center space-x-6 shrink-0 text-xs">
            <div>
              <span className="text-[10px] font-bold uppercase text-slate-400 block">Est. Tender Value</span>
              <span className="text-lg font-black text-[#002D62]">{tender.estimatedValue}</span>
            </div>

            <div>
              <span className="text-[10px] font-bold uppercase text-slate-400 block">Submission Deadline</span>
              <span className="text-xs font-extrabold text-rose-600 flex items-center space-x-1">
                <Clock className="w-3.5 h-3.5" />
                <span>{tender.closingDate}</span>
              </span>
            </div>
          </div>
        </div>

        {/* Modal Tabs Header */}
        <div className="flex border-b border-slate-200 px-6 space-x-6 text-xs font-bold bg-white">
          <button
            onClick={() => setActiveTab('nit')}
            className={`py-3 border-b-2 transition-colors ${
              activeTab === 'nit' ? 'border-[#002D62] text-[#002D62]' : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            Tender Overview & Milestones
          </button>
          <button
            onClick={() => setActiveTab('scope')}
            className={`py-3 border-b-2 transition-colors ${
              activeTab === 'scope' ? 'border-[#002D62] text-[#002D62]' : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            Scope of Work ({tender.scopeOfWork?.length || 0})
          </button>
          <button
            onClick={() => setActiveTab('eligibility')}
            className={`py-3 border-b-2 transition-colors ${
              activeTab === 'eligibility' ? 'border-[#002D62] text-[#002D62]' : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            Eligibility Criteria
          </button>
          <button
            onClick={() => setActiveTab('ai_brief')}
            className={`py-3 border-b-2 transition-colors flex items-center space-x-1 ${
              activeTab === 'ai_brief' ? 'border-amber-500 text-amber-700' : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-500" />
            <span>AI Risk Briefing</span>
          </button>
        </div>

        {/* Modal Body Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6 text-xs text-slate-800">

          {activeTab === 'nit' && (
            <div className="space-y-6">
              {/* Summary box */}
              <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-2">
                <h4 className="font-extrabold text-sm text-slate-900">Notice Inviting Tender (NIT) Summary</h4>
                <p className="text-slate-700 leading-relaxed font-medium">{tender.summary}</p>
              </div>

              {/* Financial & Fee Details */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="bg-white p-4 rounded-xl border border-slate-200">
                  <span className="text-[10px] font-bold text-slate-400 block uppercase">EMD Amount</span>
                  <span className="font-extrabold text-slate-900 text-sm">{tender.emdAmount}</span>
                  {tender.msmeExemptionAvailable && (
                    <span className="text-[10px] text-emerald-700 font-bold block mt-1">✓ MSME Exempt Available</span>
                  )}
                </div>

                <div className="bg-white p-4 rounded-xl border border-slate-200">
                  <span className="text-[10px] font-bold text-slate-400 block uppercase">Document Fee</span>
                  <span className="font-extrabold text-slate-900 text-sm">{tender.documentFee}</span>
                </div>

                <div className="bg-white p-4 rounded-xl border border-slate-200">
                  <span className="text-[10px] font-bold text-slate-400 block uppercase">GeM Status</span>
                  <span className="font-extrabold text-[#E65100] text-sm">
                    {tender.isGeMTender ? 'GeM Custom Bid' : 'CPPP / State Portal'}
                  </span>
                </div>
              </div>

              {/* Key Milestones */}
              <div className="space-y-3">
                <h4 className="font-extrabold text-xs uppercase text-slate-400">Critical Milestones & Dates</h4>
                <div className="divide-y divide-slate-100 border border-slate-200 rounded-2xl bg-white overflow-hidden font-medium">
                  <div className="p-3.5 flex justify-between items-center">
                    <span className="font-bold text-slate-700">Pre-Bid Meeting Date & Venue</span>
                    <span className="font-extrabold text-slate-900">{tender.keyMilestones?.preBidMeetingDate || 'Refer NIT document'}</span>
                  </div>
                  <div className="p-3.5 flex justify-between items-center">
                    <span className="font-bold text-slate-700">Technical Bid Opening Date</span>
                    <span className="font-extrabold text-slate-900">{tender.keyMilestones?.techBidOpeningDate || 'Refer NIT document'}</span>
                  </div>
                  <div className="p-3.5 flex justify-between items-center">
                    <span className="font-bold text-slate-700">Financial Bid Opening Date</span>
                    <span className="font-extrabold text-slate-900">{tender.keyMilestones?.financialBidOpeningDate || 'Refer NIT document'}</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'scope' && (
            <div className="space-y-3">
              <h4 className="font-extrabold text-xs uppercase text-slate-400">Detailed Scope of Work & BOQ Overview</h4>
              <ul className="space-y-2.5">
                {(tender.scopeOfWork || []).map((item, idx) => (
                  <li key={idx} className="bg-white p-4 rounded-xl border border-slate-200 flex items-start space-x-3 shadow-2xs">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                    <span className="font-semibold text-slate-800 leading-relaxed">{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {activeTab === 'eligibility' && (
            <div className="space-y-4 font-medium">
              <div className="bg-white p-4 rounded-2xl border border-slate-200 space-y-1">
                <span className="text-[10px] font-extrabold uppercase text-[#002D62]">Minimum Financial Turnover</span>
                <p className="text-slate-900 font-bold">{tender.eligibilityCriteria?.minTurnover || '30% of Estimated Tender Value'}</p>
              </div>

              <div className="bg-white p-4 rounded-2xl border border-slate-200 space-y-1">
                <span className="text-[10px] font-extrabold uppercase text-[#002D62]">Similar Past Work Experience</span>
                <p className="text-slate-900 font-bold">{tender.eligibilityCriteria?.similarWorkExperience || 'Completed similar works required as per NIT'}</p>
              </div>

              <div className="bg-white p-4 rounded-2xl border border-slate-200 space-y-1">
                <span className="text-[10px] font-extrabold uppercase text-[#002D62]">Contractor Class & Licensing</span>
                <p className="text-slate-900 font-bold">{tender.eligibilityCriteria?.classRegistration || 'Valid Enlistment License required'}</p>
              </div>
            </div>
          )}

          {activeTab === 'ai_brief' && (
            <div className="space-y-4">
              {loadingAi ? (
                <div className="p-8 text-center space-y-3">
                  <RefreshCw className="w-8 h-8 text-[#002D62] animate-spin mx-auto" />
                  <p className="text-slate-600 font-semibold text-xs">Generating Gemini AI Tender Risk & Eligibility Briefing...</p>
                </div>
              ) : aiBrief ? (
                <div className="space-y-4">
                  <div className="bg-gradient-to-r from-blue-50 to-amber-50 border border-blue-200 p-4 rounded-2xl space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-extrabold text-slate-900 text-sm">AI Executive Assessment</span>
                      <span className="bg-[#002D62] text-white text-[10px] font-black px-2.5 py-1 rounded-md">
                        {aiBrief.overallRiskRating} ({aiBrief.riskScore}/100 Score)
                      </span>
                    </div>
                    <p className="text-slate-800 leading-relaxed font-medium text-xs">{aiBrief.executiveSummary}</p>
                  </div>

                  <div className="space-y-2">
                    <h5 className="font-extrabold text-xs text-slate-400 uppercase">Recommended Bidding Covenants</h5>
                    <ul className="space-y-2">
                      {aiBrief.recommendedActions?.map((act: string, i: number) => (
                        <li key={i} className="bg-white p-3 rounded-xl border border-slate-200 flex items-start space-x-2 text-xs font-semibold">
                          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                          <span>{act}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              ) : (
                <p className="text-slate-500 text-xs">No AI brief generated.</p>
              )}
            </div>
          )}

        </div>

        {/* Modal Footer */}
        <div className="px-6 py-4 bg-slate-50 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center space-x-2 text-xs text-slate-500 font-semibold">
            <span>Verified eProcurement Document</span>
          </div>

          <div className="flex items-center space-x-3 w-full sm:w-auto">
            <button
              onClick={() => alert(`Downloading official Notice Inviting Tender (NIT) PDF document for ${tender.tenderRefNo}...`)}
              className="bg-slate-200 hover:bg-slate-300 text-slate-800 font-extrabold text-xs px-4 py-2.5 rounded-xl flex items-center justify-center space-x-1.5 transition-colors"
            >
              <Download className="w-4 h-4" />
              <span>Download NIT Document</span>
            </button>

            <button
              onClick={() => {
                onClose();
                onOpenWhatsAppAlerts();
              }}
              className="bg-[#E65100] hover:bg-[#cc4100] text-white font-extrabold text-xs px-5 py-2.5 rounded-xl flex items-center justify-center space-x-1.5 transition-all shadow-2xs"
            >
              <span>Get Bidding Assistance via WhatsApp</span>
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
