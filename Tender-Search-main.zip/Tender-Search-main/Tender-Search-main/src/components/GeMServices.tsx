import React from 'react';
import { ShieldCheck, CheckCircle2, Award, FileText, Sparkles, ArrowRight, PhoneCall } from 'lucide-react';

interface GeMServicesProps {
  onOpenWhatsAppAlerts: () => void;
}

export const GeMServices: React.FC<GeMServicesProps> = ({ onOpenWhatsAppAlerts }) => {
  const gemFeatures = [
    {
      title: 'GeM Vendor Registration & Profile Setup',
      desc: 'Complete primary seller registration, bank verification, GST validation, and Class-3 DSC pairing.',
      badge: 'Assisted Setup'
    },
    {
      title: 'OEM Authorization & Brand Listing',
      desc: 'Get your brand authorized on GeM portal to list products in primary brand categories.',
      badge: 'Brand Clearance'
    },
    {
      title: 'GeM L1 Price Auto-Bidding Optimizer',
      desc: 'Analyze competitor catalog pricing to strategically place lowest L1 bids on custom bids.',
      badge: 'AI Powered'
    },
    {
      title: 'MSME / Startup Exemption Clearance',
      desc: 'Claim 100% EMD fee waiver and prior turnover exemption under PPP-MSE guidelines.',
      badge: '100% EMD Exemption'
    }
  ];

  return (
    <div className="flex-1 bg-[#f8fafc] overflow-y-auto p-4 sm:p-6 lg:p-8 space-y-8">
      {/* Hero Banner */}
      <div className="bg-gradient-to-r from-[#002D62] to-[#001D42] text-white p-8 rounded-3xl shadow-xl space-y-4 relative overflow-hidden">
        <div className="flex items-center space-x-2">
          <span className="bg-[#E65100] text-white font-black text-[10px] uppercase px-3 py-1 rounded-md tracking-wider">
            Official GeM Support Portal
          </span>
          <span className="text-amber-300 font-bold text-xs flex items-center space-x-1">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>Government e-Marketplace (GeM) Services</span>
          </span>
        </div>

        <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white max-w-2xl">
          Scale Your Business with Direct Government Orders via <span className="text-amber-400">GeM Portal</span>
        </h1>

        <p className="text-xs sm:text-sm text-slate-300 max-w-2xl leading-relaxed">
          tenderize.com provides end-to-end GeM seller onboarding, catalog creation, tender bidding management, and L1 pricing strategies for Indian OEMs, distributors, and service providers.
        </p>

        <div className="pt-2 flex flex-wrap items-center gap-3">
          <button
            onClick={onOpenWhatsAppAlerts}
            className="bg-[#E65100] hover:bg-[#cc4100] text-white font-extrabold text-xs px-5 py-3 rounded-xl flex items-center space-x-2 transition-all shadow-md"
          >
            <span>Consult GeM Expert via WhatsApp</span>
            <ArrowRight className="w-4 h-4" />
          </button>
          <a
            href="tel:180012383633"
            className="bg-white/10 hover:bg-white/20 text-white font-bold text-xs px-4 py-3 rounded-xl flex items-center space-x-2 border border-white/20"
          >
            <PhoneCall className="w-4 h-4 text-amber-400" />
            <span>Call Helpline: 1800-123-TENDER</span>
          </a>
        </div>
      </div>

      {/* GeM Services Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {gemFeatures.map((f, i) => (
          <div key={i} className="bg-white p-6 rounded-2xl border border-slate-200 shadow-2xs space-y-3 hover:border-blue-300 transition-all">
            <div className="flex items-center justify-between">
              <span className="text-[10px] uppercase font-black tracking-wider text-[#002D62] bg-blue-50 px-2.5 py-1 rounded border border-blue-200">
                {f.badge}
              </span>
              <CheckCircle2 className="w-5 h-5 text-emerald-600" />
            </div>

            <h3 className="font-extrabold text-base text-slate-900">{f.title}</h3>
            <p className="text-xs text-slate-600 leading-relaxed">{f.desc}</p>

            <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs">
              <span className="text-slate-500 font-semibold">tenderize.com SLA Guarantee</span>
              <button
                onClick={onOpenWhatsAppAlerts}
                className="text-[#E65100] font-extrabold hover:underline flex items-center space-x-1"
              >
                <span>Request Service</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
