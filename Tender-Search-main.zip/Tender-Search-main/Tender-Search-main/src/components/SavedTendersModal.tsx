import React from 'react';
import { TenderItem } from '../types';
import { X, BookmarkCheck, FileText, Download, Trash2, ExternalLink } from 'lucide-react';

interface SavedTendersModalProps {
  isOpen: boolean;
  onClose: () => void;
  savedTenders: TenderItem[];
  onRemoveSavedTender: (id: string) => void;
  onOpenTenderDetails: (tender: TenderItem) => void;
}

export const SavedTendersModal: React.FC<SavedTendersModalProps> = ({
  isOpen,
  onClose,
  savedTenders,
  onRemoveSavedTender,
  onOpenTenderDetails
}) => {
  if (!isOpen) return null;

  const handleExportCSV = () => {
    const headers = ['Ref No', 'Title', 'Authority', 'State', 'Est Value', 'Closing Date'];
    const rows = savedTenders.map(t => [
      `"${t.tenderRefNo}"`,
      `"${t.title.replace(/"/g, '""')}"`,
      `"${t.authority}"`,
      `"${t.state}"`,
      `"${t.estimatedValue}"`,
      `"${t.closingDate}"`
    ]);
    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', 'Tracked_Tenders_TenderPulse.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in">
      <div className="bg-white w-full max-w-3xl rounded-3xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[85vh]">

        {/* Modal Header */}
        <div className="px-6 py-4 bg-[#002D62] text-white flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center space-x-2">
            <BookmarkCheck className="w-5 h-5 text-amber-400" />
            <h2 className="font-extrabold text-base text-white">Tracked & Bookmarked Tenders ({savedTenders.length})</h2>
          </div>
          <button onClick={onClose} className="text-slate-300 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Action Bar */}
        {savedTenders.length > 0 && (
          <div className="bg-slate-50 border-b border-slate-200 px-6 py-3 flex items-center justify-between text-xs font-bold">
            <span className="text-slate-600">Saved for offline review & submission tracking</span>
            <button
              onClick={handleExportCSV}
              className="bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold px-3.5 py-1.5 rounded-lg flex items-center space-x-1.5 transition-colors"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export CSV List</span>
            </button>
          </div>
        )}

        {/* List Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-3">
          {savedTenders.length === 0 ? (
            <div className="text-center py-12 space-y-2 text-slate-500 text-xs">
              <BookmarkCheck className="w-10 h-10 text-slate-300 mx-auto" />
              <p className="font-bold text-slate-800 text-sm">No Tracked Tenders Saved Yet</p>
              <p>Click the 'Track' button on any live tender card to save it here for easy access.</p>
            </div>
          ) : (
            savedTenders.map((tender) => (
              <div
                key={tender.id}
                className="bg-white p-4 rounded-2xl border border-slate-200 hover:border-blue-300 shadow-2xs flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
              >
                <div className="space-y-1 pr-4">
                  <span className="text-[10px] font-mono font-bold text-blue-700 bg-blue-50 px-2 py-0.5 rounded">
                    {tender.tenderRefNo}
                  </span>
                  <h4 className="font-extrabold text-slate-900 text-sm leading-snug">{tender.title}</h4>
                  <div className="text-slate-500 text-[11px]">
                    <span>{tender.authority}</span> • <span>{tender.state}</span>
                  </div>
                </div>

                <div className="flex items-center space-x-3 shrink-0 pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-100 justify-between">
                  <div className="text-right">
                    <span className="font-black text-[#002D62] text-sm block">{tender.estimatedValue}</span>
                    <span className="text-[10px] text-rose-600 font-bold block">{tender.closingDate}</span>
                  </div>

                  <div className="flex items-center space-x-2">
                    <button
                      onClick={() => {
                        onClose();
                        onOpenTenderDetails(tender);
                      }}
                      className="bg-[#002D62] text-white p-2 rounded-xl hover:bg-[#001D42]"
                      title="View NIT"
                    >
                      <FileText className="w-4 h-4" />
                    </button>

                    <button
                      onClick={() => onRemoveSavedTender(tender.id)}
                      className="text-slate-400 hover:text-rose-600 p-2 rounded-xl hover:bg-rose-50"
                      title="Remove from tracked list"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-4 bg-slate-50 border-t border-slate-200 flex justify-end">
          <button
            onClick={onClose}
            className="bg-slate-200 hover:bg-slate-300 text-slate-800 font-extrabold text-xs px-5 py-2.5 rounded-xl transition-colors"
          >
            Close List
          </button>
        </div>

      </div>
    </div>
  );
};
