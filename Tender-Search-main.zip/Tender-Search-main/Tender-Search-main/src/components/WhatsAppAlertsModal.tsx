import React, { useState } from 'react';
import { X, Check, BellRing, PhoneCall } from 'lucide-react';
import { ALL_INDIAN_STATES } from '../data/mockData';

interface WhatsAppAlertsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const WhatsAppAlertsModal: React.FC<WhatsAppAlertsModalProps> = ({
  isOpen,
  onClose
}) => {
  const [whatsappNumber, setWhatsappNumber] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('Civil & Construction');
  const [selectedState, setSelectedState] = useState('Maharashtra');
  const [subscribed, setSubscribed] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubscribed(true);
    setTimeout(() => {
      setSubscribed(false);
      onClose();
    }, 1800);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in">
      <div className="bg-white w-full max-w-md rounded-3xl shadow-2xl border border-slate-200 overflow-hidden">

        {/* Modal Header */}
        <div className="px-6 py-4 bg-emerald-700 text-white flex items-center justify-between border-b border-emerald-800">
          <div className="flex items-center space-x-2">
            <BellRing className="w-5 h-5 text-amber-300 animate-bounce" />
            <h2 className="font-extrabold text-base text-white">Get WhatsApp Tender Alerts</h2>
          </div>
          <button onClick={onClose} className="text-emerald-100 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        {subscribed ? (
          <div className="p-8 text-center space-y-3">
            <div className="w-12 h-12 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto">
              <Check className="w-6 h-6" />
            </div>
            <h3 className="font-extrabold text-slate-900 text-lg">Alerts Subscribed!</h3>
            <p className="text-xs text-slate-600">
              Daily government tender notifications for <strong className="text-slate-900">{selectedState}</strong> ({selectedCategory}) will be sent to WhatsApp <strong className="text-emerald-700">{whatsappNumber}</strong>.
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs font-semibold">
            <div>
              <div className="flex justify-between items-center mb-1">
                <label className="block text-slate-800 font-bold">WhatsApp Mobile Number</label>
                <span className="text-[10px] text-slate-500 font-semibold">
                  {whatsappNumber.length}/10 Digits
                </span>
              </div>
              <div className="relative">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500 font-bold text-xs pointer-events-none">
                  +91
                </span>
                <input
                  type="tel"
                  required
                  maxLength={10}
                  value={whatsappNumber}
                  onChange={(e) => {
                    const digitsOnly = e.target.value.replace(/\D/g, '').slice(0, 10);
                    setWhatsappNumber(digitsOnly);
                  }}
                  placeholder="9876543210"
                  className="w-full pl-12 pr-3.5 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-600 text-slate-900 font-bold tracking-wider"
                />
              </div>
              {whatsappNumber.length > 0 && whatsappNumber.length < 10 && (
                <p className="text-[10px] text-rose-500 font-bold mt-1">
                  Please enter a valid 10-digit mobile number (Current: {whatsappNumber.length} digits)
                </p>
              )}
            </div>

            <div>
              <label className="block text-slate-800 mb-1">Select Work Category</label>
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-600 text-slate-900 font-bold bg-white"
              >
                <option>Civil & Construction</option>
                <option>Electrical & Power</option>
                <option>IT, Software & Telecom</option>
                <option>Solar & Renewable Energy</option>
                <option>Medical & Healthcare</option>
                <option>Security & Manpower</option>
                <option>Transport & Logistics</option>
              </select>
            </div>

            <div>
              <label className="block text-slate-800 mb-1">Select Primary State</label>
              <select
                value={selectedState}
                onChange={(e) => setSelectedState(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-600 text-slate-900 font-bold bg-white"
              >
                {ALL_INDIAN_STATES.map((state) => (
                  <option key={state} value={state}>
                    {state}
                  </option>
                ))}
              </select>
            </div>

            <div className="bg-emerald-50 border border-emerald-200 p-3 rounded-xl text-emerald-900 text-[11px] leading-relaxed">
              🔔 Instant notifications triggered whenever new Notice Inviting Tenders (NIT) matching your state or work category are published.
            </div>

            <div className="pt-2 flex items-center justify-end space-x-3 border-t border-slate-100">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 rounded-xl text-slate-600 font-bold hover:bg-slate-100"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold px-6 py-2.5 rounded-xl transition-all shadow-xs text-xs"
              >
                Activate WhatsApp Alerts
              </button>
            </div>
          </form>
        )}

      </div>
    </div>
  );
};
