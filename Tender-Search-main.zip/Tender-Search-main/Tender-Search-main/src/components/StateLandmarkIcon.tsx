import React from 'react';

interface StateLandmarkIconProps {
  stateName?: string;
  code?: string;
  className?: string;
}

export const StateLandmarkIcon: React.FC<StateLandmarkIconProps> = ({
  stateName = '',
  code = '',
  className = 'w-12 h-12 mx-auto'
}) => {
  const name = stateName.toLowerCase();
  const cd = code.toUpperCase();

  // 1. Uttar Pradesh (UP)
  if (name.includes('uttar pradesh') || name === 'up' || cd === 'UP') {
    return (
      <svg className={className} viewBox="0 0 64 64" fill="none">
        <path d="M12 48H52M16 48V36C16 36 20 28 32 28C44 28 48 36 48 36V48" stroke="#F59E0B" strokeWidth="2.5" strokeLinecap="round" />
        <path d="M28 28V16M36 28V16M32 16C32 16 26 12 32 8C38 12 32 16 32 16Z" stroke="#F59E0B" strokeWidth="2.5" strokeLinecap="round" />
        <circle cx="32" cy="36" r="4" stroke="#F59E0B" strokeWidth="2" />
      </svg>
    );
  }

  // 2. Telangana
  if (name.includes('telangana') || cd === 'TS') {
    return (
      <svg className={className} viewBox="0 0 64 64" fill="none">
        <path d="M16 50H48M20 50V32H44V50M20 32L20 12M44 32L44 12M28 32V50M36 32V50" stroke="#3B82F6" strokeWidth="2.5" strokeLinecap="round" />
        <path d="M16 12H24M40 12H48M32 32H32.01" stroke="#3B82F6" strokeWidth="3" strokeLinecap="round" />
      </svg>
    );
  }

  // 3. Tamil Nadu
  if (name.includes('tamil nadu') || cd === 'TN') {
    return (
      <svg className={className} viewBox="0 0 64 64" fill="none">
        <path d="M12 50H52M16 50L22 16H42L48 50M20 38H44M22 28H42M24 20H40" stroke="#65A30D" strokeWidth="2.5" strokeLinecap="round" />
        <path d="M32 16V10M32 10L28 12M32 10L36 12" stroke="#65A30D" strokeWidth="2" strokeLinecap="round" />
      </svg>
    );
  }

  // 4. Maharashtra
  if (name.includes('maharashtra') || cd === 'MH') {
    return (
      <svg className={className} viewBox="0 0 64 64" fill="none">
        <path d="M12 50H52M18 50V24H46V50M26 50V36C26 32.6863 28.6863 30 32 30C35.3137 30 38 32.6863 38 36V50" stroke="#14B8A6" strokeWidth="2.5" strokeLinecap="round" />
        <path d="M14 24H50M22 24V16H42V24" stroke="#14B8A6" strokeWidth="2.5" strokeLinecap="round" />
      </svg>
    );
  }

  // 5. Rajasthan
  if (name.includes('rajasthan') || cd === 'RJ') {
    return (
      <svg className={className} viewBox="0 0 64 64" fill="none">
        <path d="M12 50H52M18 50V20C18 16 32 12 32 12C32 12 46 16 46 20V50" stroke="#EC4899" strokeWidth="2.5" strokeLinecap="round" />
        <path d="M24 24H40M22 32H42M20 40H44" stroke="#EC4899" strokeWidth="2" strokeLinecap="round" />
        <circle cx="32" cy="20" r="2" stroke="#EC4899" strokeWidth="2" />
      </svg>
    );
  }

  // 6. Haryana
  if (name.includes('haryana') || cd === 'HR') {
    return (
      <svg className={className} viewBox="0 0 64 64" fill="none">
        <path d="M14 50H50M20 50C20 40 24 30 32 30C40 30 44 40 44 50" stroke="#FB923C" strokeWidth="2.5" strokeLinecap="round" />
        <path d="M32 30V14M26 20H38" stroke="#FB923C" strokeWidth="2.5" strokeLinecap="round" />
      </svg>
    );
  }

  // 7. Kerala
  if (name.includes('kerala') || cd === 'KL') {
    return (
      <svg className={className} viewBox="0 0 64 64" fill="none">
        <path d="M10 44C20 44 24 48 32 48C40 48 44 44 54 44" stroke="#FB7185" strokeWidth="2.5" strokeLinecap="round" />
        <path d="M14 44C18 36 26 34 32 34C38 34 46 36 50 44" stroke="#FB7185" strokeWidth="2" strokeLinecap="round" />
        <path d="M24 34V22C24 22 28 18 32 18C36 18 40 22 40 22V34" stroke="#FB7185" strokeWidth="2.5" strokeLinecap="round" />
      </svg>
    );
  }

  // 8. Punjab
  if (name.includes('punjab') || cd === 'PB') {
    return (
      <svg className={className} viewBox="0 0 64 64" fill="none">
        <path d="M16 50H48M24 50V30H40V50" stroke="#64748B" strokeWidth="2.5" strokeLinecap="round" />
        <path d="M32 30V16M24 20L32 12L40 20" stroke="#64748B" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
    );
  }

  // 9. West Bengal
  if (name.includes('west bengal') || name.includes('bengal') || cd === 'WB') {
    return (
      <svg className={className} viewBox="0 0 64 64" fill="none">
        <path d="M12 50H52M20 50V36H44V50" stroke="#A855F7" strokeWidth="2.5" strokeLinecap="round" />
        <path d="M18 36C18 28 24 22 32 22C40 22 46 28 46 36" stroke="#A855F7" strokeWidth="2.5" strokeLinecap="round" />
        <path d="M32 22V12" stroke="#A855F7" strokeWidth="2" strokeLinecap="round" />
      </svg>
    );
  }

  // 10. Gujarat
  if (name.includes('gujarat') || cd === 'GJ') {
    return (
      <svg className={className} viewBox="0 0 64 64" fill="none">
        <path d="M16 50H48M32 50V14" stroke="#D97706" strokeWidth="3" strokeLinecap="round" />
        <path d="M22 28L32 18L42 28" stroke="#D97706" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
        <path d="M26 40H38" stroke="#D97706" strokeWidth="2.5" strokeLinecap="round" />
      </svg>
    );
  }

  // 11. Karnataka
  if (name.includes('karnataka') || cd === 'KA') {
    return (
      <svg className={className} viewBox="0 0 64 64" fill="none">
        <path d="M12 50H52M16 50V30H48V50" stroke="#6366F1" strokeWidth="2.5" strokeLinecap="round" />
        <path d="M20 30V18H44V30M28 18V12H36V18" stroke="#6366F1" strokeWidth="2" strokeLinecap="round" />
      </svg>
    );
  }

  // 12. Delhi
  if (name.includes('delhi') || cd === 'DL') {
    return (
      <svg className={className} viewBox="0 0 64 64" fill="none">
        <path d="M12 50H52M18 50V22L32 14L46 22V50" stroke="#10B981" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
        <path d="M26 50V36C26 32.6863 28.6863 30 32 30C35.3137 30 38 32.6863 38 36V50" stroke="#10B981" strokeWidth="2.5" strokeLinecap="round" />
      </svg>
    );
  }

  // 13. Andhra Pradesh
  if (name.includes('andhra') || cd === 'AP') {
    return (
      <svg className={className} viewBox="0 0 64 64" fill="none">
        <path d="M14 50H50M20 50V28L32 16L44 28V50" stroke="#0284C7" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
        <path d="M28 32H36M24 40H40" stroke="#0284C7" strokeWidth="2" strokeLinecap="round" />
      </svg>
    );
  }

  // 14. Madhya Pradesh
  if (name.includes('madhya pradesh') || cd === 'MP') {
    return (
      <svg className={className} viewBox="0 0 64 64" fill="none">
        <path d="M12 50H52M16 50C16 34 22 24 32 24C42 24 48 34 48 50" stroke="#06B6D4" strokeWidth="2.5" strokeLinecap="round" />
        <path d="M32 24V12M28 18H36" stroke="#06B6D4" strokeWidth="2" strokeLinecap="round" />
      </svg>
    );
  }

  // 15. Bihar
  if (name.includes('bihar') || cd === 'BR') {
    return (
      <svg className={className} viewBox="0 0 64 64" fill="none">
        <path d="M14 50H50M20 50V26H44V50" stroke="#B45309" strokeWidth="2.5" strokeLinecap="round" />
        <path d="M32 26V14M24 18L32 10L40 18" stroke="#B45309" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
    );
  }

  // 16. Odisha
  if (name.includes('odisha') || cd === 'OD') {
    return (
      <svg className={className} viewBox="0 0 64 64" fill="none">
        <circle cx="32" cy="32" r="16" stroke="#047857" strokeWidth="2.5" />
        <path d="M32 16V48M16 32H48M21 21L43 43M21 43L43 21" stroke="#047857" strokeWidth="1.8" />
      </svg>
    );
  }

  // 17. Assam
  if (name.includes('assam') || cd === 'AS') {
    return (
      <svg className={className} viewBox="0 0 64 64" fill="none">
        <path d="M12 50H52M18 50L26 22H38L46 50" stroke="#BE123C" strokeWidth="2.5" strokeLinecap="round" />
        <path d="M32 22V12M26 16H38" stroke="#BE123C" strokeWidth="2" strokeLinecap="round" />
      </svg>
    );
  }

  // 18. Jharkhand
  if (name.includes('jharkhand') || cd === 'JH') {
    return (
      <svg className={className} viewBox="0 0 64 64" fill="none">
        <path d="M14 50H50M20 50L32 18L44 50" stroke="#6D28D9" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
        <path d="M26 36H38" stroke="#6D28D9" strokeWidth="2" strokeLinecap="round" />
      </svg>
    );
  }

  // 19. Chhattisgarh
  if (name.includes('chhattisgarh') || cd === 'CG') {
    return (
      <svg className={className} viewBox="0 0 64 64" fill="none">
        <path d="M12 50H52M18 50V30H46V50" stroke="#C2410C" strokeWidth="2.5" strokeLinecap="round" />
        <path d="M24 30V18H40V30" stroke="#C2410C" strokeWidth="2" strokeLinecap="round" />
      </svg>
    );
  }

  // 20. Uttarakhand & Himachal
  if (name.includes('uttarakhand') || name.includes('himachal') || cd === 'UK' || cd === 'HP') {
    return (
      <svg className={className} viewBox="0 0 64 64" fill="none">
        <path d="M10 50L24 20L36 38L48 16L54 50H10Z" stroke="#0F766E" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
    );
  }

  // 21. Jammu & Kashmir
  if (name.includes('jammu') || name.includes('kashmir') || cd === 'JK') {
    return (
      <svg className={className} viewBox="0 0 64 64" fill="none">
        <path d="M10 46C20 46 24 50 32 50C40 50 44 46 54 46" stroke="#475569" strokeWidth="2.5" strokeLinecap="round" />
        <path d="M16 46L24 24L40 24L48 46" stroke="#475569" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
    );
  }

  // Default Landmark Icon
  return (
    <svg className={className} viewBox="0 0 64 64" fill="none">
      <path d="M12 50H52M18 50V24H46V50" stroke="#002D62" strokeWidth="2.5" strokeLinecap="round" />
      <path d="M32 24V14M26 18H38" stroke="#002D62" strokeWidth="2" strokeLinecap="round" />
    </svg>
  );
};
