import React, { useState } from 'react';
import {
  ShieldCheck,
  FileCheck,
  Calculator,
  Building2,
  CheckCircle2,
  IndianRupee,
  ArrowRight,
  PhoneCall,
  Sparkles,
  HelpCircle,
  Clock,
  Award
} from 'lucide-react';

interface InsuranceCalculatorProps {
  onOpenWhatsAppAlerts: () => void;
}

export const InsuranceCalculator: React.FC<InsuranceCalculatorProps> = ({
  onOpenWhatsAppAlerts
}) => {
  const [insuranceType, setInsuranceType] = useState<
    'bid_security' | 'performance_bond' | 'car_policy' | 'workmen'
  >('bid_security');
  const [tenderValueLakhs, setTenderValueLakhs] = useState<number>(500);
  const [requiredCoverageLakhs, setRequiredCoverageLakhs] = useState<number>(10);
  const [contractDurationMonths, setContractDurationMonths] = useState<number>(12);
  const [contractorClass, setContractorClass] = useState('Class A Contractor');
  const [insurerPreference, setInsurerPreference] = useState('New India Assurance (PSU)');
  const [submittedQuote, setSubmittedQuote] = useState(false);

  // Auto-calculate estimated premium based on insurance type
  const calculatePremium = () => {
    let rate = 0.015; // 1.5% base
    if (insuranceType === 'bid_security') rate = 0.008; // 0.8%
    else if (insuranceType === 'performance_bond') rate = 0.012; // 1.2%
    else if (insuranceType === 'car_policy') rate = 0.006; // 0.6%
    else if (insuranceType === 'workmen') rate = 0.004; // 0.4%

    const basePremium = requiredCoverageLakhs * 100000 * rate;
    const gst = basePremium * 0.18;
    const total = basePremium + gst;

    return {
      basePremium: Math.round(basePremium),
      gst: Math.round(gst),
      total: Math.round(total)
    };
  };

  const premiumDetails = calculatePremium();

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmittedQuote(true);
  };

  return (
    <div className="flex-1 bg-[#f8fafc] overflow-y-auto p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto w-full">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-[#002D62] to-[#001D42] text-white p-6 sm:p-8 rounded-2xl shadow-sm text-center space-y-3 relative overflow-hidden">
        <div className="inline-flex flex-wrap items-center justify-center gap-2 text-xs text-slate-300">
          <span className="bg-[#E65100] text-white font-extrabold text-[10px] uppercase px-2.5 py-0.5 rounded tracking-wide flex items-center space-x-1">
            <ShieldCheck className="w-3 h-3" />
            <span>IRDAI & GFR 2017 Compliant</span>
          </span>
          <span className="text-slate-600 hidden sm:inline">|</span>
          <span className="text-emerald-300 font-bold text-xs">
            Ministry of Finance Approved Surety Bonds
          </span>
        </div>

        <h1 className="text-xl sm:text-2xl font-black text-white tracking-tight">
          Government Tender Insurance & Surety Bonds Portal
        </h1>

        <p className="text-xs sm:text-sm text-slate-300 max-w-2xl mx-auto">
          Input your tender insurance requirements to replace cash EMD and costly Bank Guarantees (BG) with IRDAI-approved Surety Bonds, Contractor's All Risk (CAR) policies, and Workmen Compensation.
        </p>

        <div className="pt-1 flex flex-wrap items-center justify-center gap-3 text-xs">
          <div className="bg-white/10 px-3 py-1.5 rounded-xl border border-white/15 flex items-center space-x-1.5 text-emerald-300 font-bold">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>100% Accepted by CPWD, Railways, NHAI & GeM</span>
          </div>
          <div className="bg-white/10 px-3 py-1.5 rounded-xl border border-white/15 flex items-center space-x-1.5 text-emerald-300 font-bold">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>Zero Collateral Needed for MSME Contractors</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Input Form Column */}
        <div className="lg:col-span-7 bg-white p-6 rounded-2xl border border-slate-200 shadow-2xs space-y-5">
          <div className="border-b border-slate-100 pb-3 flex items-center justify-between">
            <h2 className="font-extrabold text-base text-slate-900 flex items-center space-x-2">
              <Calculator className="w-5 h-5 text-[#002D62]" />
              <span>Input Insurance & Security Requirement</span>
            </h2>
            <span className="text-[11px] font-bold text-slate-400">Step 1 of 2</span>
          </div>

          <form onSubmit={handleFormSubmit} className="space-y-4 text-xs font-semibold">
            {/* Type selector */}
            <div>
              <label className="block text-slate-800 mb-1.5 uppercase tracking-wider text-[11px]">
                Select Required Policy Type
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <button
                  type="button"
                  onClick={() => {
                    setInsuranceType('bid_security');
                    setRequiredCoverageLakhs(10);
                  }}
                  className={`p-3 rounded-xl border text-left flex flex-col justify-between transition-all ${
                    insuranceType === 'bid_security'
                      ? 'border-[#002D62] bg-blue-50/60 ring-2 ring-[#002D62]/20'
                      : 'border-slate-200 hover:border-slate-300'
                  }`}
                >
                  <span className="font-extrabold text-slate-900 text-xs">
                    Bid Security Insurance / EMD Bond
                  </span>
                  <span className="text-[11px] text-slate-500 mt-1">Replaces EMD Demand Draft / Cash</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setInsuranceType('performance_bond');
                    setRequiredCoverageLakhs(25);
                  }}
                  className={`p-3 rounded-xl border text-left flex flex-col justify-between transition-all ${
                    insuranceType === 'performance_bond'
                      ? 'border-[#002D62] bg-blue-50/60 ring-2 ring-[#002D62]/20'
                      : 'border-slate-200 hover:border-slate-300'
                  }`}
                >
                  <span className="font-extrabold text-slate-900 text-xs">
                    Performance Guarantee Surety Bond
                  </span>
                  <span className="text-[11px] text-slate-500 mt-1">5% - 10% Performance Guarantee</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setInsuranceType('car_policy');
                    setRequiredCoverageLakhs(500);
                  }}
                  className={`p-3 rounded-xl border text-left flex flex-col justify-between transition-all ${
                    insuranceType === 'car_policy'
                      ? 'border-[#002D62] bg-blue-50/60 ring-2 ring-[#002D62]/20'
                      : 'border-slate-200 hover:border-slate-300'
                  }`}
                >
                  <span className="font-extrabold text-slate-900 text-xs">
                    Contractor's All Risk (CAR) Policy
                  </span>
                  <span className="text-[11px] text-slate-500 mt-1">Physical Damage & Third Party Risk</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setInsuranceType('workmen');
                    setRequiredCoverageLakhs(15);
                  }}
                  className={`p-3 rounded-xl border text-left flex flex-col justify-between transition-all ${
                    insuranceType === 'workmen'
                      ? 'border-[#002D62] bg-blue-50/60 ring-2 ring-[#002D62]/20'
                      : 'border-slate-200 hover:border-slate-300'
                  }`}
                >
                  <span className="font-extrabold text-slate-900 text-xs">
                    Workmen Compensation Policy
                  </span>
                  <span className="text-[11px] text-slate-500 mt-1">Labor Liability & Site Safety</span>
                </button>
              </div>
            </div>

            {/* Values */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-800 mb-1">Estimated Tender Value (₹ Lakhs)</label>
                <input
                  type="number"
                  required
                  value={tenderValueLakhs}
                  onChange={(e) => setTenderValueLakhs(Number(e.target.value))}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-[#002D62] font-bold text-slate-900"
                />
              </div>

              <div>
                <label className="block text-slate-800 mb-1">Coverage Amount Required (₹ Lakhs)</label>
                <input
                  type="number"
                  required
                  value={requiredCoverageLakhs}
                  onChange={(e) => setRequiredCoverageLakhs(Number(e.target.value))}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-[#002D62] font-bold text-slate-900"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-800 mb-1">Contract Duration (Months)</label>
                <select
                  value={contractDurationMonths}
                  onChange={(e) => setContractDurationMonths(Number(e.target.value))}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-[#002D62] font-bold text-slate-900 bg-white"
                >
                  <option value={6}>6 Months</option>
                  <option value={12}>12 Months (1 Year)</option>
                  <option value={24}>24 Months (2 Years)</option>
                  <option value={36}>36 Months (3 Years)</option>
                  <option value={60}>60 Months (5 Years)</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-800 mb-1">Insurer Partner Preference</label>
                <select
                  value={insurerPreference}
                  onChange={(e) => setInsurerPreference(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-[#002D62] font-bold text-slate-900 bg-white"
                >
                  <option>New India Assurance (PSU)</option>
                  <option>National Insurance Co (PSU)</option>
                  <option>Oriental Insurance Co (PSU)</option>
                  <option>SBI General Insurance</option>
                  <option>ICICI Lombard General</option>
                  <option>Bajaj Allianz General</option>
                </select>
              </div>
            </div>

            <button
              type="submit"
              className="w-full bg-[#E65100] hover:bg-[#cc4100] text-white font-extrabold text-sm py-3 rounded-xl flex items-center justify-center space-x-2 transition-all shadow-md mt-2"
            >
              <FileCheck className="w-4 h-4" />
              <span>Calculate Premium & Request Policy Draft</span>
            </button>
          </form>
        </div>

        {/* Live Calculation Output Card */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-2xs space-y-5">
            <div className="bg-gradient-to-r from-[#002D62] to-[#001D42] text-white p-5 rounded-2xl space-y-2">
              <span className="text-[10px] font-black uppercase text-amber-300 tracking-wider block">
                Estimated Surety / Insurance Premium
              </span>
              <div className="flex items-baseline space-x-1">
                <span className="text-3xl font-black text-amber-400">
                  ₹ {premiumDetails.total.toLocaleString()}
                </span>
                <span className="text-xs text-slate-300 font-bold">(incl. 18% GST)</span>
              </div>
              <p className="text-[11px] text-slate-300">
                Saves up to 80% working capital compared to cash FD margins in Bank Guarantees.
              </p>
            </div>

            {/* Breakdown Table */}
            <div className="space-y-2 text-xs font-semibold">
              <div className="flex justify-between p-2.5 bg-slate-50 rounded-lg">
                <span className="text-slate-600">Base Premium Rate</span>
                <span className="text-slate-900 font-extrabold">
                  {insuranceType === 'bid_security'
                    ? '0.8% p.a.'
                    : insuranceType === 'performance_bond'
                    ? '1.2% p.a.'
                    : '0.6% p.a.'}
                </span>
              </div>

              <div className="flex justify-between p-2.5 bg-slate-50 rounded-lg">
                <span className="text-slate-600">Net Premium Amount</span>
                <span className="text-slate-900 font-extrabold">₹ {premiumDetails.basePremium.toLocaleString()}</span>
              </div>

              <div className="flex justify-between p-2.5 bg-slate-50 rounded-lg">
                <span className="text-slate-600">GST (18%)</span>
                <span className="text-slate-900 font-extrabold">₹ {premiumDetails.gst.toLocaleString()}</span>
              </div>

              <div className="flex justify-between p-2.5 bg-blue-50 border border-blue-200 rounded-lg text-[#002D62]">
                <span className="font-bold">Total Payable Insurance Cost</span>
                <span className="font-black text-sm">₹ {premiumDetails.total.toLocaleString()}</span>
              </div>
            </div>

            {/* Guarantees List */}
            <div className="bg-emerald-50 p-4 rounded-xl border border-emerald-200 space-y-2 text-xs text-emerald-950">
              <h4 className="font-extrabold flex items-center space-x-1.5">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span>IRDAI Compliance & GFR Rule 170 Waiver</span>
              </h4>
              <p className="text-[11px] leading-relaxed">
                As per Ministry of Finance notification OM No. F.1/1/2022-PPD, Surety Bonds issued by IRDAI registered insurers are legally valid for all Central/State Government tenders.
              </p>
            </div>

            {submittedQuote ? (
              <div className="bg-amber-50 p-4 rounded-xl border border-amber-300 text-xs text-amber-950 text-center space-y-2">
                <CheckCircle2 className="w-6 h-6 text-emerald-600 mx-auto" />
                <p className="font-bold text-sm">Insurance Request Submitted!</p>
                <p>Our Insurance Desk will issue your draft policy copy within 2 business hours.</p>
              </div>
            ) : (
              <div className="space-y-2">
                <button
                  onClick={onOpenWhatsAppAlerts}
                  className="w-full bg-[#002D62] hover:bg-[#001D42] text-white font-extrabold text-xs py-3 rounded-xl flex items-center justify-center space-x-2 transition-all shadow-xs"
                >
                  <span>Connect with Insurance Desk via WhatsApp</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
