import React from 'react';
import { Check, Sparkles, Shield, ArrowRight, Zap, PhoneCall } from 'lucide-react';

interface PricingPlansProps {
  onOpenWhatsAppAlerts: () => void;
}

export const PricingPlans: React.FC<PricingPlansProps> = ({
  onOpenWhatsAppAlerts
}) => {
  const plans = [
    {
      name: 'Starter Plan',
      price: '₹ 4,999',
      period: '/ year',
      tag: 'Small Contractors & Vendors',
      popular: false,
      features: [
        'Select 1 State or 2 Central Authorities',
        'Daily Email Tender Alert Summaries',
        'Direct GeM Portal Custom Bids Search',
        'Download NIT & Document PDFs',
        'Standard Support'
      ]
    },
    {
      name: 'Growth Business',
      price: '₹ 9,999',
      period: '/ year',
      tag: 'Active MSMEs & EPC Firms',
      popular: true,
      features: [
        'Pan-India Coverage (All 28 States & UTs)',
        'Real-Time WhatsApp Tender Alerts',
        'Unlimited Keywords & Department Tracking',
        'MSME EMD Exemption Verification Guidance',
        'GeM Seller Onboarding Support',
        'Priority Call & Chat Support'
      ]
    },
    {
      name: 'Enterprise Unlimited',
      price: '₹ 19,999',
      period: '/ year',
      tag: 'Large Infrastructure & OEMs',
      popular: false,
      features: [
        'Pan-India + Global Tenders Directory',
        'Dedicated Tender Bidding Manager',
        'Gemini AI Tender Eligibility Matcher',
        'Joint Venture (JV) Partner Matcher',
        'Complete BOQ Line-Item Analysis',
        '100% SLA Guarantee'
      ]
    }
  ];

  return (
    <div className="flex-1 bg-[#f8fafc] overflow-y-auto p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto w-full">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-[#002D62] to-[#001D42] text-white p-6 sm:p-8 rounded-2xl shadow-sm text-center space-y-3 relative overflow-hidden">
        <div className="inline-flex items-center justify-center space-x-2 text-amber-400 font-extrabold text-xs uppercase tracking-wider">
          <Sparkles className="w-4 h-4 text-[#E65100]" />
          <span>Transparent Pricing for Indian Contractors</span>
        </div>
        <h1 className="text-xl sm:text-2xl font-black text-white tracking-tight">
          Never Miss a Government Tender Opportunity
        </h1>
        <p className="text-xs sm:text-sm text-slate-300 max-w-2xl mx-auto">
          Choose a subscription plan tailored for your state, authority, or industry category. Includes instant WhatsApp alerts and document downloads.
        </p>
      </div>

      {/* Plans Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-6xl mx-auto">
        {plans.map((plan, idx) => (
          <div
            key={idx}
            className={`bg-white rounded-3xl p-6 border transition-all flex flex-col justify-between space-y-6 relative ${
              plan.popular
                ? 'border-[#E65100] shadow-xl ring-2 ring-[#E65100]/20 scale-102'
                : 'border-slate-200 shadow-2xs'
            }`}
          >
            {plan.popular && (
              <span className="absolute -top-3 left-1/2 -translate-x-1/2 bg-[#E65100] text-white font-black text-[10px] uppercase px-3 py-1 rounded-full shadow-xs">
                🔥 Most Popular Choice
              </span>
            )}

            <div className="space-y-4">
              <div>
                <span className="text-[11px] font-bold text-slate-400 block uppercase tracking-wider">{plan.tag}</span>
                <h3 className="text-xl font-extrabold text-slate-900">{plan.name}</h3>
              </div>

              <div className="flex items-baseline space-x-1">
                <span className="text-3xl sm:text-4xl font-black text-[#002D62]">{plan.price}</span>
                <span className="text-xs text-slate-500 font-bold">{plan.period}</span>
              </div>

              <ul className="space-y-2.5 pt-2 text-xs text-slate-700 font-medium border-t border-slate-100">
                {plan.features.map((feat, i) => (
                  <li key={i} className="flex items-start space-x-2">
                    <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                    <span>{feat}</span>
                  </li>
                ))}
              </ul>
            </div>

            <button
              onClick={onOpenWhatsAppAlerts}
              className={`w-full font-extrabold text-xs py-3 rounded-xl flex items-center justify-center space-x-2 transition-all shadow-xs ${
                plan.popular
                  ? 'bg-[#E65100] hover:bg-[#cc4100] text-white'
                  : 'bg-[#002D62] hover:bg-[#001D42] text-white'
              }`}
            >
              <span>Subscribe to {plan.name}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        ))}
      </div>

      {/* Need Custom Plan Banner */}
      <div className="bg-gradient-to-r from-[#002D62] to-[#001D42] text-white p-6 rounded-2xl max-w-4xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
        <div>
          <h3 className="text-base font-extrabold">Need Custom Enterprise Licensing or Multi-User Access?</h3>
          <p className="text-xs text-slate-300">Talk to our procurement experts for customized tender monitoring packages.</p>
        </div>
        <button
          onClick={onOpenWhatsAppAlerts}
          className="bg-amber-400 hover:bg-amber-500 text-slate-950 font-extrabold text-xs px-5 py-2.5 rounded-xl shrink-0 transition-colors"
        >
          Request WhatsApp Quote
        </button>
      </div>
    </div>
  );
};
