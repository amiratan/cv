import { useState } from 'react';
import { ActiveTab, UserProfile } from '../types';
import {
  Building2,
  Sparkles,
  BookmarkCheck,
  Menu,
  X,
  User,
  ChevronDown,
  CreditCard,
  HelpCircle,
  LogOut,
  Sliders,
  BellRing,
  KeyRound,
  LogIn
} from 'lucide-react';

interface HeaderProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  onGoHome?: () => void;
  onOpenBookDemo: () => void;
  onOpenWhatsAppAlerts: () => void;
  savedTendersCount: number;
  onOpenSavedTenders: () => void;
  
  // Profile & Auth
  userProfile: UserProfile;
  isLoggedIn: boolean;
  onOpenAuthModal: () => void;
  onOpenProfileTab: (subTab?: 'profile' | 'billing' | 'account') => void;
  onLogout: () => void;
}

export const Header = ({
  activeTab,
  setActiveTab,
  onGoHome,
  onOpenBookDemo,
  onOpenWhatsAppAlerts,
  savedTendersCount,
  onOpenSavedTenders,
  userProfile,
  isLoggedIn,
  onOpenAuthModal,
  onOpenProfileTab,
  onLogout
}: HeaderProps) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [userDropdownOpen, setUserDropdownOpen] = useState(false);

  const handleLogoClick = () => {
    if (onGoHome) {
      onGoHome();
    } else {
      setActiveTab('search-center');
    }
    setMobileMenuOpen(false);
  };

  const navItems: { id: ActiveTab; label: string; isHot?: boolean; badge?: string }[] = [
    { id: 'search-center', label: 'Live Tenders' },
    { id: 'tender-results', label: 'Tender Results' },
    { id: 'authorities', label: 'Authorities' },
    { id: 'competitors', label: 'Competitors' },
    { id: 'insurance', label: 'Insurance & Bonds' },
    { id: 'pricing', label: 'Pricing' }
  ];

  return (
    <header className="sticky top-0 z-40 bg-white border-b border-slate-200 shadow-2xs">
      {/* Top Announcement Bar */}
      <div className="bg-[#002D62] text-white text-xs py-1.5 px-4 border-b border-slate-800 relative">
        <div className="max-w-7xl mx-auto flex items-center justify-between relative min-h-[26px]">
          <div className="flex items-center space-x-2 shrink-0">
            <span className="bg-red-600 text-white text-[10px] font-black uppercase px-2.5 py-0.5 rounded border border-red-500 tracking-wider animate-pulse shadow-xs">
              LIVE
            </span>
          </div>

          <div className="absolute left-1/2 -translate-x-1/2 text-xs sm:text-sm text-red-500 font-black tracking-wide animate-bounce text-center whitespace-nowrap">
            Published & Managed by Raju Das
          </div>

          {/* Right side placeholder or clear whitespace */}
          <div className="shrink-0 flex items-center z-10"></div>
        </div>
      </div>

      {/* Main Header Brand Nav */}
      <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3 flex items-center justify-between gap-2 sm:gap-4">
        {/* Brand Logo */}
        <button
          type="button"
          className="flex items-center space-x-2.5 cursor-pointer shrink-0 text-left hover:opacity-90 transition-all select-none group focus:outline-none"
          onClick={handleLogoClick}
          title="Click to go to Home Page"
        >
          <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-gradient-to-br from-[#002D62] to-[#001D42] text-white flex items-center justify-center shadow-md border border-slate-700 shrink-0 group-hover:scale-105 transition-transform">
            <Building2 className="w-5 h-5 sm:w-6 sm:h-6 text-amber-400" />
          </div>
          <div>
            <div className="flex items-center space-x-0.5">
              <span className="text-xl sm:text-2xl font-black text-[#002D62] tracking-tight">Tenderplus</span>
              <span className="text-xl sm:text-2xl font-black text-[#E65100]">.com</span>
            </div>
          </div>
        </button>

        {/* Desktop Navigation Links */}
        <nav className="hidden xl:flex items-center space-x-1 font-semibold text-xs text-slate-700">
          {navItems.map((item) => {
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`px-3 py-2 rounded-lg transition-all whitespace-nowrap ${
                  isActive
                    ? 'bg-[#002D62] text-white font-bold shadow-xs'
                    : 'hover:bg-slate-100 text-slate-700'
                }`}
              >
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>

        {/* Right CTA Actions & User Profile Dropdown */}
        <div className="flex items-center space-x-1.5 sm:space-x-2 shrink-0">
          <button
            onClick={onOpenSavedTenders}
            className="relative bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold px-2.5 sm:px-3 py-2 rounded-lg flex items-center space-x-1.5 transition-colors border border-slate-200"
            title="View Tracked / Saved Tenders"
          >
            <BookmarkCheck className="w-4 h-4 text-[#002D62]" />
            <span className="hidden sm:inline">Tracked ({savedTendersCount})</span>
            <span className="sm:hidden text-[11px]">({savedTendersCount})</span>
          </button>

          <button
            onClick={onOpenWhatsAppAlerts}
            className="hidden md:flex bg-[#002D62] hover:bg-[#001D42] text-white text-xs font-bold px-3 py-2 rounded-lg shadow-2xs items-center space-x-1.5 transition-all border border-slate-700"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>Tender Alert Desk</span>
          </button>

          {/* User Profile Menu Dropdown / Sign In Trigger */}
          {isLoggedIn ? (
            <div className="relative">
              <button
                onClick={() => setUserDropdownOpen(!userDropdownOpen)}
                className="bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold px-2.5 sm:px-3 py-2 rounded-lg flex items-center space-x-1.5 sm:space-x-2 transition-all border border-slate-700 shrink-0 cursor-pointer"
              >
                <div className={`w-5 h-5 rounded-full ${userProfile.avatarBgColor || 'bg-red-600'} text-white font-black flex items-center justify-center text-[10px] shrink-0`}>
                  {userProfile.name.charAt(0).toUpperCase()}
                </div>
                <span className="font-bold text-xs">{userProfile.name}</span>
                <ChevronDown className="w-3.5 h-3.5 text-slate-400 shrink-0" />
              </button>

              {userDropdownOpen && (
                <div
                  className="absolute right-0 top-full mt-2 w-60 max-w-[calc(100vw-2rem)] bg-white rounded-xl shadow-2xl border border-slate-200 py-1.5 z-50 text-xs overflow-hidden"
                  onMouseLeave={() => setUserDropdownOpen(false)}
                >
                  <div className="px-3.5 py-2.5 border-b border-slate-100 bg-slate-50">
                    <p className="font-extrabold text-slate-900">{userProfile.name} Account</p>
                    <p className="text-[10px] text-slate-500 font-medium truncate">{userProfile.email}</p>
                  </div>

                  <button
                    onClick={() => {
                      setUserDropdownOpen(false);
                      onOpenProfileTab('profile');
                    }}
                    className="w-full text-left px-3.5 py-2 hover:bg-slate-50 flex items-center space-x-2 text-slate-700 font-semibold cursor-pointer"
                  >
                    <User className="w-3.5 h-3.5 text-[#002D62]" />
                    <span>My Profile</span>
                  </button>

                  <button
                    onClick={() => {
                      setUserDropdownOpen(false);
                      onOpenProfileTab('account');
                    }}
                    className="w-full text-left px-3.5 py-2 hover:bg-slate-50 flex items-center space-x-2 text-slate-700 font-semibold cursor-pointer"
                  >
                    <Sliders className="w-3.5 h-3.5 text-[#002D62]" />
                    <span>My Account</span>
                  </button>

                  <button
                    onClick={() => {
                      setUserDropdownOpen(false);
                      onOpenProfileTab('billing');
                    }}
                    className="w-full text-left px-3.5 py-2 hover:bg-slate-50 flex items-center space-x-2 text-slate-700 font-semibold cursor-pointer"
                  >
                    <CreditCard className="w-3.5 h-3.5 text-[#002D62]" />
                    <span>Billing Settings</span>
                  </button>

                  <button
                    onClick={() => {
                      setUserDropdownOpen(false);
                      onOpenWhatsAppAlerts();
                    }}
                    className="w-full text-left px-3.5 py-2 hover:bg-slate-50 flex items-center space-x-2 text-slate-700 font-semibold cursor-pointer"
                  >
                    <HelpCircle className="w-3.5 h-3.5 text-slate-400" />
                    <span>Support & Assistance</span>
                  </button>

                  <div className="border-t border-slate-100 my-1"></div>

                  <button
                    onClick={() => {
                      setUserDropdownOpen(false);
                      onLogout();
                    }}
                    className="w-full text-left px-3.5 py-2 hover:bg-rose-50 text-rose-600 font-bold flex items-center space-x-2 cursor-pointer"
                  >
                    <LogOut className="w-3.5 h-3.5" />
                    <span>Logout</span>
                  </button>
                </div>
              )}
            </div>
          ) : (
            <button
              onClick={onOpenAuthModal}
              className="bg-amber-400 hover:bg-amber-500 text-slate-900 text-xs font-black px-3.5 py-2 rounded-lg shadow-md flex items-center space-x-1.5 transition-all cursor-pointer shrink-0"
            >
              <KeyRound className="w-3.5 h-3.5 text-[#002D62]" />
              <span>Sign In / OTP</span>
            </button>
          )}
        </div>

        {/* Mobile menu button */}
        <div className="lg:hidden flex items-center space-x-2">
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 rounded-lg text-slate-700 hover:bg-slate-100"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer Navigation */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-slate-900 text-white p-4 space-y-3 border-t border-slate-800 animate-in slide-in-from-top-2">
          <div className="grid grid-cols-2 gap-2 text-xs font-bold">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => {
                  setActiveTab(item.id);
                  setMobileMenuOpen(false);
                }}
                className={`p-2.5 rounded-lg text-left ${
                  activeTab === item.id ? 'bg-[#E65100] text-white' : 'bg-slate-800 text-slate-200'
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>

          <div className="pt-2 flex flex-col gap-2 text-xs font-bold border-t border-slate-800">
            <div className="flex items-center space-x-2 bg-slate-800 p-2.5 rounded-lg border border-slate-700">
              <div className="w-6 h-6 rounded-full bg-red-600 text-white font-black flex items-center justify-center text-xs shrink-0">
                R
              </div>
              <div className="min-w-0 flex-1">
                <p className="font-bold text-white leading-none">Rajudas Account</p>
                <p className="text-[10px] text-slate-400 font-normal truncate mt-0.5">rajudaszoology22@gmail.com</p>
              </div>
            </div>


          </div>
        </div>
      )}
    </header>
  );
};
