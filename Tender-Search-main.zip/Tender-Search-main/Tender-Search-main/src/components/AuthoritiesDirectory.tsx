import React from 'react';
import { AuthorityInfo } from '../types';
import { Building2, Landmark, Shield, Zap, ArrowRight, Layers } from 'lucide-react';

interface AuthoritiesDirectoryProps {
  authorities: AuthorityInfo[];
  onSelectAuthority: (deptName: string) => void;
}

export const AuthoritiesDirectory: React.FC<AuthoritiesDirectoryProps> = ({
  authorities,
  onSelectAuthority
}) => {
  return (
    <div className="flex-1 bg-[#f8fafc] overflow-y-auto p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto w-full">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-[#002D62] to-[#001D42] text-white p-6 sm:p-8 rounded-2xl shadow-sm text-center space-y-3 relative overflow-hidden">
        <div className="inline-flex items-center justify-center space-x-2 text-amber-400 font-extrabold text-xs uppercase tracking-wider">
          <Landmark className="w-4 h-4 text-[#E65100]" />
          <span>Central & State Authorities Directory</span>
        </div>
        <h1 className="text-xl sm:text-2xl font-black text-white tracking-tight">
          Browse Tenders by Issuing Authority & Public Sector Undertakings (PSU)
        </h1>
        <p className="text-xs sm:text-sm text-slate-300 max-w-2xl mx-auto">
          Direct indexing of Central Ministries, Defence Engineer Services, Railways, CPWD, NHAI, NTPC, BHEL, IOCL, and Port Trusts.
        </p>
      </div>

      {/* Grid of Authorities */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {authorities.map((auth) => (
          <div
            key={auth.id}
            className="bg-white p-6 rounded-2xl border border-slate-200 hover:border-blue-400 shadow-2xs hover:shadow-md transition-all space-y-4 flex flex-col justify-between"
          >
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className={`w-11 h-11 rounded-xl text-white font-black text-xs flex items-center justify-center ${auth.logoColor} p-2 text-center`}>
                    {auth.shortName}
                  </div>
                  <div>
                    <h3 className="font-extrabold text-base text-slate-900">{auth.name}</h3>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 bg-slate-100 px-2 py-0.5 rounded">
                      {auth.type}
                    </span>
                  </div>
                </div>
              </div>

              <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-100 space-y-2 text-xs">
                <div className="flex justify-between items-center text-slate-600 font-medium">
                  <span>Live Active Bids:</span>
                  <strong className="text-[#002D62] font-black text-sm">{auth.activeTenders.toLocaleString()}</strong>
                </div>
                <div className="flex justify-between items-center text-slate-600 font-medium">
                  <span>Jurisdiction / Location:</span>
                  <span className="text-slate-800 font-semibold">{auth.location}</span>
                </div>
              </div>
            </div>

            <button
              onClick={() => onSelectAuthority(auth.shortName)}
              className="w-full bg-[#002D62] hover:bg-[#001D42] text-white font-extrabold text-xs py-2.5 px-4 rounded-xl flex items-center justify-center space-x-2 transition-all"
            >
              <span>View {auth.shortName} Tenders</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};
