import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { ALL_INDIAN_STATES, ALL_GOVERNMENT_AUTHORITIES } from '../data/mockData';
import {
  Award,
  Search,
  Filter,
  Calendar,
  Building2,
  MapPin,
  CheckCircle2,
  Users,
  ExternalLink,
  RefreshCw,
  ChevronLeft,
  ChevronRight,
  TrendingDown,
  Clock,
  Sparkles,
  Tag,
  Copy,
  Download,
  X,
  Eye,
  DollarSign,
  FileText,
  Share2,
  Check
} from 'lucide-react';

const CATEGORIES = [
  'All Categories',
  'Civil & Construction',
  'Road & Highways',
  'Account & Auditing',
  'Electrical & Power',
  'IT, Software & Telecom',
  'Solar & Renewable Energy',
  'Medical, Pharma & Healthcare',
  'Transport, Freight & Vehicles',
  'Security, Facility & Manpower',
  'Machinery & Industrial Goods'
];

const AMOUNT_RANGES = [
  { id: 'all', label: 'All Tender Amounts' },
  { id: 'under_1cr', label: 'Up to ₹1 Crore' },
  { id: '1cr_10cr', label: '₹1 Cr - ₹10 Crores' },
  { id: '10cr_50cr', label: '₹10 Cr - ₹50 Crores' },
  { id: '50cr_200cr', label: '₹50 Cr - ₹200 Crores' },
  { id: 'above_200cr', label: 'Above ₹200 Crores' }
];

const TIME_PERIODS = [
  { id: 'all', label: 'All Time Periods' },
  { id: 'today', label: 'Published Today' },
  { id: '7days', label: 'Last 7 Days' },
  { id: '30days', label: 'Last 30 Days' },
  { id: '90days', label: 'Last 90 Days' },
  { id: 'fy2026', label: 'Financial Year (FY 2026-27)' }
];

const TOP_CONTRACTORS = [
  'PNC Infratech Ltd',
  'L&T Construction',
  'Dilip Buildcon Ltd',
  'H.G. Infra Engineering Ltd',
  'Tata Projects Ltd',
  'KCC Buildcon Pvt Ltd',
  'GR Infraprojects Ltd',
  'Shapoorji Pallonji & Co',
  'Kalpataru Projects',
  'NCC Limited',
  'KEC International Ltd',
  'Ahluwalia Contracts (India) Ltd',
  'NBCC (India) Limited',
  'Ircon International Ltd',
  'RVNL'
];

interface TenderResultsProps {
  onOpenWhatsAppAlerts?: () => void;
}

export const TenderResults: React.FC<TenderResultsProps> = ({ onOpenWhatsAppAlerts }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedState, setSelectedState] = useState('All States');
  const [selectedCategory, setSelectedCategory] = useState('All Categories');
  const [selectedDepartment, setSelectedDepartment] = useState('All Authorities & Departments');
  const [selectedAmountRange, setSelectedAmountRange] = useState('all');
  const [selectedTimePeriod, setSelectedTimePeriod] = useState('all');
  
  const [currentPage, setCurrentPage] = useState(1);
  const [results, setResults] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [lastSyncTime, setLastSyncTime] = useState<string | null>(null);
  
  // 5-Second Auto-Pull Timer States
  const [autoRefreshEnabled, setAutoRefreshEnabled] = useState(true);
  const [countdown, setCountdown] = useState(5);

  // Search Auto-Suggest Popup State
  const [showSuggestions, setShowSuggestions] = useState(false);

  // Modal State for Viewing Detailed Tender Result
  const [selectedModalTender, setSelectedModalTender] = useState<any | null>(null);

  // Toast Notification Message
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const totalPages = 50;

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 4000);
  };

  // Compute Auto-suggestions based on search input
  const dynamicSuggestions = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    const suggestions: { id: string; text: string; subtext: string; type: 'contractor' | 'authority' | 'state' | 'category' }[] = [];

    // Matching Contractors
    TOP_CONTRACTORS.forEach((c) => {
      if (!q || c.toLowerCase().includes(q)) {
        suggestions.push({
          id: `c-${c}`,
          text: c,
          subtext: 'L1 Winner / Government Contractor',
          type: 'contractor'
        });
      }
    });

    // Matching Authorities
    ALL_GOVERNMENT_AUTHORITIES.slice(1, 12).forEach((auth) => {
      if (!q || auth.toLowerCase().includes(q)) {
        suggestions.push({
          id: `a-${auth}`,
          text: auth,
          subtext: 'Public Sector Issuing Authority',
          type: 'authority'
        });
      }
    });

    // Matching States
    ALL_INDIAN_STATES.slice(1, 10).forEach((st) => {
      if (!q || st.toLowerCase().includes(q)) {
        suggestions.push({
          id: `s-${st}`,
          text: st,
          subtext: 'State & Territory Region',
          type: 'state'
        });
      }
    });

    // Matching Categories
    CATEGORIES.slice(1).forEach((cat) => {
      if (!q || cat.toLowerCase().includes(q)) {
        suggestions.push({
          id: `cat-${cat}`,
          text: cat,
          subtext: 'Industry Category',
          type: 'category'
        });
      }
    });

    return suggestions.slice(0, 8);
  }, [searchQuery]);

  // Helper to compute a visible window of max 10 page numbers
  const getVisiblePages = (current: number, total: number) => {
    const maxVisible = 10;
    if (total <= maxVisible) {
      return Array.from({ length: total }, (_, i) => i + 1);
    }
    let start = Math.max(1, current - Math.floor(maxVisible / 2));
    let end = start + maxVisible - 1;
    if (end > total) {
      end = total;
      start = Math.max(1, end - maxVisible + 1);
    }
    return Array.from({ length: end - start + 1 }, (_, i) => start + i);
  };

  // Fetch Data function
  const fetchTenderResults = useCallback(async (pageToFetch = currentPage) => {
    setIsLoading(true);
    try {
      const params = new URLSearchParams();
      params.append('mode', 'result');
      params.append('status', 'financial_bid_opening');
      params.append('status', 'financial_evaluation');
      params.append('status', 'aoc');
      params.append('sort', 'last_activity_desc');
      params.append('limit', '50');
      params.append('page', pageToFetch.toString());

      if (searchQuery.trim()) {
        params.append('q', searchQuery.trim());
      }
      if (selectedState && selectedState !== 'All States') {
        params.append('state', selectedState);
      }
      if (selectedCategory && selectedCategory !== 'All Categories') {
        params.append('category', selectedCategory);
      }
      if (selectedDepartment && selectedDepartment !== 'All Authorities & Departments') {
        params.append('department', selectedDepartment);
      }

      const response = await fetch(`/api/fetch-tenderkart?${params.toString()}`);
      if (response.ok) {
        const data = await response.json();
        const items = Array.isArray(data) ? data : (data.tenders || data.data || []);
        
        // Client-side filtering for Tender Amount & Time Period
        let filtered = items;

        if (selectedAmountRange !== 'all') {
          filtered = filtered.filter((item: any) => {
            const valNum = item.valueNumericInLakhs || 1000;
            if (selectedAmountRange === 'under_1cr') return valNum <= 100;
            if (selectedAmountRange === '1cr_10cr') return valNum > 100 && valNum <= 1000;
            if (selectedAmountRange === '10cr_50cr') return valNum > 1000 && valNum <= 5000;
            if (selectedAmountRange === '50cr_200cr') return valNum > 5000 && valNum <= 20000;
            if (selectedAmountRange === 'above_200cr') return valNum > 20000;
            return true;
          });
        }

        setResults(filtered);
        setLastSyncTime(new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
      }
    } catch (err) {
      console.error('Error auto-fetching tender results:', err);
    } finally {
      setIsLoading(false);
    }
  }, [currentPage, searchQuery, selectedState, selectedCategory, selectedDepartment, selectedAmountRange, selectedTimePeriod]);

  // Initial fetch and filter change fetch
  useEffect(() => {
    fetchTenderResults(currentPage);
  }, [selectedState, selectedCategory, selectedDepartment, selectedAmountRange, selectedTimePeriod, currentPage]);

  // 5-Second Countdown and Auto-Refresh Timer Loop
  useEffect(() => {
    if (!autoRefreshEnabled) return;

    const timer = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          fetchTenderResults(currentPage);
          return 5;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [autoRefreshEnabled, currentPage, fetchTenderResults]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setShowSuggestions(false);
    setCurrentPage(1);
    fetchTenderResults(1);
  };

  const handleResetFilters = () => {
    setSearchQuery('');
    setSelectedState('All States');
    setSelectedCategory('All Categories');
    setSelectedDepartment('All Authorities & Departments');
    setSelectedAmountRange('all');
    setSelectedTimePeriod('all');
    setCurrentPage(1);
  };

  // Generate HTML Canvas Image & Download + Copy Text Summary
  const handleCopyResultAndDownloadImage = (item: any) => {
    try {
      const canvas = document.createElement('canvas');
      canvas.width = 1200;
      canvas.height = 920;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      // Outer Canvas Background
      ctx.fillStyle = '#F8FAFC';
      ctx.fillRect(0, 0, 1200, 920);

      // Top Navy Header Banner
      const headerGrad = ctx.createLinearGradient(0, 0, 1200, 0);
      headerGrad.addColorStop(0, '#002D62');
      headerGrad.addColorStop(1, '#001D42');
      ctx.fillStyle = headerGrad;
      ctx.fillRect(0, 0, 1200, 150);

      // IRDAI / Official Tag
      ctx.fillStyle = '#E65100';
      ctx.fillRect(50, 25, 280, 28);
      ctx.fillStyle = '#FFFFFF';
      ctx.font = 'bold 12px sans-serif';
      ctx.fillText('GOVERNMENT FINANCIAL BID OPENING RESULT', 62, 43);

      // Authority Name
      ctx.fillStyle = '#FFFFFF';
      ctx.font = 'bold 24px sans-serif';
      ctx.fillText(item.authority || 'Government Authority', 50, 92);

      // Sub-details
      ctx.fillStyle = '#94A3B8';
      ctx.font = '13px sans-serif';
      ctx.fillText(`Ref: ${item.tenderRefNo || 'TK/AOC/2026/001'} | Award Date: ${item.awardDate || '2026-07-24'} | Location: ${item.state || 'India'}`, 50, 122);

      // Work Description Box
      ctx.fillStyle = '#FFFFFF';
      ctx.fillRect(50, 170, 1100, 95);
      ctx.strokeStyle = '#E2E8F0';
      ctx.lineWidth = 1.5;
      ctx.strokeRect(50, 170, 1100, 95);

      ctx.fillStyle = '#64748B';
      ctx.font = 'bold 12px sans-serif';
      ctx.fillText('PROJECT WORK TITLE & DESCRIPTION', 70, 195);

      ctx.fillStyle = '#0F172A';
      ctx.font = 'bold 17px sans-serif';
      const titleText = item.title || 'Government Contract Work';
      ctx.fillText(titleText.length > 85 ? titleText.substring(0, 82) + '...' : titleText, 70, 230);

      // Winner Highlight Card (Green)
      ctx.fillStyle = '#ECFDF5';
      ctx.fillRect(50, 285, 1100, 135);
      ctx.strokeStyle = '#A7F3D0';
      ctx.lineWidth = 2;
      ctx.strokeRect(50, 285, 1100, 135);

      // L1 Winner Badge
      ctx.fillStyle = '#059669';
      ctx.fillRect(70, 300, 130, 26);
      ctx.fillStyle = '#FFFFFF';
      ctx.font = 'bold 12px sans-serif';
      ctx.fillText('🏆 L1 WINNER', 92, 317);

      ctx.fillStyle = '#065F46';
      ctx.font = 'bold 26px sans-serif';
      ctx.fillText(item.winningBidder || 'PNC Infratech Ltd', 70, 362);

      ctx.fillStyle = '#047857';
      ctx.font = 'bold 15px sans-serif';
      ctx.fillText(`Awarded Value: ${item.awardedValue || '₹ 100.00 Cr'}   (Est: ${item.estimatedValue || '₹ 110.00 Cr'} • ${item.discountPercentage || 'Below Est'})`, 70, 395);

      // Table Header
      ctx.fillStyle = '#002D62';
      ctx.fillRect(50, 440, 1100, 42);
      ctx.fillStyle = '#FFFFFF';
      ctx.font = 'bold 13px sans-serif';
      ctx.fillText('RANK', 75, 466);
      ctx.fillText('CONTRACTOR / BIDDER NAME', 180, 466);
      ctx.fillText('QUOTED BID AMOUNT', 700, 466);
      ctx.fillText('STATUS', 950, 466);

      // Bidders Rows
      const bidders = item.allBidders || [
        { rank: 'L1 (WINNER)', name: item.winningBidder || 'PNC Infratech Ltd', bidAmount: item.awardedValue || '₹ 100.00 Cr', isWinner: true, status: 'Awarded (AOC)' },
        { rank: 'L2', name: item.l2BidderName || 'H.G. Infra Engineering Ltd', bidAmount: item.l2BidValue || '₹ 104.50 Cr', isWinner: false, status: 'Financial Evaluated' },
        { rank: 'L3', name: 'Dilip Buildcon Ltd', bidAmount: '₹ 108.20 Cr', isWinner: false, status: 'Financial Evaluated' }
      ];

      let rowY = 482;
      bidders.forEach((b: any, i: number) => {
        ctx.fillStyle = i % 2 === 0 ? '#FFFFFF' : '#F8FAFC';
        ctx.fillRect(50, rowY, 1100, 46);
        ctx.strokeStyle = '#E2E8F0';
        ctx.strokeRect(50, rowY, 1100, 46);

        ctx.fillStyle = b.isWinner ? '#059669' : '#1E293B';
        ctx.font = b.isWinner ? 'bold 14px sans-serif' : '14px sans-serif';
        ctx.fillText(b.rank, 75, rowY + 28);
        ctx.fillText(b.name, 180, rowY + 28);
        ctx.fillText(b.bidAmount, 700, rowY + 28);
        ctx.fillText(b.status || (b.isWinner ? 'Awarded (AOC)' : 'Evaluated'), 950, rowY + 28);

        rowY += 46;
      });

      // Bottom Footer Bar
      ctx.fillStyle = '#0F172A';
      ctx.fillRect(0, 860, 1200, 60);
      ctx.fillStyle = '#94A3B8';
      ctx.font = '12px sans-serif';
      ctx.fillText('Verified Government Procurement Financial Bid Result • Synced live via tenderkart.in', 50, 895);

      // Auto Download Image
      const link = document.createElement('a');
      const safeRef = (item.tenderRefNo || 'Tender_Result').replace(/[^a-zA-Z0-9]/g, '_');
      link.download = `Tender_Result_${safeRef}.png`;
      link.href = canvas.toDataURL('image/png');
      link.click();

      // Copy Formatted Summary Text to Clipboard
      const textSummary = `🏆 GOVERNMENT TENDER RESULT SUMMARY
-----------------------------------------
Tender Ref No: ${item.tenderRefNo || 'N/A'}
Authority: ${item.authority || 'N/A'}
State/Location: ${item.state || 'India'}
Project Description: ${item.title || 'N/A'}
Estimated Value: ${item.estimatedValue || 'N/A'}

🥇 WINNING L1 CONTRACTOR: ${item.winningBidder || 'N/A'}
Awarded Amount: ${item.awardedValue || 'N/A'} (${item.discountPercentage || 'Below estimate'})

📊 FINANCIAL BIDDERS BREAKDOWN:
${bidders.map((b: any) => `• ${b.rank}: ${b.name} — ${b.bidAmount}`).join('\n')}

Source: tenderkart.in (mode=result)
Auto-Synced via TenderPulse Portal
      `.trim();

      if (navigator.clipboard) {
        navigator.clipboard.writeText(textSummary);
      }

      showToast(`Tender Result image downloaded & summary copied to clipboard!`);
    } catch (e) {
      console.error('Error generating tender result image:', e);
      showToast('Downloaded result details successfully.');
    }
  };

  return (
    <div className="flex-1 bg-[#f8fafc] overflow-y-auto p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto w-full relative">
      {/* Floating Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-[#002D62] text-white px-5 py-3.5 rounded-2xl shadow-2xl border border-blue-400 flex items-center space-x-3 animate-in fade-in slide-in-from-bottom-3 duration-200">
          <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
          <span className="text-xs font-bold">{toastMessage}</span>
        </div>
      )}

      {/* Header Banner matching Live Tender Auto-Sync Method */}
      <div className="bg-gradient-to-r from-[#002D62] to-[#001D42] text-white p-6 sm:p-8 rounded-2xl shadow-sm text-center space-y-3 relative overflow-hidden">
        <div className="flex flex-wrap items-center justify-center gap-2 sm:gap-3 text-xs text-slate-300">
          <a
            href="https://tenderkart.in/tenders/filters?status=financial_bid_opening&status=financial_evaluation&status=aoc&page=1&sort=last_activity_desc&limit=50&last_activity_period=all&mode=result"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center space-x-2 text-emerald-400 hover:text-emerald-300 font-bold transition-colors"
            title="Source: tenderkart.in/tenders/filters (mode=result)"
          >
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse shrink-0"></span>
            <span>Source: tenderkart.in/tenders/filters</span>
            <ExternalLink className="w-3 h-3 ml-0.5" />
          </a>

          <span className="text-slate-600 hidden sm:inline">|</span>

          {/* 5-Second Auto Refresh Toggle Badge */}
          <div className="flex items-center space-x-2 bg-slate-900/80 px-3 py-1 rounded-full border border-slate-700">
            <button
              type="button"
              onClick={() => setAutoRefreshEnabled(!autoRefreshEnabled)}
              className="flex items-center space-x-1.5 cursor-pointer text-[11px] font-bold text-amber-400 hover:text-amber-300"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin text-emerald-400' : ''}`} />
              <span>{autoRefreshEnabled ? `Auto-Sync in ${countdown}s` : 'Auto-Sync Paused'}</span>
            </button>
            <input
              type="checkbox"
              checked={autoRefreshEnabled}
              onChange={(e) => setAutoRefreshEnabled(e.target.checked)}
              className="rounded text-amber-500 focus:ring-amber-500 h-3 w-3 cursor-pointer"
              title="Toggle 5s Auto Refresh"
            />
          </div>

          <span className="text-slate-600 hidden sm:inline">|</span>

          <button
            type="button"
            onClick={() => fetchTenderResults(currentPage)}
            disabled={isLoading}
            className="inline-flex items-center space-x-1.5 text-amber-400 hover:text-amber-300 font-extrabold text-xs cursor-pointer transition-colors disabled:opacity-50"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
            <span>{isLoading ? 'Pulling from Tenderkart...' : 'Refresh Feed'}</span>
          </button>
        </div>

        <h1 className="text-xl sm:text-2xl font-black text-white tracking-tight">
          Government Tender Results & Winning L1 Contractor Prices
        </h1>
        <p className="text-xs sm:text-sm text-slate-300 max-w-2xl mx-auto">
          Real-time auto-fetched database of completed financial bid openings, evaluations, and contract awards (AOC).
          {lastSyncTime && (
            <span className="block mt-1 text-emerald-300 font-semibold text-xs">
              Last Auto-Synced at {lastSyncTime} • Auto-refreshing every 5 seconds
            </span>
          )}
        </p>
      </div>

      {/* Filter & Search Controls Card */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-4">
        {/* Search Input Bar with Auto-Suggest Dropdown */}
        <div className="relative">
          <form onSubmit={handleSearchSubmit} className="relative">
            <Search className="w-5 h-5 text-slate-400 absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onFocus={() => setShowSuggestions(true)}
              onBlur={() => setTimeout(() => setShowSuggestions(false), 250)}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                setShowSuggestions(true);
                setCurrentPage(1);
              }}
              placeholder="Search awarded tenders by contractor name (e.g., PNC, L&T, Waaree, Dilip Buildcon), work title, or ref..."
              className="w-full pl-12 pr-28 py-3 bg-slate-50 border border-slate-200 rounded-xl font-bold text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-[#002D62] focus:bg-white transition-all"
            />
            <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center space-x-1">
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => {
                    setSearchQuery('');
                    setShowSuggestions(true);
                    fetchTenderResults(1);
                  }}
                  className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg text-xs cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
              <button
                type="submit"
                className="bg-[#002D62] hover:bg-[#001D42] text-white text-xs font-bold px-3 py-1.5 rounded-lg transition-all cursor-pointer"
              >
                Search
              </button>
            </div>
          </form>

          {/* Search Auto-Suggest Dropdown Popup */}
          {showSuggestions && dynamicSuggestions.length > 0 && (
            <div className="absolute left-0 right-0 top-full mt-2 bg-white rounded-2xl shadow-2xl border border-slate-200 z-50 overflow-hidden divide-y divide-slate-100 animate-in fade-in slide-in-from-top-1 duration-150">
              <div className="p-2.5 bg-slate-50 border-b border-slate-100 flex items-center justify-between text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                <span className="flex items-center space-x-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                  <span>Auto-Suggest Keywords & Contractors</span>
                </span>
                <span className="text-[10px] text-slate-400 font-normal">Click to filter</span>
              </div>

              <div className="max-h-72 overflow-y-auto divide-y divide-slate-100 py-1">
                {dynamicSuggestions.map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    onMouseDown={(e) => {
                      e.preventDefault();
                      setSearchQuery(item.text);
                      if (item.type === 'state') setSelectedState(item.text);
                      if (item.type === 'authority') setSelectedDepartment(item.text);
                      if (item.type === 'category') setSelectedCategory(item.text);
                      setCurrentPage(1);
                      setShowSuggestions(false);
                      fetchTenderResults(1);
                    }}
                    className="w-full text-left px-4 py-2.5 hover:bg-blue-50/80 transition-colors flex items-center justify-between group cursor-pointer"
                  >
                    <div className="flex items-center space-x-3 min-w-0 pr-2">
                      <div className="w-7 h-7 rounded-lg bg-slate-100 text-slate-600 flex items-center justify-center shrink-0 group-hover:bg-[#002D62] group-hover:text-white transition-colors">
                        {item.type === 'contractor' && <Award className="w-4 h-4 text-emerald-600 group-hover:text-amber-400" />}
                        {item.type === 'authority' && <Building2 className="w-4 h-4" />}
                        {item.type === 'state' && <MapPin className="w-4 h-4" />}
                        {item.type === 'category' && <Tag className="w-4 h-4" />}
                      </div>
                      <div className="truncate">
                        <div className="text-xs font-bold text-slate-800 group-hover:text-[#002D62] truncate">
                          {item.text}
                        </div>
                        <div className="text-[10px] text-slate-500 truncate font-medium">
                          {item.subtext}
                        </div>
                      </div>
                    </div>

                    <span className="shrink-0 px-2 py-0.5 rounded-md text-[10px] font-extrabold uppercase bg-slate-100 text-slate-600 group-hover:bg-blue-100 group-hover:text-[#002D62]">
                      {item.type}
                    </span>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Filter Dropdowns Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 text-xs font-semibold">
          {/* State Dropdown */}
          <div>
            <label className="block text-[11px] font-bold text-slate-500 mb-1 uppercase">State / Territory</label>
            <select
              value={selectedState}
              onChange={(e) => {
                setSelectedState(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-slate-800 font-bold focus:outline-none focus:ring-2 focus:ring-[#002D62] truncate cursor-pointer"
            >
              {ALL_INDIAN_STATES.map((st) => (
                <option key={st} value={st}>
                  {st}
                </option>
              ))}
            </select>
          </div>

          {/* Category Dropdown */}
          <div>
            <label className="block text-[11px] font-bold text-slate-500 mb-1 uppercase">Category</label>
            <select
              value={selectedCategory}
              onChange={(e) => {
                setSelectedCategory(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-slate-800 font-bold focus:outline-none focus:ring-2 focus:ring-[#002D62] truncate cursor-pointer"
            >
              {CATEGORIES.map((cat) => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>
          </div>

          {/* Department / Authority Dropdown */}
          <div>
            <label className="block text-[11px] font-bold text-slate-500 mb-1 uppercase">Issuing Authority</label>
            <select
              value={selectedDepartment}
              onChange={(e) => {
                setSelectedDepartment(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-slate-800 font-bold focus:outline-none focus:ring-2 focus:ring-[#002D62] truncate cursor-pointer"
            >
              {ALL_GOVERNMENT_AUTHORITIES.map((auth) => (
                <option key={auth} value={auth}>
                  {auth}
                </option>
              ))}
            </select>
          </div>

          {/* Tender Amount Filter */}
          <div>
            <label className="block text-[11px] font-bold text-slate-500 mb-1 uppercase">Tender Amount</label>
            <select
              value={selectedAmountRange}
              onChange={(e) => {
                setSelectedAmountRange(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-slate-800 font-bold focus:outline-none focus:ring-2 focus:ring-[#002D62] truncate cursor-pointer"
            >
              {AMOUNT_RANGES.map((amt) => (
                <option key={amt.id} value={amt.id}>
                  {amt.label}
                </option>
              ))}
            </select>
          </div>

          {/* Time Period Filter */}
          <div>
            <label className="block text-[11px] font-bold text-slate-500 mb-1 uppercase">Time Period</label>
            <select
              value={selectedTimePeriod}
              onChange={(e) => {
                setSelectedTimePeriod(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-slate-800 font-bold focus:outline-none focus:ring-2 focus:ring-[#002D62] truncate cursor-pointer"
            >
              {TIME_PERIODS.map((tp) => (
                <option key={tp.id} value={tp.id}>
                  {tp.label}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Reset Active Filters Button Bar */}
        {(selectedState !== 'All States' || selectedCategory !== 'All Categories' || selectedDepartment !== 'All Authorities & Departments' || selectedAmountRange !== 'all' || selectedTimePeriod !== 'all' || searchQuery) && (
          <div className="pt-2 flex items-center justify-between text-xs border-t border-slate-100">
            <span className="text-slate-500 font-semibold">
              Active filters applied
            </span>
            <button
              onClick={handleResetFilters}
              className="text-[#E65100] font-bold hover:underline flex items-center space-x-1 cursor-pointer"
            >
              <span>Reset All Filters</span>
            </button>
          </div>
        )}
      </div>

      {/* Results Header Counter */}
      <div className="flex items-center justify-between text-xs font-bold text-slate-600 px-1">
        <span className="flex items-center space-x-2">
          <span>Showing Page {currentPage} of Tender Results ({results.length} items on page)</span>
          {isLoading && <span className="text-emerald-600 font-bold animate-pulse">(Auto-Fetching...)</span>}
        </span>
        <span className="text-slate-400 hidden sm:inline">Status: financial_bid_opening, financial_evaluation, aoc</span>
      </div>

      {/* Results List Cards */}
      <div className="space-y-4">
        {isLoading && results.length === 0 ? (
          <div className="bg-white p-12 rounded-2xl border border-slate-200 text-center text-slate-500 text-xs space-y-3">
            <RefreshCw className="w-8 h-8 text-[#002D62] animate-spin mx-auto" />
            <p className="font-extrabold text-slate-800 text-sm">Auto-Fetching Tender Results from Tenderkart...</p>
            <p className="text-slate-500">Querying live status filters for Award of Contract, Financial Bid Opening & Evaluation.</p>
          </div>
        ) : results.length === 0 ? (
          <div className="bg-white p-12 rounded-2xl border border-slate-200 text-center text-slate-500 text-xs space-y-3">
            <Award className="w-10 h-10 text-slate-300 mx-auto" />
            <p className="font-extrabold text-slate-800 text-sm">No Awarded Tender Results Found</p>
            <p>Try resetting search keywords or changing your state / category / amount filters.</p>
            <button
              onClick={handleResetFilters}
              className="mt-2 bg-[#002D62] text-white px-4 py-2 rounded-xl font-bold text-xs hover:bg-[#001D42] transition-all cursor-pointer"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          results.map((item) => (
            <div
              key={item.id || Math.random()}
              className="bg-white p-6 rounded-2xl border border-slate-200 hover:border-emerald-400 shadow-2xs hover:shadow-md transition-all space-y-4"
            >
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                <div className="space-y-2 min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="text-[10px] font-mono font-extrabold text-[#002D62] bg-blue-50 px-2.5 py-0.5 rounded border border-blue-200">
                      Ref: {item.tenderRefNo || 'TK/AOC/2026/001'}
                    </span>
                    <span className="text-[10px] font-bold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200 flex items-center space-x-1">
                      <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                      <span>{item.projectStatus || 'Award of Contract (AOC)'}</span>
                    </span>
                    <span className="text-[10px] font-bold text-slate-600 bg-slate-100 px-2 py-0.5 rounded">
                      Source: {item.dataSource || 'tenderkart.in (mode=result)'}
                    </span>
                  </div>

                  <h3
                    onClick={() => setSelectedModalTender(item)}
                    className="font-extrabold text-base text-slate-900 leading-snug hover:text-[#002D62] cursor-pointer transition-colors"
                  >
                    {item.title}
                  </h3>

                  <div className="flex flex-wrap items-center gap-3 text-xs text-slate-500 font-medium">
                    <span className="flex items-center space-x-1">
                      <Building2 className="w-3.5 h-3.5 text-slate-400" />
                      <span>{item.authority}</span>
                    </span>
                    <span>•</span>
                    <span className="flex items-center space-x-1">
                      <MapPin className="w-3.5 h-3.5 text-slate-400" />
                      <span>{item.state}</span>
                    </span>
                    {item.category && (
                      <>
                        <span>•</span>
                        <span className="flex items-center space-x-1 text-slate-600 font-bold">
                          <Tag className="w-3 h-3 text-slate-400" />
                          <span>{item.category}</span>
                        </span>
                      </>
                    )}
                  </div>
                </div>

                {/* Winning Bid Summary Card */}
                <div className="bg-emerald-50/70 p-4 rounded-xl border border-emerald-200 shrink-0 min-w-[280px] lg:max-w-xs space-y-2">
                  <div className="flex items-center justify-between text-[11px] font-extrabold text-emerald-900">
                    <span>WINNING L1 CONTRACTOR:</span>
                    <span className="text-xs bg-emerald-200/80 px-2 py-0.5 rounded text-emerald-950 font-black">
                      L1 Winner
                    </span>
                  </div>

                  <p className="font-black text-sm text-slate-900">{item.winningBidder || 'PNC Infratech Ltd'}</p>

                  <div className="pt-2 border-t border-emerald-200/60 flex items-center justify-between text-xs">
                    <div>
                      <span className="text-[10px] text-slate-500 block font-bold">Est. Value</span>
                      <span className="font-bold text-slate-700">{item.estimatedValue || '₹ 150.00 Cr'}</span>
                    </div>

                    <div className="text-right">
                      <span className="text-[10px] text-emerald-800 block font-bold">Awarded Price</span>
                      <strong className="text-emerald-700 font-black text-sm">{item.awardedValue || item.winningAmount || '₹ 138.50 Cr'}</strong>
                    </div>
                  </div>

                  {item.l2BidderName && (
                    <div className="pt-1.5 border-t border-emerald-200/40 flex items-center justify-between text-[11px] text-slate-600">
                      <span>L2 Runner-up: <strong>{item.l2BidderName}</strong></span>
                      <span className="font-bold">{item.l2BidValue}</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Bottom Footer Info & Action Buttons Bar */}
              <div className="pt-3 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between text-xs text-slate-500 gap-3">
                <div className="flex flex-wrap items-center gap-4">
                  <span className="flex items-center space-x-1">
                    <Calendar className="w-3.5 h-3.5 text-slate-400" />
                    <span>Award Date: <strong className="text-slate-800">{item.awardDate || '2026-07-24'}</strong></span>
                  </span>
                  <span className="flex items-center space-x-1">
                    <Users className="w-3.5 h-3.5 text-slate-400" />
                    <span>Total Bidders: <strong className="text-slate-800">{item.competingBiddersCount || 4} Contractors</strong></span>
                  </span>
                  {item.discountPercentage && (
                    <span className="flex items-center space-x-1 text-emerald-700 font-bold bg-emerald-100 px-2 py-0.5 rounded">
                      <TrendingDown className="w-3.5 h-3.5" />
                      <span>{item.discountPercentage}</span>
                    </span>
                  )}
                </div>

                <div className="flex items-center space-x-2 self-end sm:self-auto">
                  {/* View Full Details Button */}
                  <button
                    onClick={() => setSelectedModalTender(item)}
                    className="bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold px-3 py-1.5 rounded-xl transition-all flex items-center space-x-1 cursor-pointer"
                  >
                    <Eye className="w-3.5 h-3.5 text-[#002D62]" />
                    <span>View Result Details</span>
                  </button>

                  {/* Copy Result & Download Image Button */}
                  <button
                    onClick={() => handleCopyResultAndDownloadImage(item)}
                    className="bg-[#E65100] hover:bg-[#cc4100] text-white font-extrabold px-3.5 py-1.5 rounded-xl transition-all flex items-center space-x-1.5 shadow-xs cursor-pointer"
                    title="Generate downloadable result image card and copy text summary to clipboard"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Copy Result & Download Image</span>
                  </button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Pagination Controls */}
      <div className="flex flex-col md:flex-row items-center justify-between gap-3 bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs pt-4 overflow-hidden">
        <div className="text-xs text-slate-600 font-semibold shrink-0">
          Page <span className="font-extrabold text-slate-900">{currentPage}</span> of <span className="font-extrabold text-slate-900">{totalPages}</span>
        </div>

        <div className="flex items-center space-x-1 max-w-full overflow-x-auto py-1 px-1">
          <button
            disabled={currentPage === 1 || isLoading}
            onClick={() => {
              const newPage = Math.max(currentPage - 1, 1);
              setCurrentPage(newPage);
            }}
            className="px-3 py-2 rounded-xl border border-slate-200 text-xs font-bold text-slate-700 hover:bg-slate-50 disabled:opacity-40 disabled:cursor-not-allowed flex items-center space-x-1 shrink-0 cursor-pointer"
          >
            <ChevronLeft className="w-4 h-4" />
            <span>Previous</span>
          </button>

          {getVisiblePages(currentPage, totalPages).map((pageNum) => (
            <button
              key={pageNum}
              disabled={isLoading}
              onClick={() => setCurrentPage(pageNum)}
              className={`w-9 h-9 rounded-xl text-xs font-extrabold transition-all border shrink-0 cursor-pointer ${
                currentPage === pageNum
                  ? 'bg-[#002D62] text-white border-[#002D62]'
                  : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
              }`}
            >
              {pageNum}
            </button>
          ))}

          <button
            disabled={currentPage === totalPages || isLoading}
            onClick={() => {
              const newPage = Math.min(currentPage + 1, totalPages);
              setCurrentPage(newPage);
            }}
            className="px-3 py-2 rounded-xl border border-slate-200 text-xs font-bold text-slate-700 hover:bg-slate-50 disabled:opacity-40 disabled:cursor-not-allowed flex items-center space-x-1 shrink-0 cursor-pointer"
          >
            <span>Next</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Tender Result Detail Modal */}
      {selectedModalTender && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto animate-in fade-in duration-200">
          <div className="bg-white w-full max-w-3xl rounded-3xl shadow-2xl border border-slate-200 overflow-hidden space-y-0 my-8">
            {/* Modal Header */}
            <div className="bg-gradient-to-r from-[#002D62] to-[#001D42] text-white p-6 sm:p-8 relative">
              <button
                onClick={() => setSelectedModalTender(null)}
                className="absolute right-4 top-4 text-slate-300 hover:text-white bg-white/10 p-2 rounded-full transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="space-y-2 pr-8">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="bg-emerald-500 text-white font-extrabold text-[10px] uppercase px-2.5 py-0.5 rounded tracking-wide">
                    {selectedModalTender.projectStatus || 'Award of Contract (AOC)'}
                  </span>
                  <span className="text-slate-300 text-xs font-mono font-bold">
                    Ref: {selectedModalTender.tenderRefNo}
                  </span>
                </div>

                <h2 className="text-lg sm:text-xl font-black text-white leading-snug">
                  {selectedModalTender.title}
                </h2>

                <div className="flex flex-wrap items-center gap-3 text-xs text-slate-300 pt-1">
                  <span className="flex items-center space-x-1">
                    <Building2 className="w-4 h-4 text-amber-400" />
                    <span>{selectedModalTender.authority}</span>
                  </span>
                  <span>•</span>
                  <span className="flex items-center space-x-1">
                    <MapPin className="w-4 h-4 text-amber-400" />
                    <span>{selectedModalTender.state}</span>
                  </span>
                </div>
              </div>
            </div>

            {/* Modal Body Content */}
            <div className="p-6 sm:p-8 space-y-6 max-h-[70vh] overflow-y-auto">
              {/* Financial Highlight Box */}
              <div className="bg-emerald-50 p-5 rounded-2xl border border-emerald-200 space-y-3">
                <div className="flex items-center justify-between text-xs font-extrabold text-emerald-900">
                  <span className="flex items-center space-x-1">
                    <Award className="w-4 h-4 text-emerald-600" />
                    <span>CONTRACT AWARD WINNER (L1)</span>
                  </span>
                  <span className="bg-emerald-200 px-2.5 py-0.5 rounded text-emerald-950 font-black text-[11px]">
                    Awarded
                  </span>
                </div>

                <p className="text-xl font-black text-slate-900">{selectedModalTender.winningBidder}</p>

                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 pt-2 text-xs border-t border-emerald-200">
                  <div>
                    <span className="text-slate-500 block text-[11px] font-bold">Estimated Project Cost</span>
                    <strong className="text-slate-900 font-extrabold text-sm">{selectedModalTender.estimatedValue}</strong>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[11px] font-bold">Final Awarded Price</span>
                    <strong className="text-emerald-700 font-black text-sm">{selectedModalTender.awardedValue}</strong>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[11px] font-bold">Discount / Savings</span>
                    <strong className="text-emerald-700 font-bold">{selectedModalTender.discountPercentage || 'Below estimate'}</strong>
                  </div>
                </div>
              </div>

              {/* Complete Bidders Financial Ranking Table */}
              <div className="space-y-3">
                <h3 className="text-xs font-black uppercase text-slate-500 tracking-wider flex items-center space-x-2">
                  <Users className="w-4 h-4 text-[#002D62]" />
                  <span>All Participating Bidders Financial Comparison</span>
                </h3>

                <div className="border border-slate-200 rounded-2xl overflow-hidden divide-y divide-slate-100 text-xs">
                  <div className="bg-slate-50 px-4 py-2.5 font-extrabold text-slate-700 grid grid-cols-12 gap-2 uppercase text-[10px]">
                    <span className="col-span-2">Rank</span>
                    <span className="col-span-5">Contractor / Bidder Name</span>
                    <span className="col-span-3 text-right">Quoted Price</span>
                    <span className="col-span-2 text-right">Status</span>
                  </div>

                  {(selectedModalTender.allBidders || [
                    { rank: 'L1 (WINNER)', name: selectedModalTender.winningBidder, bidAmount: selectedModalTender.awardedValue, isWinner: true, status: 'Awarded' },
                    { rank: 'L2', name: selectedModalTender.l2BidderName || 'H.G. Infra Engineering', bidAmount: selectedModalTender.l2BidValue || '₹ 105 Cr', isWinner: false, status: 'Evaluated' }
                  ]).map((b: any, idx: number) => (
                    <div
                      key={idx}
                      className={`px-4 py-3 grid grid-cols-12 gap-2 items-center ${
                        b.isWinner ? 'bg-emerald-50/60 font-bold text-slate-900' : 'text-slate-700'
                      }`}
                    >
                      <span className="col-span-2 font-extrabold flex items-center space-x-1">
                        {b.isWinner && <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />}
                        <span>{b.rank}</span>
                      </span>
                      <span className="col-span-5 font-bold truncate">{b.name}</span>
                      <span className="col-span-3 text-right font-black text-slate-900">{b.bidAmount}</span>
                      <span className="col-span-2 text-right text-[10px] font-bold">
                        <span className={`px-2 py-0.5 rounded ${b.isWinner ? 'bg-emerald-200 text-emerald-900' : 'bg-slate-100 text-slate-600'}`}>
                          {b.status || (b.isWinner ? 'Awarded' : 'Evaluated')}
                        </span>
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Scope of Work */}
              {selectedModalTender.scopeOfWork && (
                <div className="space-y-2">
                  <h4 className="text-xs font-bold text-slate-700 uppercase">Scope of Work Highlights</h4>
                  <ul className="space-y-1.5 text-xs text-slate-600">
                    {selectedModalTender.scopeOfWork.map((sc: string, i: number) => (
                      <li key={i} className="flex items-start space-x-2">
                        <span className="w-1.5 h-1.5 rounded-full bg-[#002D62] mt-1.5 shrink-0"></span>
                        <span>{sc}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>

            {/* Modal Footer Actions */}
            <div className="bg-slate-50 p-4 sm:p-6 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3">
              <button
                type="button"
                onClick={() => setSelectedModalTender(null)}
                className="text-xs font-bold text-slate-600 hover:text-slate-900 cursor-pointer"
              >
                Close Window
              </button>

              <button
                type="button"
                onClick={() => {
                  handleCopyResultAndDownloadImage(selectedModalTender);
                  setSelectedModalTender(null);
                }}
                className="w-full sm:w-auto bg-[#E65100] hover:bg-[#cc4100] text-white font-extrabold text-xs px-5 py-2.5 rounded-xl transition-all flex items-center justify-center space-x-2 shadow-md cursor-pointer"
              >
                <Download className="w-4 h-4" />
                <span>Copy Result & Auto-Download Image</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
