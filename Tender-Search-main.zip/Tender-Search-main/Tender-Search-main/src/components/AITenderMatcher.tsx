import React, { useState } from 'react';
import { AITenderMatchResult } from '../types';
import {
  Sparkles,
  Building2,
  IndianRupee,
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  RefreshCw,
  Award,
  FileCheck
} from 'lucide-react';

export const AITenderMatcher: React.FC = () => {
  const [companyName, setCompanyName] = useState('');
  const [annualTurnoverLakhs, setAnnualTurnoverLakhs] = useState<number>(250);
  const [pastProjectValueLakhs, setPastProjectValueLakhs] = useState<number>(120);
  const [productKeywords, setProductKeywords] = useState('Civil Construction, Road Repair, Drainage');
  const [hasMSMERegistration, setHasMSMERegistration] = useState(true);

  const [isLoading, setIsLoading] = useState(false);
  const [matchResult, setMatchResult] = useState<AITenderMatchResult | null>(null);

  const handleRunMatcher = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      const res = await fetch('/api/match', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          companyName: companyName || 'Contractor Enterprise',
          annualTurnoverLakhs,
          pastProjectValueLakhs,
          productKeywords,
          hasMSMERegistration
        })
      });
      const data = await res.json();
      setMatchResult(data);
    } catch (err) {
      console.error('Failed to run AI Matcher:', err);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex-1 bg-[#f8fafc] overflow-y-auto p-4 sm:p-6 lg:p-8 space-y-8">
      {/* Header Banner */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-2xs space-y-2">
        <div className="flex items-center space-x-2 text-[#002D62] font-extrabold text-xs uppercase tracking-wider">
          <Sparkles className="w-4 h-4 text-amber-500" />
          <span>Gemini 3.6 Flash Intelligence Model</span>
        </div>
        <h1 className="text-2xl font-black text-slate-900 tracking-tight">
          AI Contractor Capabilities & Tender Qualification Matcher
        </h1>
        <p className="text-xs sm:text-sm text-slate-500">
          Input your company turnover, past single work value, and sector experience to discover your highest win-rate government tenders and MSME EMD exemptions.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Form Inputs */}
        <div className="lg:col-span-5 bg-white p-6 rounded-2xl border border-slate-200 shadow-2xs space-y-4">
          <h2 className="font-extrabold text-base text-slate-900 flex items-center space-x-2">
            <Building2 className="w-5 h-5 text-[#002D62]" />
            <span>Enter Company Credentials</span>
          </h2>

          <form onSubmit={handleRunMatcher} className="space-y-4 text-xs font-semibold">
            <div>
              <label className="block text-slate-800 mb-1">Company / Firm Name</label>
              <input
                type="text"
                value={companyName}
                onChange={(e) => setCompanyName(e.target.value)}
                placeholder="e.g. Apex Infra Engineers Pvt Ltd"
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-[#002D62] text-slate-900 font-bold"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-800 mb-1">Annual Turnover (₹ Lakhs)</label>
                <input
                  type="number"
                  required
                  value={annualTurnoverLakhs}
                  onChange={(e) => setAnnualTurnoverLakhs(Number(e.target.value))}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-[#002D62] text-slate-900 font-bold"
                />
              </div>

              <div>
                <label className="block text-slate-800 mb-1">Max Past Work (₹ Lakhs)</label>
                <input
                  type="number"
                  required
                  value={pastProjectValueLakhs}
                  onChange={(e) => setPastProjectValueLakhs(Number(e.target.value))}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-[#002D62] text-slate-900 font-bold"
                />
              </div>
            </div>

            <div>
              <label className="block text-slate-800 mb-1">Product & Work Keywords</label>
              <input
                type="text"
                value={productKeywords}
                onChange={(e) => setProductKeywords(e.target.value)}
                placeholder="e.g. Solar, Laptops, Civil Repair, Security, Housekeeping"
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-[#002D62] text-slate-900 font-bold"
              />
            </div>

            <label className="flex items-center space-x-2 bg-slate-50 p-3 rounded-xl border border-slate-200 cursor-pointer">
              <input
                type="checkbox"
                checked={hasMSMERegistration}
                onChange={(e) => setHasMSMERegistration(e.target.checked)}
                className="rounded text-[#E65100] focus:ring-[#E65100]"
              />
              <span className="text-slate-800 font-bold">Has Valid Udyam MSME / NSIC Registration</span>
            </label>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full bg-[#002D62] hover:bg-[#001D42] text-white font-extrabold text-sm py-3 rounded-xl flex items-center justify-center space-x-2 transition-all shadow-md"
            >
              {isLoading ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin text-amber-400" />
                  <span>AI Calculating Qualification...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 text-amber-400" />
                  <span>Calculate Win Probability</span>
                </>
              )}
            </button>
          </form>
        </div>

        {/* AI Results Output */}
        <div className="lg:col-span-7 space-y-4">
          {isLoading ? (
            <div className="bg-white p-12 rounded-2xl border border-slate-200 text-center space-y-4">
              <RefreshCw className="w-10 h-10 text-[#002D62] animate-spin mx-auto" />
              <p className="text-xs text-slate-600 font-semibold">
                Gemini AI matching your turnover and past project experience against 150,000+ active tender specifications...
              </p>
            </div>
          ) : matchResult ? (
            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-2xs space-y-6 animate-in fade-in">
              {/* Header Score Banner */}
              <div className="bg-gradient-to-r from-[#002D62] to-[#001D42] text-white p-5 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <span className="text-[10px] uppercase font-black text-amber-300 tracking-wider block">
                    AI Qualification Assessment
                  </span>
                  <h3 className="text-xl font-extrabold text-white mt-0.5">{companyName || 'Contractor Firm'}</h3>
                  <p className="text-xs text-slate-300 mt-1">
                    Evaluated under Central Public Procurement Rules & GFR 2017
                  </p>
                </div>

                <div className="flex items-center space-x-3 shrink-0">
                  <div className="text-right">
                    <span className="text-[10px] uppercase font-bold text-slate-300 block">Eligibility Score</span>
                    <span className="text-3xl font-black text-amber-400">{matchResult.overallEligibilityScore}/100</span>
                  </div>
                </div>
              </div>

              {/* Summary text */}
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 text-xs text-slate-800 leading-relaxed font-medium">
                {matchResult.summary}
              </div>

              {/* Strengths & Bottlenecks Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                {/* Strengths */}
                <div className="bg-emerald-50/60 border border-emerald-200 p-4 rounded-xl space-y-2">
                  <h4 className="font-extrabold text-emerald-900 flex items-center space-x-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    <span>Primary Bidding Advantages</span>
                  </h4>
                  <ul className="space-y-1.5 text-emerald-950 font-medium list-disc list-inside">
                    {matchResult.keyStrengths?.map((s, i) => (
                      <li key={i}>{s}</li>
                    ))}
                  </ul>
                </div>

                {/* Bottlenecks */}
                <div className="bg-amber-50/60 border border-amber-200 p-4 rounded-xl space-y-2">
                  <h4 className="font-extrabold text-amber-900 flex items-center space-x-1.5">
                    <AlertTriangle className="w-4 h-4 text-amber-600" />
                    <span>Watch Points & Conditions</span>
                  </h4>
                  <ul className="space-y-1.5 text-amber-950 font-medium list-disc list-inside">
                    {matchResult.potentialBottlenecks?.map((b, i) => (
                      <li key={i}>{b}</li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Actionable Steps */}
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-2 text-xs">
                <h4 className="font-extrabold text-slate-900 flex items-center space-x-2">
                  <Award className="w-4 h-4 text-[#E65100]" />
                  <span>Recommended Tender Bidding Strategy</span>
                </h4>
                <ul className="space-y-2 text-slate-800 font-medium">
                  {matchResult.actionableSteps?.map((step, idx) => (
                    <li key={idx} className="flex items-start space-x-2 bg-white p-2.5 rounded-lg border border-slate-200">
                      <span className="w-5 h-5 rounded-full bg-[#002D62] text-white font-bold text-[10px] flex items-center justify-center shrink-0 mt-0.5">
                        {idx + 1}
                      </span>
                      <span>{step}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          ) : (
            <div className="bg-white p-12 rounded-2xl border border-slate-200 text-center text-slate-500 text-xs space-y-2">
              <Sparkles className="w-8 h-8 text-amber-500 mx-auto" />
              <p className="font-bold text-slate-800 text-sm">Ready to Analyze Contractor Qualification</p>
              <p>Fill in your firm details on the left and click 'Calculate Win Probability'.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
