import React, { useState } from 'react';
import { TenderItem, CategoryType, DateRangeType, ProjectStatusType, TenderNote } from '../types';
import { ALL_INDIAN_STATES, ALL_GOVERNMENT_AUTHORITIES } from '../data/mockData';
import { StateLandmarkIcon } from './StateLandmarkIcon';
import {
  Search,
  Building2,
  Calendar,
  Clock,
  FileText,
  Sparkles,
  Download,
  Bookmark,
  MapPin,
  RefreshCw,
  AlertCircle,
  Database,
  Plus,
  StickyNote,
  ChevronLeft,
  ChevronRight,
  Users,
  CheckCircle,
  Tag,
  X,
  ShieldCheck,
  HardHat,
  Stethoscope,
  Laptop,
  BookOpen,
  Sun,
  Camera,
  Droplet,
  Zap,
  Recycle,
  Bus,
  Printer,
  Building,
  Landmark,
  Compass,
  Globe,
  ArrowRight,
  ExternalLink
} from 'lucide-react';

interface LiveTendersSearchProps {
  tenders: TenderItem[];
  savedTenderIds: string[];
  onToggleSaveTender: (id: string) => void;
  onOpenTenderDetails: (tender: TenderItem) => void;
  onRunAISearch: (query: string) => void;
  isAISearching: boolean;
  aiSearchSummary: string | null;
  homeResetTrigger?: number;
  onSyncLiveTenders?: (filterParams?: { q?: string; state?: string; category?: string; department?: string; page?: number; mode?: 'live' | 'result' }) => void;
  isSyncingPortals?: boolean;
  lastSyncTime?: string | null;
}

export const LiveTendersSearch: React.FC<LiveTendersSearchProps> = ({
  tenders,
  savedTenderIds,
  onToggleSaveTender,
  onOpenTenderDetails,
  onRunAISearch,
  isAISearching,
  aiSearchSummary,
  homeResetTrigger,
  onSyncLiveTenders,
  isSyncingPortals,
  lastSyncTime
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedState, setSelectedState] = useState<string>('All States');
  const [selectedCategory, setSelectedCategory] = useState<CategoryType>('All Categories');
  const [selectedDepartment, setSelectedDepartment] = useState<string>('All Authorities & Departments');
  const [dateRange, setDateRange] = useState<DateRangeType>('all');
  const [projectStatusFilter, setProjectStatusFilter] = useState<ProjectStatusType>('All Statuses');
  const [msmeExemptionOnly, setMsmeExemptionOnly] = useState(false);
  const [minValueLakhs, setMinValueLakhs] = useState<number>(0);

  // Reset Home state on logo click trigger
  React.useEffect(() => {
    if (homeResetTrigger && homeResetTrigger > 0) {
      setSearchQuery('');
      setSelectedState('All States');
      setSelectedCategory('All Categories');
      setSelectedDepartment('All Authorities & Departments');
      setDateRange('all');
      setProjectStatusFilter('All Statuses');
      setMsmeExemptionOnly(false);
      setMinValueLakhs(0);
      setCurrentPage(1);
      setHasSearched(false);
      setShowSuggestions(false);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  }, [homeResetTrigger]);

  // Pagination State
  const [currentPage, setCurrentPage] = useState<number>(1);
  const itemsPerPage = 5;

  // Search execution state (hide tender details on home page until search is triggered)
  const [hasSearched, setHasSearched] = useState(false);

  // Auto-suggestions dropdown visibility state
  const [showSuggestions, setShowSuggestions] = useState(false);

  // Tender Notes State: Record<tenderId, TenderNote[]>
  const [tenderNotesMap, setTenderNotesMap] = useState<Record<string, TenderNote[]>>({
    'tk-1001': [
      { id: 'n1', tenderId: 'tk-1001', noteNumber: 1, text: 'Checked eligibility for Class I Railway registration. Joint Venture allowed.', createdAt: '2026-07-22 10:15 AM' }
    ],
    'tk-1002': [
      { id: 'n2', tenderId: 'tk-1002', noteNumber: 1, text: 'MSME EMD exemption is applicable. Need to upload Udyam registration certificate.', createdAt: '2026-07-21 02:30 PM' }
    ]
  });

  // Active note composer state
  const [activeNoteComposerTenderId, setActiveNoteComposerTenderId] = useState<string | null>(null);
  const [noteInputText, setNoteInputText] = useState('');

  const categoriesList: CategoryType[] = [
    'All Categories',
    'Civil & Construction',
    'Electrical & Power',
    'IT, Software & Telecom',
    'Solar & Renewable Energy',
    'Medical, Pharma & Healthcare',
    'Transport, Freight & Vehicles',
    'Security, Facility & Manpower',
    'Machinery & Industrial Goods'
  ];

  // Quick Search Suggestions
  const searchSuggestions = [
    'Solar',
    'Road & Highways',
    'Account & Auditing',
    'Civil Construction',
    'Medical Equipment',
    'Manpower & Facility',
    'Railways Bridge',
    'GeM Supply'
  ];

  // 1. Keywords Discovery
  const DISCOVERY_KEYWORDS = [
    {
      title: 'Road construction',
      category: 'Infrastructure',
      searchTerm: 'Road construction',
      svg: (
        <svg className="w-9 h-9" viewBox="0 0 64 64" fill="none">
          <rect x="8" y="32" width="48" height="24" rx="4" fill="#374151" />
          <path d="M20 44H28M36 44H44" stroke="#FBBF24" strokeWidth="4" strokeLinecap="round" />
          <path d="M24 16L32 8L40 16" stroke="#10B981" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M12 32L32 16L52 32" stroke="#F59E0B" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      )
    },
    {
      title: 'Medical equipment',
      category: 'Healthcare',
      searchTerm: 'Medical equipment',
      svg: (
        <svg className="w-9 h-9" viewBox="0 0 64 64" fill="none">
          <rect x="16" y="16" width="32" height="40" rx="4" fill="#EF4444" />
          <rect x="22" y="22" width="20" height="20" rx="2" fill="#FFFFFF" />
          <path d="M32 26V38M26 32H38" stroke="#EF4444" strokeWidth="4" strokeLinecap="round" />
        </svg>
      )
    },
    {
      title: 'Software procurement',
      category: 'Technology',
      searchTerm: 'Software',
      svg: (
        <svg className="w-9 h-9" viewBox="0 0 64 64" fill="none">
          <rect x="12" y="14" width="40" height="28" rx="3" fill="#1F2937" />
          <rect x="16" y="18" width="32" height="20" rx="1" fill="#111827" />
          <path d="M20 28L25 24L20 20M27 28H32" stroke="#10B981" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M8 48H56" stroke="#4B5563" strokeWidth="4" strokeLinecap="round" />
        </svg>
      )
    },
    {
      title: 'School furniture',
      category: 'Education',
      searchTerm: 'Furniture',
      svg: (
        <svg className="w-9 h-9" viewBox="0 0 64 64" fill="none">
          <rect x="16" y="14" width="32" height="12" rx="2" fill="#F97316" />
          <rect x="16" y="28" width="32" height="12" rx="2" fill="#3B82F6" />
          <rect x="16" y="42" width="32" height="12" rx="2" fill="#10B981" />
        </svg>
      )
    },
    {
      title: 'Solar panels',
      category: 'Energy',
      searchTerm: 'Solar',
      svg: (
        <svg className="w-9 h-9" viewBox="0 0 64 64" fill="none">
          <circle cx="32" cy="32" r="14" fill="#F59E0B" />
          <path d="M32 6V12M32 52V58M6 32H12M52 32H58M14 14L18 18M46 46L50 50M14 50L18 46M46 18L50 14" stroke="#F59E0B" strokeWidth="4" strokeLinecap="round" />
        </svg>
      )
    },
    {
      title: 'CCTV cameras',
      category: 'Security',
      searchTerm: 'CCTV',
      svg: (
        <svg className="w-9 h-9" viewBox="0 0 64 64" fill="none">
          <rect x="18" y="20" width="28" height="20" rx="4" fill="#4B5563" />
          <circle cx="32" cy="30" r="6" fill="#111827" />
          <circle cx="32" cy="30" r="3" fill="#38BDF8" />
          <path d="M46 26L56 22V38L46 34" fill="#374151" />
        </svg>
      )
    },
    {
      title: 'Water supply',
      category: 'Utilities',
      searchTerm: 'Water',
      svg: (
        <svg className="w-9 h-9" viewBox="0 0 64 64" fill="none">
          <path d="M32 10C32 10 16 28 16 40C16 48.8366 23.1634 56 32 56C40.8366 56 48 48.8366 48 40C48 28 32 10 32 10Z" fill="#0EA5E9" />
          <path d="M26 38C26 38 28 44 34 44" stroke="#E0F2FE" strokeWidth="3" strokeLinecap="round" />
        </svg>
      )
    },
    {
      title: 'Building materials',
      category: 'Construction',
      searchTerm: 'Construction',
      svg: (
        <svg className="w-9 h-9" viewBox="0 0 64 64" fill="none">
          <path d="M12 48H52V52H12V48Z" fill="#374151" />
          <path d="M32 12V48M32 12L48 24H20" stroke="#EF4444" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" />
          <rect x="36" y="28" width="12" height="12" fill="#F59E0B" />
        </svg>
      )
    },
    {
      title: 'Electrical work',
      category: 'Electrical',
      searchTerm: 'Electrical',
      svg: (
        <svg className="w-9 h-9" viewBox="0 0 64 64" fill="none">
          <path d="M36 8L16 34H32L28 56L48 30H32L36 8Z" fill="#F59E0B" stroke="#D97706" strokeWidth="2" strokeLinejoin="round" />
        </svg>
      )
    },
    {
      title: 'Waste management',
      category: 'Environment',
      searchTerm: 'Waste',
      svg: (
        <svg className="w-9 h-9" viewBox="0 0 64 64" fill="none">
          <path d="M32 12L40 24H24L32 12Z" fill="#10B981" />
          <path d="M48 36L40 48L32 36H48Z" fill="#059669" />
          <path d="M16 36H32L24 48L16 36Z" fill="#047857" />
        </svg>
      )
    },
    {
      title: 'Transport vehicles',
      category: 'Transport',
      searchTerm: 'Transport',
      svg: (
        <svg className="w-9 h-9" viewBox="0 0 64 64" fill="none">
          <rect x="12" y="20" width="40" height="24" rx="4" fill="#0EA5E9" />
          <rect x="16" y="24" width="10" height="10" rx="1" fill="#E0F2FE" />
          <rect x="30" y="24" width="10" height="10" rx="1" fill="#E0F2FE" />
          <circle cx="22" cy="44" r="5" fill="#1F2937" />
          <circle cx="42" cy="44" r="5" fill="#1F2937" />
        </svg>
      )
    },
    {
      title: 'Printing services',
      category: 'Services',
      searchTerm: 'Printing',
      svg: (
        <svg className="w-9 h-9" viewBox="0 0 64 64" fill="none">
          <rect x="18" y="10" width="28" height="16" rx="2" fill="#9CA3AF" />
          <rect x="12" y="24" width="40" height="20" rx="4" fill="#374151" />
          <rect x="18" y="38" width="28" height="18" rx="2" fill="#FFFFFF" stroke="#9CA3AF" strokeWidth="2" />
          <circle cx="44" cy="30" r="2" fill="#10B981" />
        </svg>
      )
    }
  ];

  // 2. States Discovery
  const DISCOVERY_STATES = [
    {
      name: 'UP',
      fullState: 'Uttar Pradesh',
      svg: (
        <svg className="w-12 h-12 mx-auto" viewBox="0 0 64 64" fill="none">
          <path d="M12 48H52M16 48V36C16 36 20 28 32 28C44 28 48 36 48 36V48" stroke="#F59E0B" strokeWidth="2.5" strokeLinecap="round" />
          <path d="M28 28V16M36 28V16M32 16C32 16 26 12 32 8C38 12 32 16 32 16Z" stroke="#F59E0B" strokeWidth="2.5" strokeLinecap="round" />
          <circle cx="32" cy="36" r="4" stroke="#F59E0B" strokeWidth="2" />
        </svg>
      )
    },
    {
      name: 'Telangana',
      fullState: 'Telangana',
      svg: (
        <svg className="w-12 h-12 mx-auto" viewBox="0 0 64 64" fill="none">
          <path d="M16 50H48M20 50V32H44V50M20 32L20 12M44 32L44 12M28 32V50M36 32V50" stroke="#3B82F6" strokeWidth="2.5" strokeLinecap="round" />
          <path d="M16 12H24M40 12H48M32 32H32.01" stroke="#3B82F6" strokeWidth="3" strokeLinecap="round" />
        </svg>
      )
    },
    {
      name: 'Tamil Nadu',
      fullState: 'Tamil Nadu',
      svg: (
        <svg className="w-12 h-12 mx-auto" viewBox="0 0 64 64" fill="none">
          <path d="M12 50H52M16 50L22 16H42L48 50M20 38H44M22 28H42M24 20H40" stroke="#65A30D" strokeWidth="2.5" strokeLinecap="round" />
          <path d="M32 16V10M32 10L28 12M32 10L36 12" stroke="#65A30D" strokeWidth="2" strokeLinecap="round" />
        </svg>
      )
    },
    {
      name: 'Maharashtra',
      fullState: 'Maharashtra',
      svg: (
        <svg className="w-12 h-12 mx-auto" viewBox="0 0 64 64" fill="none">
          <path d="M12 50H52M18 50V24H46V50M26 50V36C26 32.6863 28.6863 30 32 30C35.3137 30 38 32.6863 38 36V50" stroke="#14B8A6" strokeWidth="2.5" strokeLinecap="round" />
          <path d="M14 24H50M22 24V16H42V24" stroke="#14B8A6" strokeWidth="2.5" strokeLinecap="round" />
        </svg>
      )
    },
    {
      name: 'Rajasthan',
      fullState: 'Rajasthan',
      svg: (
        <svg className="w-12 h-12 mx-auto" viewBox="0 0 64 64" fill="none">
          <path d="M12 50H52M18 50V20C18 16 32 12 32 12C32 12 46 16 46 20V50" stroke="#EC4899" strokeWidth="2.5" strokeLinecap="round" />
          <path d="M24 24H40M22 32H42M20 40H44" stroke="#EC4899" strokeWidth="2" strokeLinecap="round" />
          <circle cx="32" cy="20" r="2" stroke="#EC4899" strokeWidth="2" />
        </svg>
      )
    },
    {
      name: 'Haryana',
      fullState: 'Haryana',
      svg: (
        <svg className="w-12 h-12 mx-auto" viewBox="0 0 64 64" fill="none">
          <path d="M14 50H50M20 50C20 40 24 30 32 30C40 30 44 40 44 50" stroke="#FB923C" strokeWidth="2.5" strokeLinecap="round" />
          <path d="M32 30V14M26 20H38" stroke="#FB923C" strokeWidth="2.5" strokeLinecap="round" />
        </svg>
      )
    },
    {
      name: 'Kerala',
      fullState: 'Kerala',
      svg: (
        <svg className="w-12 h-12 mx-auto" viewBox="0 0 64 64" fill="none">
          <path d="M10 44C20 44 24 48 32 48C40 48 44 44 54 44" stroke="#FB7185" strokeWidth="2.5" strokeLinecap="round" />
          <path d="M14 44C18 36 26 34 32 34C38 34 46 36 50 44" stroke="#FB7185" strokeWidth="2" strokeLinecap="round" />
          <path d="M24 34V22C24 22 28 18 32 18C36 18 40 22 40 22V34" stroke="#FB7185" strokeWidth="2.5" strokeLinecap="round" />
        </svg>
      )
    },
    {
      name: 'Punjab',
      fullState: 'Punjab',
      svg: (
        <svg className="w-12 h-12 mx-auto" viewBox="0 0 64 64" fill="none">
          <path d="M16 50H48M24 50V30H40V50" stroke="#64748B" strokeWidth="2.5" strokeLinecap="round" />
          <path d="M32 30V16M24 20L32 12L40 20" stroke="#64748B" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      )
    },
    {
      name: 'West Bengal',
      fullState: 'West Bengal',
      svg: (
        <svg className="w-12 h-12 mx-auto" viewBox="0 0 64 64" fill="none">
          <path d="M12 50H52M20 50V36H44V50" stroke="#A855F7" strokeWidth="2.5" strokeLinecap="round" />
          <path d="M18 36C18 28 24 22 32 22C40 22 46 28 46 36" stroke="#A855F7" strokeWidth="2.5" strokeLinecap="round" />
          <path d="M32 22V12" stroke="#A855F7" strokeWidth="2" strokeLinecap="round" />
        </svg>
      )
    },
    {
      name: 'Gujarat',
      fullState: 'Gujarat',
      svg: (
        <svg className="w-12 h-12 mx-auto" viewBox="0 0 64 64" fill="none">
          <path d="M16 50H48M32 50V14" stroke="#D97706" strokeWidth="3" strokeLinecap="round" />
          <path d="M22 28L32 18L42 28" stroke="#D97706" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M26 40H38" stroke="#D97706" strokeWidth="2.5" strokeLinecap="round" />
        </svg>
      )
    },
    {
      name: 'Karnataka',
      fullState: 'Karnataka',
      svg: (
        <svg className="w-12 h-12 mx-auto" viewBox="0 0 64 64" fill="none">
          <path d="M12 50H52M16 50V30H48V50" stroke="#6366F1" strokeWidth="2.5" strokeLinecap="round" />
          <path d="M20 30V18H44V30M28 18V12H36V18" stroke="#6366F1" strokeWidth="2" strokeLinecap="round" />
        </svg>
      )
    },
    {
      name: 'Delhi',
      fullState: 'Delhi NCR (UT)',
      svg: (
        <svg className="w-12 h-12 mx-auto" viewBox="0 0 64 64" fill="none">
          <path d="M12 50H52M18 50V22L32 14L46 22V50" stroke="#10B981" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M26 50V36C26 32.6863 28.6863 30 32 30C35.3137 30 38 32.6863 38 36V50" stroke="#10B981" strokeWidth="2.5" strokeLinecap="round" />
        </svg>
      )
    }
  ];

  // 3. Portals Discovery
  const DISCOVERY_PORTALS = [
    {
      name: 'Government e-Marketplace (GeM)',
      dept: 'GeM - Government e-Marketplace',
      keyword: 'GeM',
      logo: (
        <div className="w-14 h-14 rounded-2xl bg-white border border-slate-200 shadow-xs flex items-center justify-center p-2">
          <span className="font-black text-lg text-[#002D62]">Ge<span className="text-amber-500">M</span></span>
        </div>
      )
    },
    {
      name: 'Central Public Procurement (Eprocure)',
      dept: 'Central Public Works Department (CPWD)',
      keyword: 'eprocure',
      logo: (
        <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-orange-500 to-amber-600 text-white shadow-xs flex items-center justify-center font-black text-xs p-1 text-center">
          eProcure
        </div>
      )
    },
    {
      name: 'Central Public Sector Enterprises (eTenders)',
      dept: 'All Authorities & Departments',
      keyword: 'CPSE',
      logo: (
        <div className="w-14 h-14 rounded-2xl bg-emerald-600 text-white shadow-xs flex items-center justify-center p-2">
          <Clock className="w-8 h-8" />
        </div>
      )
    },
    {
      name: 'Indian Railways (IREPS)',
      dept: 'Indian Railways (IREPS / Zonal Railways)',
      keyword: 'IREPS',
      logo: (
        <div className="w-14 h-14 rounded-full bg-red-700 text-white shadow-xs flex items-center justify-center font-black text-[10px] p-1 text-center border-2 border-amber-300">
          RAILWAYS
        </div>
      )
    },
    {
      name: 'Defence eProcurement (DEFPROC)',
      dept: 'Military Engineer Services (MES Defence)',
      keyword: 'Defence',
      logo: (
        <div className="w-14 h-14 rounded-2xl bg-[#001D42] text-white shadow-xs flex items-center justify-center p-2">
          <ShieldCheck className="w-8 h-8 text-amber-400" />
        </div>
      )
    },
    {
      name: 'Pradhan Mantri Gram Sadak Yojana (PMGSY)',
      dept: 'State Public Works Departments (PWD)',
      keyword: 'PMGSY',
      logo: (
        <div className="w-14 h-14 rounded-2xl bg-amber-500 text-white shadow-xs flex items-center justify-center font-black text-xs p-1 text-center">
          PMGSY
        </div>
      )
    },
    {
      name: 'Coal India (CIL)',
      dept: 'All Authorities & Departments',
      keyword: 'Coal India',
      logo: (
        <div className="w-14 h-14 rounded-2xl bg-slate-900 text-white shadow-xs flex items-center justify-center font-black text-sm p-1 text-center border border-slate-700">
          CIL
        </div>
      )
    },
    {
      name: 'National Thermal Power Corporation (NTPC)',
      dept: 'NTPC Limited',
      keyword: 'NTPC',
      logo: (
        <div className="w-14 h-14 rounded-2xl bg-blue-600 text-white shadow-xs flex items-center justify-center font-black text-xs p-1 text-center">
          NTPC
        </div>
      )
    }
  ];

  // 4. Organisations Discovery
  const DISCOVERY_ORGANISATIONS = [
    {
      name: 'NHIDCL',
      dept: 'National Highways Authority of India (NHAI)',
      keyword: 'NHIDCL',
      logo: (
        <div className="w-14 h-14 rounded-2xl bg-slate-100 border border-slate-300 shadow-xs flex items-center justify-center p-1 font-black text-xs text-slate-800 text-center">
          NHIDCL
        </div>
      )
    },
    {
      name: 'DDA',
      dept: 'Urban Local Bodies & Municipal Corporations (BMC/MCD/BBMP/AMC)',
      keyword: 'DDA',
      logo: (
        <div className="w-14 h-14 rounded-2xl bg-purple-50 border border-purple-200 shadow-xs flex items-center justify-center p-1 font-black text-xs text-purple-900 text-center">
          DDA
        </div>
      )
    },
    {
      name: 'Ministry of Petroleum',
      dept: 'Oil & Natural Gas Corporation (ONGC)',
      keyword: 'Petroleum',
      logo: (
        <div className="w-14 h-14 rounded-2xl bg-amber-50 border border-amber-300 shadow-xs flex items-center justify-center p-1 font-extrabold text-[10px] text-amber-900 text-center">
          MoPNG
        </div>
      )
    },
    {
      name: 'BRO',
      dept: 'Military Engineer Services (MES Defence)',
      keyword: 'BRO',
      logo: (
        <div className="w-14 h-14 rounded-full bg-blue-900 text-amber-400 shadow-xs flex items-center justify-center p-1 font-black text-xs text-center border-2 border-amber-400">
          BRO
        </div>
      )
    },
    {
      name: 'CPWD',
      dept: 'Central Public Works Department (CPWD)',
      keyword: 'CPWD',
      logo: (
        <div className="w-14 h-14 rounded-2xl bg-cyan-50 border border-cyan-300 shadow-xs flex items-center justify-center p-1 font-black text-xs text-cyan-900 text-center">
          CPWD
        </div>
      )
    },
    {
      name: 'Indian Air Force',
      dept: 'Military Engineer Services (MES Defence)',
      keyword: 'Air Force',
      logo: (
        <div className="w-14 h-14 rounded-2xl bg-sky-600 text-white shadow-xs flex items-center justify-center p-1 font-black text-[10px] text-center">
          IAF
        </div>
      )
    },
    {
      name: 'NHPC',
      dept: 'NTPC Limited',
      keyword: 'NHPC',
      logo: (
        <div className="w-14 h-14 rounded-2xl bg-emerald-600 text-white shadow-xs flex items-center justify-center p-1 font-black text-xs text-center">
          NHPC
        </div>
      )
    },
    {
      name: 'HPCL',
      dept: 'Bharat Petroleum Corporation (BPCL)',
      keyword: 'HPCL',
      logo: (
        <div className="w-14 h-14 rounded-2xl bg-red-600 text-white shadow-xs flex items-center justify-center p-1 font-black text-xs text-center">
          HPCL
        </div>
      )
    }
  ];

  // Dynamic Auto-Suggestions Calculation while typing
  const dynamicSuggestions = React.useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    const list: Array<{ id: string; text: string; type: 'tender' | 'department' | 'state' | 'category' | 'keyword'; subtext?: string }> = [];

    if (!q) {
      return [
        { id: 'pop-1', text: 'Solar Power Plant', type: 'keyword', subtext: 'Renewable energy & rooftop solar tenders' },
        { id: 'pop-2', text: 'Road & Highways', type: 'keyword', subtext: 'NHAI, PWD & Civil road works' },
        { id: 'pop-3', text: 'Account & Auditing', type: 'keyword', subtext: 'Financial, CA & internal audit services' },
        { id: 'pop-4', text: 'Civil & Construction', type: 'category', subtext: 'CPWD, MES & Municipal construction' },
        { id: 'pop-5', text: 'Central Public Works Department (CPWD)', type: 'department', subtext: 'Central Ministry Authority' },
        { id: 'pop-6', text: 'National Highways Authority of India (NHAI)', type: 'department', subtext: 'MoRTH Authority' },
        { id: 'pop-7', text: 'Maharashtra', type: 'state', subtext: 'State Government Tenders' },
        { id: 'pop-8', text: 'GeM Supply', type: 'keyword', subtext: 'Government e-Marketplace procurement' }
      ];
    }

    // 1. Keywords
    const popularKeywords = [
      'Solar', 'Solar Power Plant', 'Road & Highways', 'Highway Construction', 'Account & Auditing',
      'Civil Construction', 'Medical Equipment', 'Hospital Supplies', 'Manpower & Facility',
      'Security Services', 'Railways Bridge', 'CCTV & Surveillance', 'Computer Hardware',
      'Software & IT Support', 'Plumbing & Drainage', 'Electrical Maintenance', 'GeM Supply'
    ];

    popularKeywords.forEach((kw, idx) => {
      if (kw.toLowerCase().includes(q)) {
        list.push({
          id: `kw-${idx}`,
          text: kw,
          type: 'keyword',
          subtext: 'Matching Search Keyword'
        });
      }
    });

    // 2. Departments
    ALL_GOVERNMENT_AUTHORITIES.forEach((dept, idx) => {
      if (dept !== 'All Authorities & Departments' && dept.toLowerCase().includes(q)) {
        list.push({
          id: `dept-${idx}`,
          text: dept,
          type: 'department',
          subtext: 'Government Authority / Ministry'
        });
      }
    });

    // 3. States
    ALL_INDIAN_STATES.forEach((st, idx) => {
      if (st !== 'All States' && st.toLowerCase().includes(q)) {
        list.push({
          id: `st-${idx}`,
          text: st,
          type: 'state',
          subtext: 'State Government Portal'
        });
      }
    });

    // 4. Categories
    categoriesList.forEach((cat, idx) => {
      if (cat !== 'All Categories' && cat.toLowerCase().includes(q)) {
        list.push({
          id: `cat-${idx}`,
          text: cat,
          type: 'category',
          subtext: 'Work Category Sector'
        });
      }
    });

    // 5. Tenders matching title/ref
    tenders.forEach((t) => {
      if (t.title.toLowerCase().includes(q) || t.tenderRefNo.toLowerCase().includes(q) || t.city.toLowerCase().includes(q)) {
        list.push({
          id: `t-${t.id}`,
          text: t.title,
          type: 'tender',
          subtext: `${t.tenderRefNo} • ${t.authority} (${t.city}, ${t.state})`
        });
      }
    });

    // Deduplicate by text
    const seen = new Set<string>();
    const uniqueList: typeof list = [];
    for (const item of list) {
      const key = item.text.toLowerCase();
      if (!seen.has(key)) {
        seen.add(key);
        uniqueList.push(item);
      }
    }

    return uniqueList.slice(0, 8);
  }, [searchQuery, tenders, categoriesList]);

  // Add Note Handler
  const handleSaveNote = (tenderId: string) => {
    if (!noteInputText.trim()) return;

    const existingNotes = tenderNotesMap[tenderId] || [];
    const newNoteNumber = existingNotes.length + 1;

    const newNote: TenderNote = {
      id: `note-${Date.now()}`,
      tenderId,
      noteNumber: newNoteNumber,
      text: noteInputText.trim(),
      createdAt: new Date().toLocaleString('en-IN', {
        dateStyle: 'medium',
        timeStyle: 'short'
      })
    };

    setTenderNotesMap((prev) => ({
      ...prev,
      [tenderId]: [...existingNotes, newNote]
    }));

    setNoteInputText('');
    setActiveNoteComposerTenderId(null);
  };

  // Download NIT Document PDF simulation
  const handleDownloadNIT = (tender: TenderItem) => {
    const textContent = `
========================================================================
             TENDERIZE.COM - OFFICIAL NIT TENDER DOCUMENT
========================================================================
Tender Ref No: ${tender.tenderRefNo}
Title: ${tender.title}
Authority: ${tender.authority}
State: ${tender.state} | City: ${tender.city}
Category: ${tender.category}
Source Portal: ${tender.dataSource}
Estimated Value: ${tender.estimatedValue}
EMD Amount: ${tender.emdAmount} | Document Fee: ${tender.documentFee}
Published Date: ${tender.publishedDate}
Closing Due Date: ${tender.closingDate}

SUMMARY & SCOPE OF WORK:
${tender.summary}

Scope Details:
${(tender.scopeOfWork || ['Standard NIT guidelines apply']).map((s, idx) => `  ${idx + 1}. ${s}`).join('\n')}

ELIGIBILITY CRITERIA:
- Minimum Turnover: ${tender.eligibilityCriteria?.minTurnover || '30% of Estimated Value'}
- Work Experience: ${tender.eligibilityCriteria?.similarWorkExperience || '1 work of 80% or 2 works of 50% or 3 works of 40%'}
- Registration: ${tender.eligibilityCriteria?.classRegistration || 'Class 1 / Class A Enlisted Contractor'}

------------------------------------------------------------------------
App Published & Managed by Rajudas.
    `.trim();

    const blob = new Blob([textContent], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `NIT_Tender_${tender.tenderRefNo.replace(/[/\\?%*:|"<>]/g, '_')}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  // Filtered tenders logic
  const filteredTenders = tenders.filter((t) => {
    const q = searchQuery.trim().toLowerCase();
    
    let matchesQuery = !q;
    if (q) {
      const fullSearchableText = [
        t.title,
        t.authority,
        t.departmentCategory || '',
        t.tenderRefNo,
        t.city,
        t.state,
        t.summary,
        t.category,
        ...(t.scopeOfWork || []),
        t.dataSource || '',
        t.portalName || ''
      ].join(' ').toLowerCase();

      if (fullSearchableText.includes(q)) {
        matchesQuery = true;
      } else {
        const tokens = q
          .replace(/[^a-z0-9]/g, ' ')
          .split(/\s+/)
          .filter((tok) => tok.length > 1);

        if (tokens.length > 0) {
          const matchedTokenCount = tokens.filter((tok) => {
            if (fullSearchableText.includes(tok)) return true;
            if (tok.endsWith('s') && fullSearchableText.includes(tok.slice(0, -1))) return true;
            if (!tok.endsWith('s') && fullSearchableText.includes(tok + 's')) return true;

            if ((tok === 'road' || tok === 'highway' || tok === 'highways' || tok === 'expressway') &&
                (fullSearchableText.includes('road') || fullSearchableText.includes('highway') || fullSearchableText.includes('nhai') || fullSearchableText.includes('morth') || fullSearchableText.includes('bridge') || fullSearchableText.includes('rob') || fullSearchableText.includes('flyover') || fullSearchableText.includes('corridor') || fullSearchableText.includes('pavement') || fullSearchableText.includes('civil') || fullSearchableText.includes('pwd'))) {
              return true;
            }

            if ((tok === 'solar' || tok === 'pv' || tok === 'renewable') &&
                (fullSearchableText.includes('solar') || fullSearchableText.includes('pv') || fullSearchableText.includes('renewable') || fullSearchableText.includes('energy') || fullSearchableText.includes('power'))) {
              return true;
            }

            if ((tok === 'account' || tok === 'audit' || tok === 'auditing' || tok === 'accounts') &&
                (fullSearchableText.includes('audit') || fullSearchableText.includes('account') || fullSearchableText.includes('financial') || fullSearchableText.includes('billing') || fullSearchableText.includes('ca'))) {
              return true;
            }

            if ((tok === 'software' || tok === 'telecom' || tok === 'it') &&
                (fullSearchableText.includes('software') || fullSearchableText.includes('telecom') || fullSearchableText.includes('it') || fullSearchableText.includes('computer') || fullSearchableText.includes('cloud') || fullSearchableText.includes('digital'))) {
              return true;
            }

            return false;
          }).length;

          if (matchedTokenCount > 0) {
            matchesQuery = true;
          }
        }
      }
    }

    const cleanSelectedState = selectedState.replace(' (UT)', '').trim().toLowerCase();
    const matchesState =
      selectedState === 'All States' ||
      t.state.toLowerCase().includes(cleanSelectedState) ||
      cleanSelectedState.includes(t.state.toLowerCase());

    const matchesCategory = selectedCategory === 'All Categories' || 
      t.category === selectedCategory ||
      (selectedCategory === 'Road & Highways' && (t.category === 'Road & Highways' || t.title.toLowerCase().includes('highway') || t.title.toLowerCase().includes('road') || t.departmentCategory === 'NHAI & Highways'));

    const deptKeyword = selectedDepartment.split(' ')[0].toLowerCase();
    const matchesDept =
      selectedDepartment === 'All Authorities & Departments' ||
      t.authority.toLowerCase().includes(selectedDepartment.toLowerCase()) ||
      selectedDepartment.toLowerCase().includes(t.authority.toLowerCase()) ||
      (deptKeyword.length > 3 && t.authority.toLowerCase().includes(deptKeyword));

    const matchesStatus =
      projectStatusFilter === 'All Statuses' ||
      (t.projectStatus || 'Live / Active') === projectStatusFilter;

    const matchesMSME = !msmeExemptionOnly || t.msmeExemptionAvailable;
    const matchesValue = (t.valueNumericInLakhs || 0) >= minValueLakhs;

    // Date Range check
    let matchesDate = true;
    if (dateRange !== 'all' && t.publishedDate) {
      const pubDate = new Date(t.publishedDate);
      if (!isNaN(pubDate.getTime())) {
        const now = new Date();
        const diffDays = Math.abs((now.getTime() - pubDate.getTime()) / (1000 * 3600 * 24));

        if (dateRange === '7days') matchesDate = diffDays <= 7;
        else if (dateRange === '1month') matchesDate = diffDays <= 30;
        else if (dateRange === '6months') matchesDate = diffDays <= 180;
        else if (dateRange === '1year') matchesDate = diffDays <= 365;
      }
    }

    return (
      matchesQuery &&
      matchesState &&
      matchesCategory &&
      matchesDept &&
      matchesStatus &&
      matchesMSME &&
      matchesValue &&
      matchesDate
    );
  });

  // Pagination calculation
  const totalPages = Math.ceil(filteredTenders.length / itemsPerPage) || 1;
  const currentTenders = filteredTenders.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  // Helper to compute a visible window of max 10 page numbers
  const getVisiblePages = (current: number, total: number) => {
    const maxVisible = 10;
    if (total <= maxVisible) {
      return Array.from({ length: total }, (_, i) => i + 1);
    }
    let start = Math.max(1, current - Math.floor(maxVisible / 2));
    let end = start + maxVisible - 1;
    if (end > total) {
      end = total;
      start = Math.max(1, end - maxVisible + 1);
    }
    return Array.from({ length: end - start + 1 }, (_, i) => start + i);
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setHasSearched(true);
    setCurrentPage(1);
    if (onSyncLiveTenders) {
      onSyncLiveTenders({
        q: searchQuery,
        state: selectedState,
        category: selectedCategory,
        department: selectedDepartment
      });
    }
    if (searchQuery.trim()) {
      onRunAISearch(searchQuery);
    }
  };

  return (
    <div className="flex-1 bg-[#f8fafc] overflow-y-auto">
      {/* Hero Banner with Search Bar & Suggestions */}
      <div className="bg-gradient-to-b from-[#002D62] via-[#001E42] to-[#0A192F] text-white pt-8 pb-12 px-4 sm:px-6 lg:px-8 border-b border-slate-800 relative">
        <div className="max-w-7xl mx-auto space-y-6">
          <div className="text-center max-w-3xl mx-auto space-y-3">
            {/* Simplified Live Portal Status & Sync Bar */}
            <div className="inline-flex flex-wrap items-center justify-center gap-2 sm:gap-3 bg-slate-900/80 backdrop-blur-md border border-slate-700/70 px-4 py-2 rounded-full text-xs shadow-md mx-auto">
              <a
                href={`https://tenderkart.in/tenders/filters?sort=last_activity_desc&last_activity_period=all${searchQuery ? '&q=' + encodeURIComponent(searchQuery) : ''}${selectedState !== 'All States' ? '&state=' + encodeURIComponent(selectedState) : ''}`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center space-x-2 text-emerald-400 hover:text-emerald-300 font-bold transition-colors"
                title="Source: tenderkart.in/tenders/filters"
              >
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse shrink-0"></span>
                <span>Source: tenderkart.in/tenders/filters</span>
                <ExternalLink className="w-3 h-3 ml-0.5" />
              </a>
              <span className="text-slate-600 hidden sm:inline">|</span>
              <button
                type="button"
                onClick={() => onSyncLiveTenders && onSyncLiveTenders({ q: searchQuery, state: selectedState, category: selectedCategory, department: selectedDepartment })}
                disabled={isSyncingPortals}
                className="inline-flex items-center space-x-1.5 text-amber-400 hover:text-amber-300 font-extrabold text-xs cursor-pointer transition-colors disabled:opacity-50"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isSyncingPortals ? 'animate-spin' : ''}`} />
                <span>{isSyncingPortals ? 'Pulling from Tenderkart...' : 'Auto-Pull Live Tenders'}</span>
              </button>
            </div>

            <h1 className="text-[clamp(12px,2.8vw,36px)] font-black tracking-tight text-white whitespace-nowrap text-center leading-normal">
              Search <span className="text-amber-400">150,000+ Active</span> Indian Government Tenders
            </h1>
            <p className="text-slate-300 text-xs sm:text-sm font-normal max-w-2xl mx-auto">
              Direct access to Central Ministries, State PWDs, GeM Portal, Indian Railways, NHAI, MES & Municipal tenders.
            </p>
          </div>

          {/* Search Form Box */}
          <form
            onSubmit={(e) => {
              setShowSuggestions(false);
              handleSearchSubmit(e);
              if (onSyncLiveTenders) {
                onSyncLiveTenders({
                  q: searchQuery,
                  state: selectedState,
                  category: selectedCategory,
                  department: selectedDepartment,
                  page: 1
                });
              }
            }}
            className="bg-white p-3 sm:p-4 rounded-2xl shadow-2xl border border-slate-200 max-w-5xl mx-auto text-slate-900 space-y-3"
          >
            <div className="flex flex-col md:flex-row items-center gap-2">
              <div className="relative flex-1 w-full">
                <Search className="w-5 h-5 text-slate-400 absolute left-3.5 top-3.5 pointer-events-none" />
                <input
                  type="text"
                  value={searchQuery}
                  onFocus={() => setShowSuggestions(true)}
                  onBlur={() => setTimeout(() => setShowSuggestions(false), 200)}
                  onChange={(e) => {
                    setSearchQuery(e.target.value);
                    setShowSuggestions(true);
                    setCurrentPage(1);
                  }}
                  placeholder="Enter Keyword, Tender ID, Authority (e.g., Solar, Road, Account, Construction, CPWD)..."
                  className="w-full pl-11 pr-10 py-3 rounded-xl border border-slate-200 text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-[#002D62] text-slate-900"
                />

                {searchQuery && (
                  <button
                    type="button"
                    onClick={() => {
                      setSearchQuery('');
                      setShowSuggestions(true);
                    }}
                    className="absolute right-3.5 top-3.5 text-slate-400 hover:text-slate-600 p-0.5 rounded-full hover:bg-slate-100 transition-colors"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}

                {/* Autocomplete Suggestions Dropdown Popup */}
                {showSuggestions && (
                  <div className="absolute left-0 right-0 top-full mt-2 bg-white rounded-2xl shadow-2xl border border-slate-200 z-50 overflow-hidden divide-y divide-slate-100 animate-in fade-in slide-in-from-top-1 duration-150">
                    <div className="p-2.5 bg-slate-50 border-b border-slate-100 flex items-center justify-between text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                      <span className="flex items-center space-x-1.5">
                        <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                        <span>{searchQuery.trim() ? `Suggestions for "${searchQuery}"` : 'Popular & Trending Searches'}</span>
                      </span>
                      <span className="text-[10px] text-slate-400 font-normal">Click to select & search</span>
                    </div>

                    <div className="max-h-80 overflow-y-auto divide-y divide-slate-100 py-1">
                      {dynamicSuggestions.length === 0 ? (
                        <div className="p-4 text-center text-xs text-slate-500 font-medium">
                          No direct keyword match for "{searchQuery}". Click search or press Enter to search across all tenders.
                        </div>
                      ) : (
                        dynamicSuggestions.map((item) => (
                          <button
                            key={item.id}
                            type="button"
                            onMouseDown={(e) => {
                              e.preventDefault();
                              setSearchQuery(item.text);
                              if (item.type === 'state') setSelectedState(item.text);
                              if (item.type === 'department') setSelectedDepartment(item.text);
                              if (item.type === 'category') setSelectedCategory(item.text as CategoryType);
                              setHasSearched(true);
                              setCurrentPage(1);
                              setShowSuggestions(false);
                              if (item.text.trim()) {
                                onRunAISearch(item.text);
                              }
                            }}
                            className="w-full text-left px-4 py-2.5 hover:bg-blue-50/80 transition-colors flex items-center justify-between group"
                          >
                            <div className="flex items-center space-x-3 min-w-0 pr-2">
                              <div className="w-8 h-8 rounded-xl bg-slate-100 text-slate-600 flex items-center justify-center shrink-0 group-hover:bg-[#002D62] group-hover:text-white transition-colors">
                                {item.type === 'department' && <Building2 className="w-4 h-4" />}
                                {item.type === 'state' && <MapPin className="w-4 h-4" />}
                                {item.type === 'category' && <Tag className="w-4 h-4" />}
                                {item.type === 'tender' && <FileText className="w-4 h-4 text-amber-600 group-hover:text-amber-400" />}
                                {item.type === 'keyword' && <Search className="w-4 h-4 text-blue-600 group-hover:text-white" />}
                              </div>
                              <div className="truncate">
                                <div className="text-xs font-bold text-slate-800 group-hover:text-[#002D62] truncate">
                                  {item.text}
                                </div>
                                {item.subtext && (
                                  <div className="text-[10px] text-slate-500 truncate font-medium">
                                    {item.subtext}
                                  </div>
                                )}
                              </div>
                            </div>

                            <span className="shrink-0 px-2 py-0.5 rounded-md text-[10px] font-extrabold uppercase bg-slate-100 text-slate-600 group-hover:bg-blue-100 group-hover:text-[#002D62]">
                              {item.type}
                            </span>
                          </button>
                        ))
                      )}
                    </div>
                  </div>
                )}
              </div>

              <button
                type="submit"
                disabled={isAISearching}
                className="w-full md:w-auto bg-[#E65100] hover:bg-[#cc4100] text-white font-extrabold text-sm px-6 py-3 rounded-xl flex items-center justify-center space-x-2 transition-all shrink-0 shadow-md"
              >
                {isAISearching ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>Searching...</span>
                  </>
                ) : (
                  <>
                    <Search className="w-4 h-4" />
                    <span>Search Tenders</span>
                  </>
                )}
              </button>
            </div>



            {/* Single Clean Line Filters Bar */}
            <div className="flex flex-wrap lg:flex-nowrap items-center gap-1.5 pt-1 text-[11px]">
              {/* State Filter */}
              <select
                value={selectedState}
                onChange={(e) => {
                  const newSt = e.target.value;
                  setSelectedState(newSt);
                  setHasSearched(true);
                  setCurrentPage(1);
                  if (onSyncLiveTenders) {
                    onSyncLiveTenders({
                      q: searchQuery,
                      state: newSt,
                      category: selectedCategory,
                      department: selectedDepartment,
                      page: 1
                    });
                  }
                }}
                className="flex-1 min-w-[110px] px-2 py-1.5 rounded-lg border border-slate-200 text-[11px] font-semibold text-slate-800 bg-slate-50 focus:outline-none focus:ring-1 focus:ring-[#002D62] truncate"
              >
                {ALL_INDIAN_STATES.map((s) => (
                  <option key={s} value={s}>{s}</option>
                ))}
              </select>

              {/* Authority / Dept Filter */}
              <select
                value={selectedDepartment}
                onChange={(e) => {
                  const newDept = e.target.value;
                  setSelectedDepartment(newDept);
                  setHasSearched(true);
                  setCurrentPage(1);
                  if (onSyncLiveTenders) {
                    onSyncLiveTenders({
                      q: searchQuery,
                      state: selectedState,
                      category: selectedCategory,
                      department: newDept,
                      page: 1
                    });
                  }
                }}
                className="flex-1 min-w-[140px] px-2 py-1.5 rounded-lg border border-slate-200 text-[11px] font-semibold text-slate-800 bg-slate-50 focus:outline-none focus:ring-1 focus:ring-[#002D62] truncate"
              >
                {ALL_GOVERNMENT_AUTHORITIES.map((d) => (
                  <option key={d} value={d}>{d}</option>
                ))}
              </select>

              {/* Project / Tender Status Filter */}
              <select
                value={projectStatusFilter}
                onChange={(e) => {
                  setProjectStatusFilter(e.target.value as ProjectStatusType);
                  setHasSearched(true);
                  setCurrentPage(1);
                }}
                className="flex-1 min-w-[125px] px-2 py-1.5 rounded-lg border border-slate-200 text-[11px] font-semibold text-slate-800 bg-slate-50 focus:outline-none focus:ring-1 focus:ring-[#002D62] truncate"
              >
                <option value="All Statuses">All Statuses</option>
                <option value="Live / Active">Live / Active</option>
                <option value="Under Evolution">Under Evolution</option>
                <option value="Tender Awarded">Tender Awarded</option>
              </select>

              {/* Published Duration Filter */}
              <select
                value={dateRange}
                onChange={(e) => {
                  setDateRange(e.target.value as DateRangeType);
                  setHasSearched(true);
                  setCurrentPage(1);
                }}
                className="flex-1 min-w-[120px] px-2 py-1.5 rounded-lg border border-slate-200 text-[11px] font-semibold text-slate-800 bg-slate-50 focus:outline-none focus:ring-1 focus:ring-[#002D62] truncate"
              >
                <option value="all">Published: All Time</option>
                <option value="7days">Published: Last 7 Days</option>
                <option value="1month">Published: Last 1 Month</option>
                <option value="6months">Published: Last 6 Months</option>
                <option value="1year">Published: Last 1 Year</option>
              </select>

              {/* MSME EMD Exempted Toggle */}
              <label className="flex items-center space-x-1 shrink-0 bg-slate-50 px-2 py-1.5 rounded-lg border border-slate-200 cursor-pointer hover:bg-slate-100 transition-colors text-[11px] font-semibold text-slate-700 whitespace-nowrap">
                <input
                  type="checkbox"
                  checked={msmeExemptionOnly}
                  onChange={(e) => {
                    setMsmeExemptionOnly(e.target.checked);
                    setHasSearched(true);
                    setCurrentPage(1);
                  }}
                  className="rounded text-[#E65100] focus:ring-[#E65100] h-3.5 w-3.5"
                />
                <span>MSME Exempted</span>
              </label>

              {/* Min Value Filter */}
              <div className="flex items-center space-x-1 shrink-0 bg-slate-50 px-2 py-1.5 rounded-lg border border-slate-200 text-[11px]">
                <span className="text-slate-500 font-medium">Min:</span>
                <select
                  value={minValueLakhs}
                  onChange={(e) => {
                    setMinValueLakhs(Number(e.target.value));
                    setHasSearched(true);
                    setCurrentPage(1);
                  }}
                  className="bg-transparent font-bold text-slate-800 focus:outline-none text-[11px]"
                >
                  <option value={0}>₹ 0+</option>
                  <option value={50}>₹ 50L+</option>
                  <option value={200}>₹ 2Cr+</option>
                  <option value={1000}>₹ 10Cr+</option>
                  <option value={5000}>₹ 50Cr+</option>
                </select>
              </div>

              {/* Reset All Filters Button */}
              <button
                type="button"
                onClick={() => {
                  setSearchQuery('');
                  setSelectedState('All States');
                  setSelectedCategory('All Categories');
                  setSelectedDepartment('All Authorities & Departments');
                  setDateRange('all');
                  setProjectStatusFilter('All Statuses');
                  setMsmeExemptionOnly(false);
                  setMinValueLakhs(0);
                  setCurrentPage(1);
                  setHasSearched(false);
                }}
                className="text-[11px] text-[#002D62] font-bold hover:underline shrink-0 px-1 py-1 whitespace-nowrap ml-auto"
              >
                Reset All
              </button>
            </div>
          </form>

          {/* Real-time Tenders Stats Row */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 max-w-5xl mx-auto pt-2">
            <div className="bg-slate-800/60 border border-slate-700/60 rounded-xl p-3 text-center">
              <span className="text-xl font-extrabold text-amber-400 block">154,280+</span>
              <span className="text-[11px] text-slate-300 font-semibold uppercase">Active Tenders</span>
            </div>
            <div className="bg-slate-800/60 border border-slate-700/60 rounded-xl p-3 text-center">
              <span className="text-xl font-extrabold text-white block">₹ 85,400 Cr</span>
              <span className="text-[11px] text-slate-300 font-semibold uppercase">Total Value</span>
            </div>
            <div className="bg-slate-800/60 border border-slate-700/60 rounded-xl p-3 text-center">
              <span className="text-xl font-extrabold text-emerald-400 block">3,840+</span>
              <span className="text-[11px] text-slate-300 font-semibold uppercase">Added Today</span>
            </div>
            <div className="bg-slate-800/60 border border-slate-700/60 rounded-xl p-3 text-center">
              <span className="text-xl font-extrabold text-white block">36 States & UTs</span>
              <span className="text-[11px] text-slate-300 font-semibold uppercase">Full Coverage</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">

        {/* AI Briefing Summary if triggered */}
        {aiSearchSummary && (
          <div className="bg-gradient-to-r from-blue-50 to-amber-50 border border-blue-200 rounded-2xl p-5 space-y-2 animate-in fade-in">
            <div className="flex items-center space-x-2 text-[#002D62] font-extrabold text-xs uppercase tracking-wider">
              <Sparkles className="w-4 h-4 text-amber-600" />
              <span>Gemini AI Tender Market Briefing</span>
            </div>
            <p className="text-xs sm:text-sm text-slate-800 leading-relaxed font-medium">
              {aiSearchSummary}
            </p>
          </div>
        )}

        {/* Discovery Sections (Keywords, States, Portals, Organisation) */}
        {!hasSearched ? (
          <div className="space-y-16 py-4 animate-in fade-in duration-300">
            {/* 1. Find by Keywords */}
            <section className="space-y-6">
              <div className="text-center space-y-2">
                <h2 className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tight">
                  Find by Keywords
                </h2>
                <p className="text-slate-500 font-medium text-xs sm:text-sm max-w-2xl mx-auto">
                  Discover tender opportunities by searching popular keywords across all categories
                </p>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3.5 sm:gap-4">
                {DISCOVERY_KEYWORDS.map((item, idx) => (
                  <button
                    key={idx}
                    onClick={() => {
                      setSearchQuery(item.searchTerm);
                      setSelectedCategory('All Categories');
                      setSelectedState('All States');
                      setSelectedDepartment('All Authorities & Departments');
                      setHasSearched(true);
                      setCurrentPage(1);
                    }}
                    className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200/90 shadow-xs hover:shadow-xl hover:border-blue-400 hover:-translate-y-1 transition-all duration-200 flex flex-col items-center justify-center text-center group cursor-pointer"
                  >
                    <div className="mb-3 p-2.5 rounded-2xl bg-slate-50 group-hover:bg-blue-50 transition-colors">
                      {item.svg}
                    </div>
                    <span className="font-extrabold text-xs sm:text-sm text-slate-900 leading-tight group-hover:text-[#002D62] transition-colors">
                      {item.title}
                    </span>
                    <span className="text-[10px] font-semibold text-slate-400 mt-1">
                      {item.category}
                    </span>
                  </button>
                ))}
              </div>
            </section>

            {/* 2. Find tenders by States */}
            <section className="space-y-6 bg-slate-50/60 p-5 sm:p-8 rounded-3xl border border-slate-200/70">
              <div className="text-center space-y-2">
                <h2 className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tight">
                  Find tenders by States
                </h2>
                <p className="text-slate-500 font-medium text-xs sm:text-sm max-w-2xl mx-auto">
                  Browse active tenders from all Indian states and union territories
                </p>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3.5 sm:gap-5">
                {DISCOVERY_STATES.map((item, idx) => (
                  <button
                    key={idx}
                    onClick={() => {
                      setSelectedState(item.fullState);
                      setSelectedCategory('All Categories');
                      setSelectedDepartment('All Authorities & Departments');
                      setSearchQuery('');
                      setHasSearched(true);
                      setCurrentPage(1);
                    }}
                    className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs hover:shadow-xl hover:border-blue-400 hover:-translate-y-1 transition-all duration-200 flex flex-col items-center justify-center text-center group cursor-pointer"
                  >
                    <div className="mb-3">
                      <StateLandmarkIcon stateName={item.fullState} className="w-12 h-12 mx-auto" />
                    </div>
                    <span className="font-extrabold text-xs sm:text-sm text-slate-900 group-hover:text-[#002D62] transition-colors">
                      {item.name}
                    </span>
                  </button>
                ))}
              </div>
            </section>

            {/* 3. Find tenders by Portals */}
            <section className="space-y-6">
              <div className="text-center space-y-2">
                <h2 className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tight">
                  Find tenders by Portals
                </h2>
                <p className="text-slate-500 font-medium text-xs sm:text-sm max-w-2xl mx-auto">
                  Explore tenders from Central Government platforms and Public Sector Undertakings
                </p>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-4 gap-4 sm:gap-5">
                {DISCOVERY_PORTALS.map((item, idx) => (
                  <button
                    key={idx}
                    onClick={() => {
                      if (item.dept !== 'All Authorities & Departments') {
                        setSelectedDepartment(item.dept);
                        setSearchQuery('');
                      } else {
                        setSearchQuery(item.keyword);
                      }
                      setSelectedCategory('All Categories');
                      setSelectedState('All States');
                      setHasSearched(true);
                      setCurrentPage(1);
                    }}
                    className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs hover:shadow-xl hover:border-blue-400 hover:-translate-y-1 transition-all duration-200 flex flex-col items-center justify-center text-center group cursor-pointer space-y-3"
                  >
                    {item.logo}
                    <span className="font-extrabold text-xs sm:text-sm text-slate-800 leading-snug group-hover:text-[#002D62] transition-colors">
                      {item.name}
                    </span>
                  </button>
                ))}
              </div>
            </section>

            {/* 4. Find tenders by Organisation */}
            <section className="space-y-6 bg-slate-50/60 p-5 sm:p-8 rounded-3xl border border-slate-200/70">
              <div className="text-center space-y-2">
                <h2 className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tight">
                  Find tenders by Organisation
                </h2>
                <p className="text-slate-500 font-medium text-xs sm:text-sm max-w-2xl mx-auto">
                  Access procurement opportunities from major government departments and agencies
                </p>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-4 gap-4 sm:gap-5">
                {DISCOVERY_ORGANISATIONS.map((item, idx) => (
                  <button
                    key={idx}
                    onClick={() => {
                      if (item.dept !== 'All Authorities & Departments') {
                        setSelectedDepartment(item.dept);
                        setSearchQuery('');
                      } else {
                        setSearchQuery(item.keyword);
                      }
                      setSelectedCategory('All Categories');
                      setSelectedState('All States');
                      setHasSearched(true);
                      setCurrentPage(1);
                    }}
                    className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs hover:shadow-xl hover:border-blue-400 hover:-translate-y-1 transition-all duration-200 flex flex-col items-center justify-center text-center group cursor-pointer space-y-3"
                  >
                    {item.logo}
                    <span className="font-black text-xs sm:text-sm text-slate-800 group-hover:text-[#002D62] transition-colors">
                      {item.name}
                    </span>
                  </button>
                ))}
              </div>
            </section>
          </div>
        ) : (
          <>
            {/* Category Chips Bar */}
            <div id="tender-results-container" className="flex items-center space-x-2 overflow-x-auto pb-2 scrollbar-none">
              {categoriesList.map((cat) => {
                const isCatActive = selectedCategory === cat;
                return (
                  <button
                    key={cat}
                    onClick={() => {
                      setSelectedCategory(cat);
                      setHasSearched(true);
                      setCurrentPage(1);
                    }}
                    className={`px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all border ${
                      isCatActive
                        ? 'bg-[#002D62] text-white border-[#002D62] shadow-xs'
                        : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    {cat}
                  </button>
                );
              })}
            </div>

            {/* Live Tenders List Container */}
            <div className="space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-200 pb-3">
            <div>
              <h2 className="text-xl font-extrabold text-slate-900 tracking-tight">
                Live Government Tenders ({filteredTenders.length})
              </h2>
              <p className="text-xs text-slate-500">
                Indexed from tenderkart.in, indextender.in, tender.co.in, CPPP, IREPS & GeM portal.
              </p>
            </div>

            <div className="text-xs text-slate-500 font-semibold">
              Showing <span className="font-bold text-slate-900">{(currentPage - 1) * itemsPerPage + 1} - {Math.min(currentPage * itemsPerPage, filteredTenders.length)}</span> of <span className="font-bold text-slate-900">{filteredTenders.length}</span> active tenders
            </div>
          </div>

          {filteredTenders.length === 0 ? (
            <div className="bg-white p-12 text-center rounded-2xl border border-slate-200 space-y-3">
              <AlertCircle className="w-10 h-10 text-slate-400 mx-auto" />
              <h3 className="font-bold text-slate-800 text-base">No Matching Tenders Found</h3>
              <p className="text-xs text-slate-500 max-w-md mx-auto">
                Try widening your search terms, choosing 'All States & UTs' or resetting the project status filter.
              </p>
              <button
                onClick={() => {
                  setSearchQuery('');
                  setSelectedState('All States & UTs');
                  setSelectedCategory('All Categories');
                  setSelectedDepartment('All Authorities & Departments');
                  setDateRange('all');
                  setProjectStatusFilter('All Statuses');
                  setMinValueLakhs(0);
                  setCurrentPage(1);
                }}
                className="bg-[#002D62] text-white font-bold text-xs px-4 py-2 rounded-xl"
              >
                Reset Search Filters
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-4">
              {currentTenders.map((tender) => {
                const isSaved = savedTenderIds.includes(tender.id);
                const notesList = tenderNotesMap[tender.id] || tender.notes || [];
                const isComposerOpen = activeNoteComposerTenderId === tender.id;

                return (
                  <div
                    key={tender.id}
                    className="bg-white rounded-2xl border border-slate-200 hover:border-blue-400 shadow-2xs hover:shadow-md transition-all p-5 space-y-4"
                  >
                    {/* Header line */}
                    <div className="flex flex-col md:flex-row md:items-start justify-between gap-3">
                      <div className="space-y-1.5 flex-1">
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="bg-blue-50 text-[#002D62] font-mono text-[11px] font-extrabold px-2.5 py-0.5 rounded border border-blue-200">
                            Ref: {tender.tenderRefNo}
                          </span>
                          <span className="bg-slate-100 text-slate-700 text-[11px] font-bold px-2 py-0.5 rounded">
                            {tender.category}
                          </span>
                          <span className="bg-amber-50 text-amber-900 text-[10px] font-bold px-2 py-0.5 rounded border border-amber-200">
                            Source: {tender.dataSource}
                          </span>

                          {/* Project Status Badge */}
                          <span className={`text-[10px] font-extrabold px-2.5 py-0.5 rounded border ${
                            tender.projectStatus === 'Live / Active' || !tender.projectStatus
                              ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                              : tender.projectStatus === 'On Hold'
                              ? 'bg-amber-100 text-amber-900 border-amber-300'
                              : tender.projectStatus === 'Tender Awarded'
                              ? 'bg-blue-50 text-blue-800 border-blue-200'
                              : 'bg-rose-50 text-rose-800 border-rose-200'
                          }`}>
                            Status: {tender.projectStatus || 'Live / Active'}
                          </span>

                          {tender.isGeMTender && (
                            <span className="bg-[#E65100]/10 text-[#E65100] text-[10px] font-extrabold px-2 py-0.5 rounded border border-[#E65100]/30">
                              GeM Custom Bid
                            </span>
                          )}
                          {tender.msmeExemptionAvailable && (
                            <span className="bg-emerald-50 text-emerald-800 text-[10px] font-bold px-2 py-0.5 rounded border border-emerald-200">
                              MSME EMD Exempt
                            </span>
                          )}
                        </div>

                        <h3
                          onClick={() => onOpenTenderDetails(tender)}
                          className="text-base font-extrabold text-slate-900 hover:text-[#002D62] cursor-pointer leading-snug"
                        >
                          {tender.title}
                        </h3>

                        <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-slate-600 font-semibold">
                          <span className="flex items-center space-x-1 text-slate-900 font-bold">
                            <Building2 className="w-3.5 h-3.5 text-slate-400" />
                            <span>{tender.authority}</span>
                          </span>
                          <span className="flex items-center space-x-1">
                            <MapPin className="w-3.5 h-3.5 text-slate-400" />
                            <span>{tender.city}, {tender.state}</span>
                          </span>
                          <span className="flex items-center space-x-1 text-slate-400">
                            <Calendar className="w-3.5 h-3.5" />
                            <span>Pub: {tender.publishedDate}</span>
                          </span>
                        </div>
                      </div>

                      {/* Value & Due Date Block */}
                      <div className="flex md:flex-col items-center md:items-end justify-between border-t md:border-t-0 pt-3 md:pt-0 border-slate-100 gap-2 shrink-0">
                        <div className="text-left md:text-right">
                          <span className="text-[10px] uppercase font-bold text-slate-400 block">Est. Tender Value</span>
                          <span className="text-lg font-black text-[#002D62]">{tender.estimatedValue}</span>
                        </div>

                        <div className="text-right">
                          <span className="text-[10px] uppercase font-bold text-slate-400 block">Closing Due Date</span>
                          <span className="text-xs font-bold text-rose-600 flex items-center space-x-1 justify-end">
                            <Clock className="w-3.5 h-3.5" />
                            <span>{tender.closingDate}</span>
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Brief Work Overview */}
                    <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed bg-slate-50 p-3 rounded-xl border border-slate-100">
                      {tender.summary}
                    </p>

                    {/* Participating Contractors / Bidders Info */}
                    {tender.participatingContractors && tender.participatingContractors.length > 0 && (
                      <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-200/80 text-xs flex flex-wrap items-center gap-2">
                        <div className="flex items-center space-x-1 text-slate-700 font-extrabold text-[11px] shrink-0">
                          <Users className="w-3.5 h-3.5 text-[#002D62]" />
                          <span>Participating Bidders / Contractors:</span>
                        </div>
                        <div className="flex flex-wrap gap-1.5">
                          {tender.participatingContractors.map((c) => (
                            <span key={c} className="bg-white border border-slate-200 text-slate-800 text-[11px] font-semibold px-2 py-0.5 rounded">
                              {c}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Locked Notes Display Log */}
                    {notesList.length > 0 && (
                      <div className="bg-amber-50/70 border border-amber-200/80 rounded-xl p-3 space-y-2 text-xs">
                        <div className="flex items-center space-x-1.5 font-extrabold text-amber-900 text-[11px] uppercase tracking-wider">
                          <StickyNote className="w-3.5 h-3.5 text-amber-600" />
                          <span>Internal Saved Remarks & Notes ({notesList.length})</span>
                        </div>
                        <div className="space-y-1.5 pl-1">
                          {notesList.map((n, idx) => (
                            <div key={n.id || idx} className="bg-white p-2 rounded-lg border border-amber-200 shadow-2xs text-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                              <div className="space-x-1.5">
                                <span className="font-extrabold text-amber-900 bg-amber-100 px-1.5 py-0.5 rounded text-[10px]">
                                  Note {n.noteNumber || idx + 1}:
                                </span>
                                <span className="font-medium text-slate-800">{n.text}</span>
                              </div>
                              <span className="text-[10px] text-slate-400 font-mono shrink-0">
                                {n.createdAt}
                              </span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Inline Note Composer */}
                    {isComposerOpen && (
                      <div className="bg-blue-50/80 border border-blue-200 rounded-xl p-3 space-y-2 animate-in fade-in">
                        <label className="block text-xs font-bold text-[#002D62]">
                          Add Internal Remark / Note for Tender {tender.tenderRefNo}:
                        </label>
                        <div className="flex flex-col sm:flex-row items-center gap-2">
                          <input
                            type="text"
                            value={noteInputText}
                            onChange={(e) => setNoteInputText(e.target.value)}
                            placeholder="Enter remarks (e.g. Joint Venture partner agreed, Pre-bid query raised, EMD submitted)..."
                            className="flex-1 bg-white border border-slate-300 text-xs px-3 py-2 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-[#002D62] w-full"
                          />
                          <div className="flex items-center space-x-2 w-full sm:w-auto">
                            <button
                              type="button"
                              onClick={() => handleSaveNote(tender.id)}
                              className="bg-[#002D62] hover:bg-[#001D42] text-white text-xs font-bold px-4 py-2 rounded-lg transition-all shadow-xs flex-1 sm:flex-initial"
                            >
                              Save Note
                            </button>
                            <button
                              type="button"
                              onClick={() => {
                                setActiveNoteComposerTenderId(null);
                                setNoteInputText('');
                              }}
                              className="bg-white hover:bg-slate-100 text-slate-600 text-xs font-bold px-3 py-2 rounded-lg border border-slate-300"
                            >
                              Cancel
                            </button>
                          </div>
                        </div>
                      </div>
                    )}

                    {/* Footer Details & Action Bar */}
                    <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-3 border-t border-slate-100 text-xs">
                      <div className="flex items-center space-x-4 text-slate-500 font-medium text-[11px]">
                        <span>EMD: <strong className="text-slate-800">{tender.emdAmount}</strong></span>
                        <span>Doc Fee: <strong className="text-slate-800">{tender.documentFee}</strong></span>
                      </div>

                      <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
                        <button
                          onClick={() => onToggleSaveTender(tender.id)}
                          className={`px-3 py-2 rounded-xl text-xs font-bold flex items-center space-x-1 transition-colors border ${
                            isSaved
                              ? 'bg-amber-50 text-amber-800 border-amber-300'
                              : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                          }`}
                        >
                          <Bookmark className={`w-3.5 h-3.5 ${isSaved ? 'fill-amber-500 text-amber-500' : ''}`} />
                          <span>{isSaved ? 'Tracked' : 'Track'}</span>
                        </button>

                        <button
                          onClick={() => {
                            if (isComposerOpen) {
                              setActiveNoteComposerTenderId(null);
                            } else {
                              setActiveNoteComposerTenderId(tender.id);
                              setNoteInputText('');
                            }
                          }}
                          className="px-3 py-2 rounded-xl text-xs font-bold flex items-center space-x-1.5 transition-colors border bg-white text-blue-900 border-blue-200 hover:bg-blue-50"
                        >
                          <Plus className="w-3.5 h-3.5 text-blue-700" />
                          <span>Add Note</span>
                        </button>

                        <button
                          onClick={() => handleDownloadNIT(tender)}
                          className="px-3 py-2 rounded-xl text-xs font-bold flex items-center space-x-1 transition-colors border bg-slate-100 hover:bg-slate-200 text-slate-800 border-slate-300"
                          title="Download Official NIT Document File"
                        >
                          <Download className="w-3.5 h-3.5 text-slate-600" />
                          <span>Download NIT</span>
                        </button>

                        {/* Official Source Portal Direct Link */}
                        <a
                          href={tender.officialPortalUrl || (tender.isGeMTender ? 'https://gem.gov.in' : tender.authority?.includes('Railway') ? 'https://www.ireps.gov.in' : tender.authority?.includes('Defence') ? 'https://defproc.gov.in' : 'https://eprocure.gov.in/eprocure/app')}
                          target="_blank"
                          rel="noreferrer"
                          className="px-3 py-2 rounded-xl text-xs font-bold flex items-center space-x-1 transition-colors border bg-emerald-50 hover:bg-emerald-100 text-emerald-900 border-emerald-300"
                          title="Open official procurement portal notice in new tab"
                        >
                          <Globe className="w-3.5 h-3.5 text-emerald-700" />
                          <span>Official Portal</span>
                          <ExternalLink className="w-3 h-3 text-emerald-600 ml-0.5" />
                        </a>

                        <button
                          onClick={() => onOpenTenderDetails(tender)}
                          className="flex-1 sm:flex-initial bg-[#002D62] hover:bg-[#001D42] text-white font-extrabold px-4 py-2 rounded-xl flex items-center justify-center space-x-1.5 transition-all shadow-2xs text-xs"
                        >
                          <FileText className="w-3.5 h-3.5" />
                          <span>View Document</span>
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* Pagination Controls */}
          {filteredTenders.length > itemsPerPage && (
            <div className="flex flex-col md:flex-row items-center justify-between gap-3 bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs pt-4 overflow-hidden">
              <div className="text-xs text-slate-600 font-semibold shrink-0">
                Page <span className="font-extrabold text-slate-900">{currentPage}</span> of <span className="font-extrabold text-slate-900">{totalPages}</span>
              </div>

              <div className="flex items-center space-x-1 max-w-full overflow-x-auto py-1 px-1">
                <button
                  disabled={currentPage === 1}
                  onClick={() => {
                    const newPage = Math.max(currentPage - 1, 1);
                    setCurrentPage(newPage);
                    if (onSyncLiveTenders) {
                      onSyncLiveTenders({
                        q: searchQuery,
                        state: selectedState,
                        category: selectedCategory,
                        department: selectedDepartment,
                        page: newPage
                      });
                    }
                  }}
                  className="px-3 py-2 rounded-xl border border-slate-200 text-xs font-bold text-slate-700 hover:bg-slate-50 disabled:opacity-40 disabled:cursor-not-allowed flex items-center space-x-1 shrink-0"
                >
                  <ChevronLeft className="w-4 h-4" />
                  <span>Previous</span>
                </button>

                {/* First page shortcut if window starts > 1 */}
                {getVisiblePages(currentPage, totalPages)[0] > 1 && (
                  <>
                    <button
                      onClick={() => {
                        setCurrentPage(1);
                        if (onSyncLiveTenders) {
                          onSyncLiveTenders({
                            q: searchQuery,
                            state: selectedState,
                            category: selectedCategory,
                            department: selectedDepartment,
                            page: 1
                          });
                        }
                      }}
                      className="w-9 h-9 rounded-xl text-xs font-extrabold transition-all border bg-white text-slate-700 border-slate-200 hover:bg-slate-50 shrink-0"
                    >
                      1
                    </button>
                    {getVisiblePages(currentPage, totalPages)[0] > 2 && (
                      <span className="px-1 text-slate-400 font-bold text-xs select-none shrink-0">...</span>
                    )}
                  </>
                )}

                {/* Maximum 10 visible serial numbers */}
                {getVisiblePages(currentPage, totalPages).map((pageNum) => (
                  <button
                    key={pageNum}
                    onClick={() => {
                      setCurrentPage(pageNum);
                      if (onSyncLiveTenders) {
                        onSyncLiveTenders({
                          q: searchQuery,
                          state: selectedState,
                          category: selectedCategory,
                          department: selectedDepartment,
                          page: pageNum
                        });
                      }
                    }}
                    className={`w-9 h-9 rounded-xl text-xs font-extrabold transition-all border shrink-0 ${
                      currentPage === pageNum
                        ? 'bg-[#002D62] text-white border-[#002D62]'
                        : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    {pageNum}
                  </button>
                ))}

                {/* Last page shortcut if window ends < totalPages */}
                {getVisiblePages(currentPage, totalPages)[getVisiblePages(currentPage, totalPages).length - 1] < totalPages && (
                  <>
                    {getVisiblePages(currentPage, totalPages)[getVisiblePages(currentPage, totalPages).length - 1] < totalPages - 1 && (
                      <span className="px-1 text-slate-400 font-bold text-xs select-none shrink-0">...</span>
                    )}
                    <button
                      onClick={() => {
                        setCurrentPage(totalPages);
                        if (onSyncLiveTenders) {
                          onSyncLiveTenders({
                            q: searchQuery,
                            state: selectedState,
                            category: selectedCategory,
                            department: selectedDepartment,
                            page: totalPages
                          });
                        }
                      }}
                      className="w-9 h-9 rounded-xl text-xs font-extrabold transition-all border bg-white text-slate-700 border-slate-200 hover:bg-slate-50 shrink-0"
                    >
                      {totalPages}
                    </button>
                  </>
                )}

                <button
                  disabled={currentPage === totalPages}
                  onClick={() => {
                    const newPage = Math.min(currentPage + 1, totalPages);
                    setCurrentPage(newPage);
                    if (onSyncLiveTenders) {
                      onSyncLiveTenders({
                        q: searchQuery,
                        state: selectedState,
                        category: selectedCategory,
                        department: selectedDepartment,
                        page: newPage
                      });
                    }
                  }}
                  className="px-3 py-2 rounded-xl border border-slate-200 text-xs font-bold text-slate-700 hover:bg-slate-50 disabled:opacity-40 disabled:cursor-not-allowed flex items-center space-x-1 shrink-0"
                >
                  <span>Next</span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {/* Quick Category & Portal Discovery Footer Bar */}
          <div className="mt-12 pt-8 border-t border-slate-200 space-y-8">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-xl font-extrabold text-slate-900">Explore Tenders by Categories & Portals</h3>
                <p className="text-xs text-slate-500 font-medium">Click any portal, state, or keyword filter below to instantly view matching tenders</p>
              </div>
              <button
                onClick={() => {
                  setSearchQuery('');
                  setSelectedState('All States');
                  setSelectedCategory('All Categories');
                  setSelectedDepartment('All Authorities & Departments');
                  setHasSearched(false);
                }}
                className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-xs font-bold text-slate-700 transition-colors"
              >
                Clear Filters & View Home Grid
              </button>
            </div>

            {/* Compact Quick Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 gap-3">
              {DISCOVERY_KEYWORDS.slice(0, 6).map((item, idx) => (
                <button
                  key={idx}
                  onClick={() => {
                    setSearchQuery(item.searchTerm);
                    setSelectedCategory('All Categories');
                    setSelectedState('All States');
                    setSelectedDepartment('All Authorities & Departments');
                    setCurrentPage(1);
                    const resultsEl = document.getElementById('tender-results-container');
                    if (resultsEl) resultsEl.scrollIntoView({ behavior: 'smooth' });
                  }}
                  className="p-3 bg-white border border-slate-200 hover:border-blue-400 rounded-xl flex items-center space-x-2 text-left group transition-all"
                >
                  <div className="w-6 h-6 shrink-0">{item.svg}</div>
                  <span className="text-xs font-extrabold text-slate-800 truncate group-hover:text-[#002D62]">{item.title}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
        </>
        )}
      </div>
    </div>
  );
};
