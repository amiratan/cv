import React from 'react';
import { MOCK_COMPETITORS } from '../data/mockData';
import { Users, Award, TrendingUp, ShieldCheck, MapPin, Search } from 'lucide-react';

export const CompetitorsView: React.FC = () => {
  return (
    <div className="flex-1 bg-[#f8fafc] overflow-y-auto p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto w-full">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-[#002D62] to-[#001D42] text-white p-6 sm:p-8 rounded-2xl shadow-sm text-center space-y-3 relative overflow-hidden">
        <div className="inline-flex items-center justify-center space-x-2 text-amber-400 font-extrabold text-xs uppercase tracking-wider">
          <Users className="w-4 h-4 text-[#E65100]" />
          <span>Competitor & Bidder Intelligence Portal</span>
        </div>
        <h1 className="text-xl sm:text-2xl font-black text-white tracking-tight">
          Top Government Contractors & Bidding Competitors
        </h1>
        <p className="text-xs sm:text-sm text-slate-300 max-w-2xl mx-auto">
          Track active bidding contractors, historical tender win rates, regional presence, and awarded contract values across Indian eProcurement portals.
        </p>
      </div>

        {/* Search / Filter Bar */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="relative flex-1 w-full">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
            <input
              type="text"
              placeholder="Search contractor name, sector, or state..."
              className="w-full pl-10 pr-4 py-2 text-xs font-semibold rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-[#002D62]"
            />
          </div>
          <div className="text-xs text-slate-500 font-semibold shrink-0">
            Tracking <strong className="text-slate-900">5 Major EPC Contractors</strong>
          </div>
        </div>

        {/* Competitors List Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {MOCK_COMPETITORS.map((comp, idx) => (
            <div
              key={idx}
              className="bg-white rounded-2xl border border-slate-200 hover:border-blue-400 shadow-2xs p-5 space-y-4 transition-all"
            >
              <div className="flex items-start justify-between gap-2">
                <div className="space-y-1">
                  <span className="bg-blue-50 text-[#002D62] text-[10px] font-extrabold px-2 py-0.5 rounded border border-blue-200">
                    {comp.category}
                  </span>
                  <h3 className="text-base font-black text-slate-900">{comp.name}</h3>
                </div>
                <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 px-3 py-1.5 rounded-xl text-center shrink-0">
                  <span className="text-[10px] uppercase font-extrabold text-emerald-700 block">L1 Win Rate</span>
                  <span className="text-base font-black">{comp.winRate}</span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs bg-slate-50 p-3 rounded-xl border border-slate-100">
                <div>
                  <span className="text-slate-400 text-[10px] font-extrabold uppercase block">Active Bids</span>
                  <span className="font-extrabold text-slate-800 text-sm">{comp.activeBids} Live Tenders</span>
                </div>
                <div>
                  <span className="text-slate-400 text-[10px] font-extrabold uppercase block">Total Awarded Cr</span>
                  <span className="font-extrabold text-[#002D62] text-sm">{comp.totalAwardedCr}</span>
                </div>
              </div>

              <div className="space-y-1 text-xs">
                <span className="text-slate-500 font-extrabold text-[11px] block">Top Active States:</span>
                <div className="flex flex-wrap gap-1.5">
                  {comp.topStates.map((st) => (
                    <span key={st} className="bg-slate-100 text-slate-700 px-2 py-0.5 rounded text-[11px] font-medium border border-slate-200 flex items-center space-x-1">
                      <MapPin className="w-3 h-3 text-slate-400" />
                      <span>{st}</span>
                    </span>
                  ))}
                </div>
              </div>

              <div className="text-xs text-slate-600 bg-amber-50/60 p-2.5 rounded-xl border border-amber-200/60 font-medium">
                <strong className="text-amber-900">Key Strengths:</strong> {comp.keyStrengths}
              </div>
            </div>
          ))}
        </div>
    </div>
  );
};
