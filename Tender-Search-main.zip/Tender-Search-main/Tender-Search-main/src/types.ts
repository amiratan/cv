export type ActiveTab =
  | 'search-center'
  | 'tender-results'
  | 'insurance'
  | 'authorities'
  | 'competitors'
  | 'pricing'
  | 'profile';

export type CategoryType =
  | 'All Categories'
  | 'Civil & Construction'
  | 'Road & Highways'
  | 'Account & Auditing'
  | 'Electrical & Power'
  | 'IT, Software & Telecom'
  | 'Solar & Renewable Energy'
  | 'Medical, Pharma & Healthcare'
  | 'Transport, Freight & Vehicles'
  | 'Security, Facility & Manpower'
  | 'Machinery & Industrial Goods';

export type DateRangeType =
  | 'all'
  | '7days'
  | '1month'
  | '6months'
  | '1year';

export type ProjectStatusType =
  | 'All Statuses'
  | 'Live / Active'
  | 'Under Evolution'
  | 'Tender Awarded';

export interface TenderNote {
  id: string;
  tenderId: string;
  noteNumber: number;
  text: string;
  createdAt: string;
}

export interface TenderItem {
  id: string;
  tenderRefNo: string;
  title: string;
  authority: string;
  departmentCategory: 'Railways' | 'CPWD / PWD' | 'NHAI & Highways' | 'PSU Energy' | 'Defense & MES' | 'Smart City & Municipal' | 'Healthcare & PSU' | 'Financial Services' | 'IT & Smart City' | string;
  state: string;
  city: string;
  estimatedValue: string;
  valueNumericInLakhs: number; // e.g. 45.8, 1250
  emdAmount: string;
  documentFee: string;
  closingDate: string;
  daysRemaining: number;
  category: CategoryType;
  isGeMTender: boolean;
  msmeExemptionAvailable: boolean;
  publishedDate: string;
  summary: string;
  dataSource: string;
  portalName?: string;
  officialPortalUrl?: string;
  projectStatus: 'Live / Active' | 'Under Evolution' | 'Tender Awarded';
  participatingContractors?: string[];
  notes?: TenderNote[];
  scopeOfWork: string[];
  eligibilityCriteria: {
    minTurnover: string;
    similarWorkExperience: string;
    classRegistration: string;
  };
  keyMilestones: {
    preBidMeetingDate: string;
    techBidOpeningDate: string;
    financialBidOpeningDate: string;
  };
}

export interface TenderResultItem {
  id: string;
  tenderRefNo: string;
  title: string;
  authority: string;
  state: string;
  category: string;
  estimatedValue: string;
  winningBidder: string;
  winningAmount: string;
  awardDate: string;
  publishedDate: string;
  dataSource: 'indextender.in' | 'tender.co.in' | 'cppp.gov.in' | 'gem.gov.in';
  biddersCount: number;
  status: 'Awarded' | 'Cancelled' | 'Retendered';
}

export interface InsurancePolicyQuote {
  insuranceType: 'Bid Security Insurance' | 'Performance Guarantee Bond' | 'Contractor All Risk (CAR)' | 'Workmen Compensation' | 'Advance Payment Guarantee';
  tenderValueLakhs: number;
  requiredCoverageLakhs: number;
  estimatedPremium: string;
  validityPeriod: string;
  approvedProviders: string[];
}

export interface StateHubInfo {
  stateName: string;
  code: string;
  activeTendersCount: number;
  totalValueCrores: string;
  topDepartment: string;
  iconBg: string;
  isUT?: boolean;
}

export interface AuthorityInfo {
  id: string;
  name: string;
  shortName: string;
  type: 'Central Ministry' | 'PSU' | 'Railways' | 'State Dept' | 'Defense' | 'Smart City' | 'Port Trust' | 'Energy';
  activeTenders: number;
  location: string;
  logoColor: string;
}

export interface AITenderMatchRequest {
  companyName: string;
  annualTurnoverLakhs: number;
  preferredStates: string[];
  productKeywords: string;
  pastProjectValueLakhs: number;
  hasMSMERegistration: boolean;
}

export interface AITenderMatchResult {
  summary: string;
  overallEligibilityScore: number; // 0 - 100
  recommendedTenderIds: string[];
  keyStrengths: string[];
  potentialBottlenecks: string[];
  actionableSteps: string[];
}

export interface PaymentInvoice {
  id: string;
  date: string;
  description: string;
  amount: string;
  taxAmount: string;
  status: 'Paid' | 'Processing' | 'Failed';
  invoiceUrl: string;
}

export interface SubAccountControls {
  emailNotifications: boolean;
  smsAlerts: boolean;
  whatsappUpdates: boolean;
  allowSubUsers: boolean;
  autoTrackNewTenders: boolean;
  rolePermissions: 'Admin' | 'Manager' | 'Viewer';
  dailyDigestTime: string;
}

export interface UserProfile {
  name: string;
  email: string;
  mobile: string;
  address: string;
  gender: 'Male' | 'Female' | 'Other' | 'Prefer not to say';
  dateOfBirth: string;
  avatarBgColor: string;

  // Billing and Settings
  gstNumber: string;
  panNumber: string;
  companyName: string;
  billingAddress: string;
  paymentHistory: PaymentInvoice[];

  // My Account Controls & Security
  subAccountControls: SubAccountControls;
  twoFactorEnabled: boolean;
  twoFactorMethod: 'Gmail OTP' | 'Authenticator App' | 'SMS OTP';
  twoFactorPhoneOrEmail: string;
  backupCodes: string[];
  activeSessions: {
    id: string;
    device: string;
    ip: string;
    location: string;
    lastActive: string;
    current: boolean;
  }[];
}
