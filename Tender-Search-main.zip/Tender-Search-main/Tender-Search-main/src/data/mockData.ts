import { TenderItem, StateHubInfo, AuthorityInfo, TenderResultItem } from '../types';

export const ALL_INDIAN_STATES = [
  'All States',
  'Andhra Pradesh',
  'Arunachal Pradesh',
  'Assam',
  'Bihar',
  'Chhattisgarh',
  'Goa',
  'Gujarat',
  'Haryana',
  'Himachal Pradesh',
  'Jharkhand',
  'Karnataka',
  'Kerala',
  'Madhya Pradesh',
  'Maharashtra',
  'Manipur',
  'Meghalaya',
  'Mizoram',
  'Nagaland',
  'Odisha',
  'Punjab',
  'Rajasthan',
  'Sikkim',
  'Tamil Nadu',
  'Telangana',
  'Tripura',
  'Uttar Pradesh',
  'Uttarakhand',
  'West Bengal',
  'Andaman and Nicobar Islands (UT)',
  'Chandigarh (UT)',
  'Dadra and Nagar Haveli and Daman and Diu (UT)',
  'Delhi NCR (UT)',
  'Jammu and Kashmir (UT)',
  'Ladakh (UT)',
  'Lakshadweep (UT)',
  'Puducherry (UT)'
];

export const ALL_GOVERNMENT_AUTHORITIES = [
  'All Authorities & Departments',
  'Central Public Works Department (CPWD)',
  'Indian Railways (IREPS / Zonal Railways)',
  'Military Engineer Services (MES Defence)',
  'National Highways Authority of India (NHAI)',
  'GeM - Government e-Marketplace',
  'NTPC Limited',
  'Bharat Heavy Electricals Limited (BHEL)',
  'Indian Oil Corporation (IOCL)',
  'Oil & Natural Gas Corporation (ONGC)',
  'Bharat Petroleum Corporation (BPCL)',
  'Power Grid Corporation of India (POWERGRID)',
  'State Public Works Departments (PWD)',
  'Jal Jeevan Mission & State Jal Nigams',
  'Urban Local Bodies & Municipal Corporations (BMC/MCD/BBMP/AMC)',
  'Smart City Development Corporations',
  'Delhi Metro Rail Corporation (DMRC) & Metro Corps',
  'Port Trusts & Inland Waterways Authority (IWAI)',
  'Airport Authority of India (AAI)',
  'Hindustan Aeronautics Limited (HAL)',
  'Border Roads Organisation (BRO)',
  'Coal India Limited (CIL)',
  'Steel Authority of India Limited (SAIL)',
  'National Thermal Power & Solar Energy Corporation (SECI)'
];

export const INITIAL_TENDERS: TenderItem[] = [
  {
    id: 'tk-1001',
    tenderRefNo: 'CR/BB/CIVIL/2026/894',
    title: 'Construction of 4-Lane Rail Over Bridge (ROB) & Approach Roads at Km 142/6-8 near Kalyan Yard',
    authority: 'Indian Railways (IREPS / Zonal Railways)',
    departmentCategory: 'Railways',
    state: 'Maharashtra',
    city: 'Mumbai / Thane',
    estimatedValue: '₹ 42.85 Crores',
    valueNumericInLakhs: 4285,
    emdAmount: '₹ 21.42 Lakhs',
    documentFee: '₹ 10,000',
    closingDate: '2026-08-04 (15:00 Hrs)',
    daysRemaining: 11,
    category: 'Civil & Construction',
    isGeMTender: false,
    msmeExemptionAvailable: true,
    publishedDate: '2026-07-20',
    dataSource: 'indextender.in',
    projectStatus: 'Live / Active',
    participatingContractors: ['L&T Construction', 'J Kumar Infraprojects', 'Dilip Buildcon', 'NCC Limited'],
    notes: [
      { id: 'n1', tenderId: 'tk-1001', noteNumber: 1, text: 'Checked eligibility for Class I Railway registration. Joint Venture allowed.', createdAt: '2026-07-22 10:15 AM' }
    ],
    summary: 'EPC Contract for construction of two-lane ROB replacing level crossing no. 48 with RCC piers, composite steel girders, street lighting, and bituminous approach pavement.',
    scopeOfWork: [
      'Piling works for foundation piers (1200mm diameter cast-in-situ piles)',
      'Fabrication & launching of 45m span composite steel plate girders',
      'Construction of RCC retaining walls and RE wall embankment',
      'Provision of LED street illumination, drainage, and safety signage'
    ],
    eligibilityCriteria: {
      minTurnover: '₹ 12.85 Crores (Average annual turnover in last 3 financial years)',
      similarWorkExperience: 'Completion of 1 single similar ROB/Flyover work costing >= ₹ 25.7 Crores',
      classRegistration: 'Class I Approved Super Special Railway Contractor or Highways License'
    },
    keyMilestones: {
      preBidMeetingDate: '2026-07-28 at 11:00 AM (DRM Office CSMT)',
      techBidOpeningDate: '2026-08-04 at 15:30 Hrs',
      financialBidOpeningDate: '2026-08-12 at 11:00 Hrs'
    }
  },
  {
    id: 'tk-1002',
    tenderRefNo: 'CPWD/DELHI/ELECT/2026/412',
    title: 'Supply, Installation, Testing & Commissioning of 500 KW Grid-Connected Rooftop Solar PV System at AIIMS Campus',
    authority: 'Central Public Works Department (CPWD)',
    departmentCategory: 'CPWD / PWD',
    state: 'Delhi NCR (UT)',
    city: 'New Delhi',
    estimatedValue: '₹ 3.25 Crores',
    valueNumericInLakhs: 325,
    emdAmount: '₹ 6.50 Lakhs',
    documentFee: '₹ 2,500',
    closingDate: '2026-07-31 (14:30 Hrs)',
    daysRemaining: 7,
    category: 'Solar & Renewable Energy',
    isGeMTender: true,
    msmeExemptionAvailable: true,
    publishedDate: '2026-07-18',
    dataSource: 'tender.co.in',
    projectStatus: 'Live / Active',
    participatingContractors: ['Waaree Energies', 'Sterling & Wilson', 'Tata Power Solar', 'Jakson Group'],
    notes: [
      { id: 'n2', tenderId: 'tk-1002', noteNumber: 1, text: 'MSME EMD exemption is applicable. Need to upload Udyam registration certificate.', createdAt: '2026-07-21 02:30 PM' }
    ],
    summary: 'Turnkey execution of 500 KWp rooftop solar PV plant with net-metering, string inverters, remote SCADA telemetry monitoring, and 5 years comprehensive O&M.',
    scopeOfWork: [
      'Supply of Tier-1 Mono-PERC solar PV modules (>= 540Wp capacity)',
      'HDG mounting structures with elevated tilt angle for rooftop slab',
      'Net-metering synchronisation with BSES Rajdhani Discom grid',
      'Continuous 5-Year Operation & Preventive Maintenance'
    ],
    eligibilityCriteria: {
      minTurnover: '₹ 97.5 Lakhs in any one of the last 3 financial years',
      similarWorkExperience: 'Completed 1 solar project >= 400 KWp or 2 projects >= 250 KWp',
      classRegistration: 'CPWD Electrical Category Class I or MNRE Empanelled Channel Partner'
    },
    keyMilestones: {
      preBidMeetingDate: '2026-07-25 at 14:00 Hrs (Online VC)',
      techBidOpeningDate: '2026-07-31 at 15:00 Hrs',
      financialBidOpeningDate: '2026-08-05 at 11:30 Hrs'
    }
  },
  {
    id: 'tk-1003',
    tenderRefNo: 'NHAI/PIU-BLR/HW/2026/05',
    title: 'Widening to 6-Lane with Elevated Corridor & Service Roads on NH-44 Bengaluru to Hosur Section (Km 21 to 38)',
    authority: 'National Highways Authority of India (NHAI)',
    departmentCategory: 'NHAI & Highways',
    state: 'Karnataka',
    city: 'Bengaluru / Electronics City',
    estimatedValue: '₹ 345.00 Crores',
    valueNumericInLakhs: 34500,
    emdAmount: '₹ 3.45 Crores',
    documentFee: '₹ 25,000',
    closingDate: '2026-08-18 (11:00 Hrs)',
    daysRemaining: 25,
    category: 'Civil & Construction',
    isGeMTender: false,
    msmeExemptionAvailable: false,
    publishedDate: '2026-07-15',
    dataSource: 'indextender.in',
    projectStatus: 'Under Evolution',
    participatingContractors: ['KNR Constructions', 'GR Infraprojects', 'Megha Engineering (MEIL)', 'L&T Construction'],
    notes: [
      { id: 'n3', tenderId: 'tk-1003', noteNumber: 1, text: 'Pre-bid meeting queries regarding utility shifting submitted on NHAI portal.', createdAt: '2026-07-19 04:10 PM' },
      { id: 'n4', tenderId: 'tk-1003', noteNumber: 2, text: 'NHAI issued Corrigendum No. 1 - Submission date temporarily extended/on hold pending land acquisition review.', createdAt: '2026-07-23 11:00 AM' }
    ],
    summary: 'Hybrid Annuity Mode (HAM) EPC highway expansion contract including 4.2 km elevated viaduct, smart toll plaza plaza installation, and noise barriers.',
    scopeOfWork: [
      'Flexible and rigid pavement construction with SMA bituminous overlay',
      'Erection of 180 precast segmental girders for elevated section',
      'Advanced Traffic Management Systems (ATMS) & FASTag electronic tolling',
      'Utility shifting (water pipelines, high tension electric lines)'
    ],
    eligibilityCriteria: {
      minTurnover: '₹ 103.5 Crores in last 3 financial years',
      similarWorkExperience: 'Successfully completed 1 national highway / elevated viaduct project >= ₹ 207 Crores',
      classRegistration: 'Ministry of Road Transport & Highways Class 1-A National EPC License'
    },
    keyMilestones: {
      preBidMeetingDate: '2026-07-30 at 11:00 Hrs (NHAI HQ Dwarka)',
      techBidOpeningDate: '2026-08-18 at 11:30 Hrs',
      financialBidOpeningDate: '2026-08-28 at 15:00 Hrs'
    }
  },
  {
    id: 'tk-1004',
    tenderRefNo: 'NTPC/SIMHADRI/MECH/2026/78',
    title: 'Annual Maintenance Contract for Flue Gas Desulfurization (FGD) Plant & Coal Handling System at Simhadri Super Thermal Power Station (2000 MW)',
    authority: 'NTPC Limited',
    departmentCategory: 'PSU Energy',
    state: 'Andhra Pradesh',
    city: 'Visakhapatnam',
    estimatedValue: '₹ 14.50 Crores',
    valueNumericInLakhs: 1450,
    emdAmount: '₹ 14.50 Lakhs',
    documentFee: '₹ 5,000',
    closingDate: '2026-08-10 (16:00 Hrs)',
    daysRemaining: 17,
    category: 'Machinery & Industrial Goods',
    isGeMTender: true,
    msmeExemptionAvailable: true,
    publishedDate: '2026-07-12',
    dataSource: 'gem.gov.in',
    projectStatus: 'Live / Active',
    participatingContractors: ['BHEL', 'Thermax Ltd', 'GE Power India', 'L&T Energy'],
    summary: 'Comprehensive mechanical overhauling, slurry pump replacements, conveyor belt vulcanising, and limestone absorber slurry maintenance.',
    scopeOfWork: [
      'Preventive and breakdown maintenance of 4 units FGD absorbers',
      'Conveyor belt splicing, roller replacements, and drive gearbox repairs',
      'High-pressure water jet cleaning of heat exchangers and cooling towers',
      'Deputation of 85 skilled mechanical fitters, riggers, and certified welders'
    ],
    eligibilityCriteria: {
      minTurnover: '₹ 4.35 Crores annual turnover',
      similarWorkExperience: 'Executed 1 single AMC contract in thermal power plant FGD/CHP costing >= ₹ 8.7 Crores',
      classRegistration: 'NTPC Vendor Enrolment Category Mechanised Plant Operations'
    },
    keyMilestones: {
      preBidMeetingDate: '2026-07-29 at 10:30 Hrs',
      techBidOpeningDate: '2026-08-10 at 16:30 Hrs',
      financialBidOpeningDate: '2026-08-17 at 11:00 Hrs'
    }
  },
  {
    id: 'tk-1005',
    tenderRefNo: 'MES/PUNE/ZONE/2026/102',
    title: 'Special Repairs to Specialised Hangars, Runway Apron Markings & Solar Lighting at Air Force Station Lohegaon',
    authority: 'Military Engineer Services (MES Defence)',
    departmentCategory: 'Defense & MES',
    state: 'Maharashtra',
    city: 'Pune',
    estimatedValue: '₹ 8.90 Crores',
    valueNumericInLakhs: 890,
    emdAmount: '₹ 8.90 Lakhs',
    documentFee: '₹ 2,000',
    closingDate: '2026-08-02 (12:00 Hrs)',
    daysRemaining: 9,
    category: 'Civil & Construction',
    isGeMTender: false,
    msmeExemptionAvailable: true,
    publishedDate: '2026-07-10',
    dataSource: 'tender.co.in',
    projectStatus: 'Under Evolution',
    participatingContractors: ['Supreme Infrastructure', 'Rohan Builders', 'Unity Infraprojects'],
    notes: [
      { id: 'n5', tenderId: 'tk-1005', noteNumber: 1, text: 'Previously cancelled due to single bid qualification. Re-floated as Retender with revised BOQ.', createdAt: '2026-07-15 09:00 AM' }
    ],
    summary: 'Renovation of aircraft maintenance hangars with epoxy floor coating, anti-static flooring, perimeter security lighting, and runway micro-surfacing.',
    scopeOfWork: [
      'Application of 3mm heavy-duty anti-static epoxy coating in hangar bays',
      'Thermoplastic airfield marking paint for runway and taxiways',
      'Installation of 120 standalone solar LED mast lights with lithium battery storage',
      'Structural steel truss corrosion treatment and PU painting'
    ],
    eligibilityCriteria: {
      minTurnover: '₹ 2.67 Crores in last 3 financial years',
      similarWorkExperience: 'Completed similar facility management contract in Defense / PSU / Airports',
      classRegistration: 'MES Enlisted Class S Facility Management Contractor'
    },
    keyMilestones: {
      preBidMeetingDate: '2026-07-29 at 12:00 Hrs',
      techBidOpeningDate: '2026-08-02 at 12:30 Hrs',
      financialBidOpeningDate: '2026-08-09 at 14:00 Hrs'
    }
  },
  {
    id: 'tk-1006',
    tenderRefNo: 'BMC/HEALTH/SION/2026/88',
    title: 'Procurement of High-End Dual-Source 128-Slice Cardiac CT Scanner Machine with 5 Years CAMC for Lokmanya Tilak Municipal Hospital',
    authority: 'Urban Local Bodies & Municipal Corporations (BMC/MCD/BBMP/AMC)',
    departmentCategory: 'Healthcare & PSU',
    state: 'Maharashtra',
    city: 'Mumbai / Sion',
    estimatedValue: '₹ 11.20 Crores',
    valueNumericInLakhs: 1120,
    emdAmount: '₹ 11.20 Lakhs',
    documentFee: '₹ 15,000',
    closingDate: '2026-08-14 (15:00 Hrs)',
    daysRemaining: 21,
    category: 'Medical, Pharma & Healthcare',
    isGeMTender: true,
    msmeExemptionAvailable: true,
    publishedDate: '2026-06-25',
    dataSource: 'gem.gov.in',
    projectStatus: 'Live / Active',
    participatingContractors: ['Siemens Healthineers India', 'GE Healthcare India', 'Philips Medical Systems'],
    summary: 'Global tender for turnkey supply, civil room preparation, radiation shielding, AERB license assistance, and 5-Year Comprehensive Annual Maintenance Contract (CAMC).',
    scopeOfWork: [
      'Supply of 128-Slice Cardiac CT Scanner with AI motion artifact reduction',
      'Lead glass shielding, interior air conditioning, and 100 KVA online UPS system',
      'Training of senior radiology technicians and radiographers',
      'Comprehensive maintenance including X-Ray tube replacements for 5 years'
    ],
    eligibilityCriteria: {
      minTurnover: '₹ 3.36 Crores per annum',
      similarWorkExperience: 'OEM or Authorized Indian Distributor having installed at least 3 CT scanners in Govt Medical Colleges',
      classRegistration: 'AERB Approved Medical Equipment Importer / Manufacturer'
    },
    keyMilestones: {
      preBidMeetingDate: '2026-07-31 at 11:00 Hrs (BMC HQ Fort)',
      techBidOpeningDate: '2026-08-14 at 15:30 Hrs',
      financialBidOpeningDate: '2026-08-21 at 12:00 Hrs'
    }
  },
  {
    id: 'tk-1007',
    tenderRefNo: 'JAL-NIGAM/LKO/JJM/2026/19',
    title: 'Execution of Rural Piped Water Supply Schemes under Jal Jeevan Mission covering 84 Villages in Hardoi District',
    authority: 'Jal Jeevan Mission & State Jal Nigams',
    departmentCategory: 'CPWD / PWD',
    state: 'Uttar Pradesh',
    city: 'Lucknow / Hardoi',
    estimatedValue: '₹ 64.20 Crores',
    valueNumericInLakhs: 6420,
    emdAmount: '₹ 64.20 Lakhs',
    documentFee: '₹ 20,000',
    closingDate: '2026-08-06 (12:00 Hrs)',
    daysRemaining: 13,
    category: 'Civil & Construction',
    isGeMTender: false,
    msmeExemptionAvailable: true,
    publishedDate: '2026-05-18',
    dataSource: 'indextender.in',
    projectStatus: 'Tender Awarded',
    participatingContractors: ['NCC Limited', 'NCC-PNC Infratech JV', 'Dilip Buildcon', 'Welspun Enterprises'],
    notes: [
      { id: 'n6', tenderId: 'tk-1007', noteNumber: 1, text: 'Financial bid opened. NCC-PNC Infratech JV emerged as L1 lowest bidder.', createdAt: '2026-07-18 03:45 PM' }
    ],
    summary: 'Tube well drilling, Overhead Service Reservoirs (OHSR), HDPE distribution pipeline network laying, household functional tap connections (FHTC), and solar pumping sets.',
    scopeOfWork: [
      'Drilling of 84 deep tube wells (up to 200m depth) with gravel packing',
      'Construction of 42 RCC Overhead Service Reservoirs (150 KL to 300 KL capacity)',
      'Laying of 310 Km HDPE distribution pipeline network',
      'Installation of 14,200 Functional Household Tap Connections (FHTC)'
    ],
    eligibilityCriteria: {
      minTurnover: '₹ 19.26 Crores per annum over last 3 years',
      similarWorkExperience: 'Completed 1 road work or water supply project costing >= ₹ 38 Crores',
      classRegistration: 'UP PWD Class A Water Works Registration'
    },
    keyMilestones: {
      preBidMeetingDate: '2026-07-27 at 11:30 Hrs',
      techBidOpeningDate: '2026-08-06 at 12:30 Hrs',
      financialBidOpeningDate: '2026-08-13 at 15:00 Hrs'
    }
  },
  {
    id: 'tk-1008',
    tenderRefNo: 'PWD/UP/HW/2026/304',
    title: 'Widening, Resurfacing & Construction of 4-Lane Road & Highways Corridor with Concrete Pavement & Culverts',
    authority: 'State Public Works Departments (PWD)',
    departmentCategory: 'CPWD / PWD',
    state: 'Uttar Pradesh',
    city: 'Lucknow / Kanpur',
    estimatedValue: '₹ 88.50 Crores',
    valueNumericInLakhs: 8850,
    emdAmount: '₹ 88.50 Lakhs',
    documentFee: '₹ 25,000',
    closingDate: '2026-08-20 (17:00 Hrs)',
    daysRemaining: 27,
    category: 'Road & Highways',
    isGeMTender: false,
    msmeExemptionAvailable: true,
    publishedDate: '2026-07-22',
    dataSource: 'tenderkart.in',
    projectStatus: 'Live / Active',
    participatingContractors: ['PNC Infratech', 'Dilip Buildcon', 'GR Infraprojects'],
    summary: 'EPC contract for road widening, highway resurfacing, bituminous concrete macadam layer, road safety barriers, and solar blinkers.',
    scopeOfWork: [
      'Excavation and sub-grade compaction for 42 km road stretch',
      'Dense Bituminous Macadam (DBM) and Bituminous Concrete (BC) overlay',
      'Installation of crash barriers, signages, and solar road studs'
    ],
    eligibilityCriteria: {
      minTurnover: '₹ 26.55 Crores annual turnover',
      similarWorkExperience: 'Completed 1 road/highway project >= ₹ 44 Crores',
      classRegistration: 'Class A UP PWD Enlisted Contractor'
    },
    keyMilestones: {
      preBidMeetingDate: '2026-08-05 at 11:00 AM',
      techBidOpeningDate: '2026-08-20 at 17:30 Hrs',
      financialBidOpeningDate: '2026-08-27 at 11:00 Hrs'
    }
  },
  {
    id: 'tk-1009',
    tenderRefNo: 'FIN/CAG/AUDIT/2026/112',
    title: 'Empanelment of Chartered Accountant (CA) Firms for Account & Auditing Services, Statutory Audit & GST Filings',
    authority: 'GeM - Government e-Marketplace',
    departmentCategory: 'Financial Services',
    state: 'Delhi NCR (UT)',
    city: 'New Delhi',
    estimatedValue: '₹ 1.85 Crores',
    valueNumericInLakhs: 185,
    emdAmount: '₹ 3.70 Lakhs',
    documentFee: '₹ 1,500',
    closingDate: '2026-08-15 (15:00 Hrs)',
    daysRemaining: 22,
    category: 'Account & Auditing',
    isGeMTender: true,
    msmeExemptionAvailable: true,
    publishedDate: '2026-07-20',
    dataSource: 'gem.gov.in',
    projectStatus: 'Live / Active',
    participatingContractors: ['KPMG India', 'Deloitte India', 'EY India'],
    summary: 'Services tender for external financial audit, internal compliance auditing, GST reconciliation, and balance sheet certification.',
    scopeOfWork: [
      'Statutory & internal auditing of financial statements for FY 2026-27',
      'Tax audit under Section 44AB and GST annual reconciliation',
      'Asset verification and physical inventory audit'
    ],
    eligibilityCriteria: {
      minTurnover: '₹ 50 Lakhs annual fee billing',
      similarWorkExperience: 'Minimum 5 years standing CA firm with CAG empanelment',
      classRegistration: 'ICAI Registered Partnership Firm'
    },
    keyMilestones: {
      preBidMeetingDate: '2026-08-01 at 12:00 Hrs',
      techBidOpeningDate: '2026-08-15 at 15:30 Hrs',
      financialBidOpeningDate: '2026-08-22 at 11:00 Hrs'
    }
  },
  {
    id: 'tk-1010',
    tenderRefNo: 'IT/SMARTCITY/CLOUD/2026/501',
    title: 'Development, Deployment & Maintenance of Integrated IT Software, Citizen Portal & Enterprise Mobile Application',
    authority: 'Smart City Development Corporations',
    departmentCategory: 'IT & Smart City',
    state: 'Karnataka',
    city: 'Bengaluru',
    estimatedValue: '₹ 18.40 Crores',
    valueNumericInLakhs: 1840,
    emdAmount: '₹ 18.40 Lakhs',
    documentFee: '₹ 5,000',
    closingDate: '2026-08-22 (16:00 Hrs)',
    daysRemaining: 29,
    category: 'IT, Software & Telecom',
    isGeMTender: true,
    msmeExemptionAvailable: true,
    publishedDate: '2026-07-19',
    dataSource: 'tenderkart.in',
    projectStatus: 'Live / Active',
    participatingContractors: ['TCS', 'Infosys', 'Wipro', 'Tech Mahindra'],
    summary: 'Turnkey cloud software application development, AI analytics dashboard, mobile app for iOS/Android, and 3-year SLA support.',
    scopeOfWork: [
      'Microservices software architecture hosted on MeitY-empanelled cloud',
      'Integration of payment gateway, SMS/WhatsApp notifications, and GIS mapping',
      '24x7 SOC monitoring and cybersecurity vulnerability audit'
    ],
    eligibilityCriteria: {
      minTurnover: '₹ 5.5 Crores annual IT services revenue',
      similarWorkExperience: 'CMMI Level 3 or 5 certified software company',
      classRegistration: 'MeitY Cloud Vendor License'
    },
    keyMilestones: {
      preBidMeetingDate: '2026-08-03 at 11:00 AM',
      techBidOpeningDate: '2026-08-22 at 16:30 Hrs',
      financialBidOpeningDate: '2026-08-29 at 11:00 Hrs'
    }
  }
];

export const MOCK_COMPETITORS = [
  {
    name: 'L&T Construction & Infrastructure Ltd',
    category: 'Civil, Railways, Highways & Power',
    winRate: '78%',
    activeBids: 42,
    totalAwardedCr: '₹ 14,500 Cr',
    topStates: ['Maharashtra', 'Gujarat', 'Delhi NCR', 'Karnataka'],
    keyStrengths: 'EPC Mega-Projects, Railway Viaducts, Metro Corridors, Hydro Projects'
  },
  {
    name: 'NCC Limited (Nagarjuna Construction)',
    category: 'Water Supply, Buildings & Highways',
    winRate: '68%',
    activeBids: 28,
    totalAwardedCr: '₹ 6,200 Cr',
    topStates: ['Uttar Pradesh', 'Telangana', 'Andhra Pradesh', 'Bihar'],
    keyStrengths: 'Jal Jeevan Mission, Smart City Buildings, High-Rise Housing'
  },
  {
    name: 'Waaree Energies Green Solutions',
    category: 'Solar & Renewable Energy',
    winRate: '82%',
    activeBids: 35,
    totalAwardedCr: '₹ 2,800 Cr',
    topStates: ['Gujarat', 'Rajasthan', 'Maharashtra', 'Madhya Pradesh'],
    keyStrengths: 'Rooftop & Utility Solar PV, Battery Energy Storage, Microgrids'
  },
  {
    name: 'Kalpataru Projects International Ltd',
    category: 'Power Transmission, Oil & Gas Pipelines',
    winRate: '71%',
    activeBids: 21,
    totalAwardedCr: '₹ 5,100 Cr',
    topStates: ['West Bengal', 'Odisha', 'Assam', 'Madhya Pradesh'],
    keyStrengths: 'Cross-Country Pipelines, 765kV Sub-stations, Rail Electrification'
  },
  {
    name: 'Dilip Buildcon Limited',
    category: 'Roads, Bridges & Mining',
    winRate: '65%',
    activeBids: 19,
    totalAwardedCr: '₹ 4,900 Cr',
    topStates: ['Madhya Pradesh', 'Maharashtra', 'Karnataka', 'Rajasthan'],
    keyStrengths: 'Fast-Track Highway Paving, Tunnels, Coal Mining Operations'
  }
];

export const MOCK_TENDER_RESULTS: TenderResultItem[] = [
  {
    id: 'res-101',
    tenderRefNo: 'NHAI/DL-HR/2026/AOC-44',
    title: 'Construction of 6-Lane Access Controlled Highway Section on Dwarka Expressway (Km 12 to 24)',
    authority: 'National Highways Authority of India (NHAI)',
    state: 'Haryana',
    category: 'Civil & Construction',
    estimatedValue: '₹ 520.00 Crores',
    winningBidder: 'L&T Construction Infrastructure Ltd',
    winningAmount: '₹ 482.50 Crores',
    awardDate: '2026-07-21',
    publishedDate: '2026-04-10',
    dataSource: 'indextender.in',
    biddersCount: 6,
    status: 'Awarded'
  },
  {
    id: 'res-102',
    tenderRefNo: 'IREPS/WR/SOLAR/2026/AOC-12',
    title: 'Installation of 2.5 MW Solar Power Microgrid at Sabarmati Railway Station & Carriage Workshops',
    authority: 'Indian Railways (IREPS / Zonal Railways)',
    state: 'Gujarat',
    category: 'Solar & Renewable Energy',
    estimatedValue: '₹ 14.80 Crores',
    winningBidder: 'Waaree Energies Green Solutions Pvt Ltd',
    winningAmount: '₹ 12.95 Crores',
    awardDate: '2026-07-19',
    publishedDate: '2026-05-02',
    dataSource: 'tender.co.in',
    biddersCount: 8,
    status: 'Awarded'
  },
  {
    id: 'res-103',
    tenderRefNo: 'CPWD/BLR/IT-PARK/2026/AOC-08',
    title: 'Electrical & Automation Reticulation for Software Technology Parks of India (STPI) Campus',
    authority: 'Central Public Works Department (CPWD)',
    state: 'Karnataka',
    category: 'Electrical & Power',
    estimatedValue: '₹ 8.40 Crores',
    winningBidder: 'Sterling & Wilson Renewable Power Ltd',
    winningAmount: '₹ 7.80 Crores',
    awardDate: '2026-07-14',
    publishedDate: '2026-05-15',
    dataSource: 'cppp.gov.in',
    biddersCount: 5,
    status: 'Awarded'
  },
  {
    id: 'res-104',
    tenderRefNo: 'GeM/2026/B/8821092',
    title: 'Supply of 1,200 High Performance Laptops & Rugged Tablets for Ordnance Factory Board',
    authority: 'GeM - Government e-Marketplace',
    state: 'Tamil Nadu',
    category: 'IT, Software & Telecom',
    estimatedValue: '₹ 6.10 Crores',
    winningBidder: 'HCL Infosystems India Ltd',
    winningAmount: '₹ 5.45 Crores',
    awardDate: '2026-07-11',
    publishedDate: '2026-06-01',
    dataSource: 'gem.gov.in',
    biddersCount: 11,
    status: 'Awarded'
  },
  {
    id: 'res-105',
    tenderRefNo: 'IOCL/HALDIA/PIPE/2026/AOC-99',
    title: 'Cross-Country Underground Crude Oil Pipeline Trenching & Testing (80 Km Section)',
    authority: 'Indian Oil Corporation (IOCL)',
    state: 'West Bengal',
    category: 'Machinery & Industrial Goods',
    estimatedValue: '₹ 89.00 Crores',
    winningBidder: 'Kalpataru Projects International Ltd',
    winningAmount: '₹ 81.20 Crores',
    awardDate: '2026-06-28',
    publishedDate: '2026-03-20',
    dataSource: 'indextender.in',
    biddersCount: 4,
    status: 'Awarded'
  }
];

export const STATE_HUBS: StateHubInfo[] = [
  { stateName: 'Maharashtra', code: 'MH', activeTendersCount: 18450, totalValueCrores: '₹ 12,450 Cr', topDepartment: 'MSRDC, PWD, BMC & MMRDA', iconBg: 'bg-orange-500' },
  { stateName: 'Uttar Pradesh', code: 'UP', activeTendersCount: 16210, totalValueCrores: '₹ 10,890 Cr', topDepartment: 'UP PWD, UPEIDA, Jal Nigam', iconBg: 'bg-[#FF9933]' },
  { stateName: 'Delhi NCR (UT)', code: 'DL', activeTendersCount: 14890, totalValueCrores: '₹ 8,920 Cr', topDepartment: 'CPWD, DDA, DMRC, MCD', iconBg: 'bg-blue-600', isUT: true },
  { stateName: 'Gujarat', code: 'GJ', activeTendersCount: 12400, totalValueCrores: '₹ 9,150 Cr', topDepartment: 'GSRDC, GWSSB, PGVCL, AMC', iconBg: 'bg-amber-600' },
  { stateName: 'Karnataka', code: 'KA', activeTendersCount: 11800, totalValueCrores: '₹ 7,850 Cr', topDepartment: 'PWD Karnataka, BBMP, BWSSB', iconBg: 'bg-emerald-600' },
  { stateName: 'Tamil Nadu', code: 'TN', activeTendersCount: 10950, totalValueCrores: '₹ 6,940 Cr', topDepartment: 'Highways Dept, TANGEDCO, CMWSSB', iconBg: 'bg-indigo-600' },
  { stateName: 'West Bengal', code: 'WB', activeTendersCount: 8900, totalValueCrores: '₹ 5,410 Cr', topDepartment: 'WB PWD, KMDA, WBSEDCL', iconBg: 'bg-teal-600' },
  { stateName: 'Rajasthan', code: 'RJ', activeTendersCount: 8450, totalValueCrores: '₹ 4,890 Cr', topDepartment: 'Rajasthan PWD, PHED, RSAMB', iconBg: 'bg-rose-600' },
  { stateName: 'Telangana', code: 'TS', activeTendersCount: 7800, totalValueCrores: '₹ 6,120 Cr', topDepartment: 'R&B Dept, TSSPDCL, HMWS&SB', iconBg: 'bg-purple-600' },
  { stateName: 'Madhya Pradesh', code: 'MP', activeTendersCount: 7120, totalValueCrores: '₹ 4,320 Cr', topDepartment: 'MP PWD, MP Urban Dev, MPPKVVCL', iconBg: 'bg-cyan-600' },
  { stateName: 'Andhra Pradesh', code: 'AP', activeTendersCount: 6800, totalValueCrores: '₹ 4,110 Cr', topDepartment: 'AP R&B, APTRANSCO, VMRDA', iconBg: 'bg-sky-600' },
  { stateName: 'Bihar', code: 'BR', activeTendersCount: 6500, totalValueCrores: '₹ 3,950 Cr', topDepartment: 'Bihar BSRDCL, PHED, Road Construction', iconBg: 'bg-amber-700' },
  { stateName: 'Odisha', code: 'OD', activeTendersCount: 5900, totalValueCrores: '₹ 3,780 Cr', topDepartment: 'Works Dept Odisha, OPTCL, WATCO', iconBg: 'bg-emerald-700' },
  { stateName: 'Haryana', code: 'HR', activeTendersCount: 5400, totalValueCrores: '₹ 3,210 Cr', topDepartment: 'Haryana PWD, HSVP, DHBVN', iconBg: 'bg-blue-700' },
  { stateName: 'Punjab', code: 'PB', activeTendersCount: 4800, totalValueCrores: '₹ 2,900 Cr', topDepartment: 'Punjab PWD, PSPCL, GMADA', iconBg: 'bg-[#002D62]' },
  { stateName: 'Kerala', code: 'KL', activeTendersCount: 4200, totalValueCrores: '₹ 2,450 Cr', topDepartment: 'Kerala PWD, KSEB, KWA', iconBg: 'bg-emerald-800' },
  { stateName: 'Assam', code: 'AS', activeTendersCount: 3900, totalValueCrores: '₹ 2,100 Cr', topDepartment: 'Assam PWD, APDCL, GMDA', iconBg: 'bg-rose-700' },
  { stateName: 'Jharkhand', code: 'JH', activeTendersCount: 3600, totalValueCrores: '₹ 1,980 Cr', topDepartment: 'Jharkhand Road Construction, JUSNL', iconBg: 'bg-indigo-700' },
  { stateName: 'Chhattisgarh', code: 'CG', activeTendersCount: 3400, totalValueCrores: '₹ 1,850 Cr', topDepartment: 'CG PWD, CSPDCL, NRDA', iconBg: 'bg-amber-800' },
  { stateName: 'Uttarakhand', code: 'UK', activeTendersCount: 3100, totalValueCrores: '₹ 1,650 Cr', topDepartment: 'Uttarakhand PWD, UPCL, UJVNL', iconBg: 'bg-teal-700' },
  { stateName: 'Himachal Pradesh', code: 'HP', activeTendersCount: 2800, totalValueCrores: '₹ 1,420 Cr', topDepartment: 'HP PWD, HPSEBL, Jal Shakti', iconBg: 'bg-blue-800' },
  { stateName: 'Jammu and Kashmir (UT)', code: 'JK', activeTendersCount: 2900, totalValueCrores: '₹ 1,580 Cr', topDepartment: 'JK PWD, JPDCL, KPDCL', iconBg: 'bg-slate-700', isUT: true },
  { stateName: 'Goa', code: 'GA', activeTendersCount: 1200, totalValueCrores: '₹ 750 Cr', topDepartment: 'Goa PWD, Electricity Dept', iconBg: 'bg-orange-600' },
  { stateName: 'Tripura', code: 'TR', activeTendersCount: 950, totalValueCrores: '₹ 480 Cr', topDepartment: 'Tripura PWD, TSECL', iconBg: 'bg-purple-700' },
  { stateName: 'Meghalaya', code: 'ML', activeTendersCount: 880, totalValueCrores: '₹ 420 Cr', topDepartment: 'Meghalaya PWD, MeECL', iconBg: 'bg-cyan-700' },
  { stateName: 'Manipur', code: 'MN', activeTendersCount: 750, totalValueCrores: '₹ 380 Cr', topDepartment: 'Manipur PWD, MSPDCL', iconBg: 'bg-emerald-900' },
  { stateName: 'Arunachal Pradesh', code: 'AR', activeTendersCount: 820, totalValueCrores: '₹ 510 Cr', topDepartment: 'Arunachal PWD, Hydropower Dept', iconBg: 'bg-indigo-800' },
  { stateName: 'Nagaland', code: 'NL', activeTendersCount: 620, totalValueCrores: '₹ 310 Cr', topDepartment: 'Nagaland PWD, Power Dept', iconBg: 'bg-rose-800' },
  { stateName: 'Mizoram', code: 'MZ', activeTendersCount: 540, totalValueCrores: '₹ 260 Cr', topDepartment: 'Mizoram PWD, P&E Dept', iconBg: 'bg-teal-800' },
  { stateName: 'Sikkim', code: 'SK', activeTendersCount: 480, totalValueCrores: '₹ 220 Cr', topDepartment: 'Sikkim RDD, Power Dept', iconBg: 'bg-amber-900' },
  { stateName: 'Chandigarh (UT)', code: 'CH', activeTendersCount: 850, totalValueCrores: '₹ 390 Cr', topDepartment: 'Chandigarh Engineering Dept, MCC', iconBg: 'bg-blue-900', isUT: true },
  { stateName: 'Puducherry (UT)', code: 'PY', activeTendersCount: 620, totalValueCrores: '₹ 280 Cr', topDepartment: 'Puducherry PWD, Electricity Dept', iconBg: 'bg-violet-700', isUT: true },
  { stateName: 'Ladakh (UT)', code: 'LA', activeTendersCount: 710, totalValueCrores: '₹ 450 Cr', topDepartment: 'Ladakh PWD, BRO, LAHDC', iconBg: 'bg-stone-700', isUT: true },
  { stateName: 'Andaman and Nicobar Islands (UT)', code: 'AN', activeTendersCount: 410, totalValueCrores: '₹ 210 Cr', topDepartment: 'APWD, Electricity Dept Port Blair', iconBg: 'bg-teal-900', isUT: true },
  { stateName: 'Dadra and Nagar Haveli and Daman and Diu (UT)', code: 'DN', activeTendersCount: 380, totalValueCrores: '₹ 190 Cr', topDepartment: 'DNH&DD PWD', iconBg: 'bg-neutral-700', isUT: true },
  { stateName: 'Lakshadweep (UT)', code: 'LD', activeTendersCount: 150, totalValueCrores: '₹ 85 Cr', topDepartment: 'Lakshadweep PWD, Port Dept', iconBg: 'bg-cyan-900', isUT: true }
];

export const POPULAR_AUTHORITIES: AuthorityInfo[] = [
  { id: 'auth-1', name: 'Indian Railways (IREPS / Zonal Railways)', shortName: 'RAILWAYS', type: 'Railways', activeTenders: 14200, location: 'Pan India', logoColor: 'bg-red-700' },
  { id: 'auth-2', name: 'Central Public Works Department (CPWD)', shortName: 'CPWD', type: 'Central Ministry', activeTenders: 9850, location: 'Pan India', logoColor: 'bg-[#002D62]' },
  { id: 'auth-3', name: 'National Highways Authority of India (NHAI)', shortName: 'NHAI', type: 'Central Ministry', activeTenders: 4120, location: 'Highways Network', logoColor: 'bg-amber-700' },
  { id: 'auth-4', name: 'NTPC / BHEL / PowerGrid', shortName: 'POWER PSUs', type: 'PSU', activeTenders: 6540, location: 'Thermal & Solar Plants', logoColor: 'bg-emerald-700' },
  { id: 'auth-5', name: 'Military Engineer Services (MES Defence)', shortName: 'MES DEFENSE', type: 'Defense', activeTenders: 3890, location: 'Military Airbases & Cantonments', logoColor: 'bg-[#1e293b]' },
  { id: 'auth-6', name: 'GeM - Government e-Marketplace', shortName: 'GeM PORTAL', type: 'Central Ministry', activeTenders: 38200, location: 'All States / Municipalities', logoColor: 'bg-[#E65100]' },
  { id: 'auth-7', name: 'Indian Oil Corporation (IOCL) / ONGC', shortName: 'OIL PSUs', type: 'PSU', activeTenders: 5120, location: 'Refineries & Exploration', logoColor: 'bg-orange-700' },
  { id: 'auth-8', name: 'Jal Jeevan Mission & State Jal Nigams', shortName: 'JAL NIGAMS', type: 'State Dept', activeTenders: 12400, location: 'Rural & Urban Water Networks', logoColor: 'bg-blue-700' },
  { id: 'auth-9', name: 'Municipal Corporations (BMC / MCD / BBMP / AMC)', shortName: 'MUNICIPAL', type: 'Smart City', activeTenders: 15600, location: 'Metros & Tier 1/2 Cities', logoColor: 'bg-purple-700' }
];

export const DEFAULT_USER_PROFILE: import('../types').UserProfile = {
  name: 'Rajudas',
  email: 'rajudaszoology22@gmail.com',
  mobile: '9876543210',
  address: '123 Government Procurement Hub, Marine Drive, Mumbai, Maharashtra 400021',
  gender: 'Male',
  dateOfBirth: '1992-08-15',
  avatarBgColor: 'bg-red-600',

  gstNumber: '27AABCU9603R1ZM',
  panNumber: 'AABCU9603R',
  companyName: 'Rajudas Procurement Solutions Pvt Ltd',
  billingAddress: '123 Government Procurement Hub, Marine Drive, Mumbai, Maharashtra 400021',
  paymentHistory: [
    {
      id: 'INV-2026-001',
      date: '2026-07-01',
      description: 'Tenderplus Enterprise Annual Portal Subscription',
      amount: '₹ 14,999',
      taxAmount: '₹ 2,700 (GST 18%)',
      status: 'Paid',
      invoiceUrl: '#'
    },
    {
      id: 'INV-2026-002',
      date: '2026-06-12',
      description: 'Custom WhatsApp Tender Alert Desk Add-On',
      amount: '₹ 2,499',
      taxAmount: '₹ 450 (GST 18%)',
      status: 'Paid',
      invoiceUrl: '#'
    },
    {
      id: 'INV-2025-089',
      date: '2025-07-01',
      description: 'Tenderplus Pro Tier (1 Year Renewal)',
      amount: '₹ 9,999',
      taxAmount: '₹ 1,800 (GST 18%)',
      status: 'Paid',
      invoiceUrl: '#'
    }
  ],

  subAccountControls: {
    emailNotifications: true,
    smsAlerts: true,
    whatsappUpdates: true,
    allowSubUsers: true,
    autoTrackNewTenders: true,
    rolePermissions: 'Admin',
    dailyDigestTime: '08:00 AM'
  },

  twoFactorEnabled: true,
  twoFactorMethod: 'Gmail OTP',
  twoFactorPhoneOrEmail: 'rajudaszoology22@gmail.com',
  backupCodes: ['8A2K-91F2', '3M7P-41L0', '9X1Z-88Q2', '5B6R-22T9', '7C3W-90M4', '1K8Y-66N3'],
  activeSessions: [
    {
      id: 'sess-1',
      device: 'Chrome on Windows 11 (Current)',
      ip: '103.21.124.88',
      location: 'Mumbai, Maharashtra, India',
      lastActive: 'Just now',
      current: true
    },
    {
      id: 'sess-2',
      device: 'Safari on iPhone 15 Pro',
      ip: '103.21.124.90',
      location: 'Mumbai, Maharashtra, India',
      lastActive: '3 hours ago',
      current: false
    }
  ]
};
